// Inhalt von sql/shops_items.sql – Platzhalter für Shop-System
