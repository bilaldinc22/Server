// Inhalt von README_INSTALL.md – Platzhalter für Shop-System
