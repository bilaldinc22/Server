// Inhalt von packages/Gamemode/shops/clothes.js – Platzhalter für Shop-System
