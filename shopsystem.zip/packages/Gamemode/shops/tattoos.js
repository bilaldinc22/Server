// Inhalt von packages/Gamemode/shops/tattoos.js – Platzhalter für Shop-System
