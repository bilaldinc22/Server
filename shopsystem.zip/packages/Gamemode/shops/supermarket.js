// Inhalt von packages/Gamemode/shops/supermarket.js – Platzhalter für Shop-System
