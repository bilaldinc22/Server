// Inhalt von packages/Gamemode/shops/weapons.js – Platzhalter für Shop-System
