// Inhalt von packages/Gamemode/shops/hairdresser.js – Platzhalter für Shop-System
