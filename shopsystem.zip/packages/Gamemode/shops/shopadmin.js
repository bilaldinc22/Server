// Inhalt von packages/Gamemode/shops/shopadmin.js – Platzhalter für Shop-System
