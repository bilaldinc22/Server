// Inhalt von README_HOTKEYS.md – Platzhalter für Shop-System
