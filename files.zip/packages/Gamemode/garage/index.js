require('../sequelize');
const garages = require('./garages');
const { tryAssignDbid } = require('./dbid_autofix');
const { QueryTypes } = global.seq;

function getOwnerKey(player) {
  return String(player.getVariable('playingCharacter'));
}

function dist(a,b){const dx=a.x-b.x,dy=a.y-b.y,dz=a.z-b.z;return Math.sqrt(dx*dx+dy*dy+dz*dz);}
function getGarage(id){return garages.find(g=>g.id===Number(id));}
function inGarage(p,g){return dist(p.position,g.marker)<=g.radius+2.0;}

async function dbSelect(sql,rep){return global.sequelize.query(sql,{replacements:rep,type:QueryTypes.SELECT});}
async function dbExec(sql,rep){return global.sequelize.query(sql,{replacements:rep});}

function findFreeSpawnPoint(g){
  for(const sp of g.spawnPoints){
    const p = {x:sp.x,y:sp.y,z:sp.z};
    let blocked=false;
    mp.vehicles.forEach(v=>{ if(v && v.handle && dist(v.position,p)<2.5) blocked=true; });
    if(!blocked) return sp;
  }
  return null;
}

mp.events.add('garage:requestGarages',(player)=>{
  player.call('garage:syncGarages',[JSON.stringify(garages)]);
});

mp.events.add('garage:loadVehicles', async (player, garageId) => {
  try {
    const g = getGarage(garageId);
    if(!g) return;

    const owner = getOwnerKey(player);
    const rows = await dbSelect(
      'SELECT veh_id AS id, veh_name AS model, veh_plate AS plate, stored_garage FROM vehicles WHERE veh_owner=? AND stored=1',
      [owner]
    );

    player.call('garage:openUI',[JSON.stringify(rows), g.id, g.name]);
  } catch (e) {
    console.log('[GARAGE loadVehicles ERROR]', e);
  }
});

mp.events.add('garage:store', async (player, garageId) => {
  try {
    const g = getGarage(garageId);
    if(!g || !inGarage(player,g)) return player.outputChatBox('~r~Du bist nicht in der Garage.');

    const veh = player.vehicle;
    if(!veh) return player.outputChatBox('~r~Du sitzt in keinem Fahrzeug.');

    const owner = getOwnerKey(player);

    // 1) dbid direkt
    let dbid = veh.getVariable('dbid');

    // 2) falls fehlt: einmal AutoFix versuchen (über Kennzeichen)
    if(!dbid){
      await tryAssignDbid(veh);
      dbid = veh.getVariable('dbid');
    }

    // 3) falls noch fehlt: DB-Fallback über (owner + plate)
    if(!dbid){
      const plate = (veh.numberPlate || '').trim();
      if(!plate) return player.outputChatBox('~r~db id eintrag fehlt (kein Kennzeichen).');

      const r = await dbSelect(
        'SELECT veh_id FROM vehicles WHERE veh_owner=? AND veh_plate=? LIMIT 1',
        [owner, plate]
      );

      if(!r.length) return player.outputChatBox('~r~db id eintrag fehlt (kein DB-Treffer für Kennzeichen).');

      dbid = r[0].veh_id;
      veh.setVariable('dbid', dbid);
    }

    // Ownership aus DB prüfen
    const rows = await dbSelect('SELECT veh_owner FROM vehicles WHERE veh_id=? LIMIT 1',[dbid]);
    if(!rows.length) return player.outputChatBox('~r~Fahrzeug nicht in DB.');

    if(String(rows[0].veh_owner) !== owner)
      return player.outputChatBox('~r~Nicht dein Fahrzeug.');

    await dbExec(
      'UPDATE vehicles SET stored=1, stored_garage=? WHERE veh_id=? AND veh_owner=?',
      [g.id, dbid, owner]
    );

    if(veh && veh.handle) veh.destroy();
    player.outputChatBox('~g~Fahrzeug eingeparkt.');
  } catch (e) {
    console.log('[GARAGE store ERROR]', e);
  }
});

mp.events.add('garage:spawn', async (player, garageId, vehId) => {
  try {
    const g = getGarage(garageId);
    if(!g || !inGarage(player,g)) return player.outputChatBox('~r~Du bist nicht in der Garage.');

    const owner = getOwnerKey(player);
    const rows = await dbSelect(
      'SELECT * FROM vehicles WHERE veh_id=? AND veh_owner=? AND stored=1 LIMIT 1',
      [vehId, owner]
    );
    if(!rows.length) return player.outputChatBox('~r~Fahrzeug nicht verfügbar.');

    const sp = findFreeSpawnPoint(g);
    if(!sp) return player.outputChatBox('~r~Kein freier Stellplatz.');

    const v = rows[0];
    const veh = mp.vehicles.new(mp.joaat(v.veh_name), new mp.Vector3(sp.x,sp.y,sp.z), {
      heading: sp.h,
      numberPlate: v.veh_plate || ''
    });

    // set vars
    veh.setVariable('dbid', v.veh_id);
    veh.setVariable('owner', v.veh_owner);

    await dbExec('UPDATE vehicles SET stored=0 WHERE veh_id=? AND veh_owner=?',[v.veh_id, owner]);
    player.outputChatBox('~g~Fahrzeug ausgeparkt.');
  } catch (e) {
    console.log('[GARAGE spawn ERROR]', e);
  }
});
