require('../sequelize');
const { QueryTypes } = global.seq;

async function tryAssignDbid(veh) {
  try {
    if (!veh || !veh.handle) return;
    if (veh.getVariable('dbid')) return;

    const plateRaw = veh.numberPlate;
    const plate = (plateRaw || '').trim();
    if (!plate) return;

    const rows = await global.sequelize.query(
      'SELECT veh_id, veh_owner FROM vehicles WHERE veh_plate = ? LIMIT 1',
      { replacements: [plate], type: QueryTypes.SELECT }
    );

    if (!rows.length) return;

    veh.setVariable('dbid', rows[0].veh_id);
    veh.setVariable('owner', rows[0].veh_owner);

    // optional debug
    // console.log(`[GARAGE] dbid auto gesetzt: ${rows[0].veh_id} plate=${plate}`);
  } catch (e) {
    console.log('[GARAGE dbid_autofix ERROR]', e);
  }
}

mp.events.add('vehicleCreated', (veh) => {
  // plate wird manchmal erst nach Create gesetzt -> retries
  setTimeout(() => tryAssignDbid(veh), 200);
  setTimeout(() => tryAssignDbid(veh), 1200);
  setTimeout(() => tryAssignDbid(veh), 3000);
});

module.exports = { tryAssignDbid };
