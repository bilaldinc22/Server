module.exports = [
  {
    id: 1,
    name: "LS Garage",
    marker: { x: 215.8, y: -810.1, z: 30.7 },
    radius: 3.5,
    blip: { sprite: 357, color: 27, scale: 0.8 },
    spawnPoints: [
      { x: 223.2, y: -806.0, z: 30.0, h: 157.0 },
      { x: 226.6, y: -804.8, z: 30.0, h: 157.0 },
      { x: 230.2, y: -803.2, z: 30.0, h: 157.0 }
    ]
  }
];
