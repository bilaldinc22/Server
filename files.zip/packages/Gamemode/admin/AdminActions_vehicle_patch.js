// PATCH-FILE: Merge diese Funktionen in DEIN bestehendes AdminActions.js
// (Damit du nicht andere Admin-Funktionen verlierst.)

const AdminVehRepo = require("./db/AdminSpawnedVehicleRepository");

function nearestVehicle(pos, maxDist=10.0) {
  const maxSq = maxDist*maxDist;
  let best=null, bestSq=maxSq;
  mp.vehicles.forEach(v=>{
    if (!v || !v.position) return;
    const dx=pos.x-v.position.x, dy=pos.y-v.position.y, dz=pos.z-v.position.z;
    const d=dx*dx+dy*dy+dz*dz;
    if (d<bestSq){ bestSq=d; best=v; }
  });
  return best;
}

module.exports.vehicleSpawn = async function(admin, model) {
  model = String(model || "adder").trim();
  const hash = mp.joaat(model);
  const pos = admin.position;
  const heading = admin.heading;

  const v = mp.vehicles.new(hash, pos, { heading });

  v.setVariable("adminSpawned", true);
  v.setVariable("adminOwnerSc", admin.socialClub);
  v.setVariable("adminOwnerName", admin.name);

  const plate = `ADM${String(admin.id).padStart(2,"0")}`;
  try { v.numberPlate = plate; } catch {}

  const row = await AdminVehRepo.create(admin, model, pos, heading, plate);
  if (row && row.id) v.setVariable("adminDbId", row.id);
};

module.exports.vehicleDelete = async function(admin) {
  const v = admin.vehicle || nearestVehicle(admin.position, 10.0);
  if (!v) return;

  const dbId = v.getVariable("adminDbId");
  if (dbId) await AdminVehRepo.deactivate(dbId);

  v.destroy();
};
