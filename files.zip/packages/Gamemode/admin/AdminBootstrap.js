const { getAdminLevelByPlayer, setAdminLevelForSocialClub } = require("./AdminRankProvider");
const { PERMS } = require("./AdminPermissions");

mp.events.add("playerJoin", (p)=> { p.adminLevel = getAdminLevelByPlayer(p); });

mp.events.addCommand("setadmin", (p, _, id, level) => {
  if (Number(p.adminLevel||0) < PERMS.OWNER) return p.outputChatBox("~r~Keine Berechtigung. (Owner benötigt)");
  const t = mp.players.at(parseInt(id,10));
  const lvl = parseInt(level,10);
  if (!t || !Number.isFinite(lvl)) return p.outputChatBox("~r~Usage: /setadmin <id> <level>");
  t.adminLevel = lvl;
  setAdminLevelForSocialClub(t.socialClub, lvl);
  p.outputChatBox(`~g~Admin gesetzt: ${t.name} (${t.socialClub}) -> Level ${lvl}`);
});
