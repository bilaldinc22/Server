const { requireLevel, PERMS } = require("./AdminPermissions");
mp.events.add("admin:panel:opened", (admin) => { if (!requireLevel(admin, PERMS.SUPPORT)) return; admin.adminPanelOpen = true; });
mp.events.add("admin:panel:closed", (admin) => { admin.adminPanelOpen = false; });
