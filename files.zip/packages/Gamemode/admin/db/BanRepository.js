const { Op } = require("sequelize");
const AdminBan = require("./Ban.model");

module.exports = {
  async ban({ player, sc, reason, admin, until }) {
    await AdminBan.create({ targetName: player, targetSocialClub: sc, reason, adminName: admin, expiresAt: until, active: true });
  },
  async active(sc) {
    return await AdminBan.findOne({
      where: {
        targetSocialClub: sc,
        active: true,
        [Op.or]: [{ expiresAt: null }, { expiresAt: { [Op.gt]: new Date() } }]
      },
      order: [["id","DESC"]]
    });
  },
  async list(limit=200) {
    return await AdminBan.findAll({ where:{active:true}, order:[["createdAt","DESC"]], limit });
  },
  async unban(sc) {
    await AdminBan.update({ active:false }, { where:{ targetSocialClub: sc } });
  }
};
