const { DataTypes } = require("sequelize");
const sequelize = global.sequelize;
if (!sequelize) throw new Error("global.sequelize ist nicht gesetzt. sequelize.js muss vorher geladen werden.");

const AdminBan = sequelize.define("admin_bans", {
  id: { type: DataTypes.INTEGER, primaryKey:true, autoIncrement:true },
  targetName: { type: DataTypes.STRING(255), allowNull:true },
  targetSocialClub: { type: DataTypes.STRING(255), allowNull:true },
  reason: { type: DataTypes.TEXT, allowNull:true },
  adminName: { type: DataTypes.STRING(255), allowNull:true },
  expiresAt: { type: DataTypes.DATE, allowNull:true },
  active: { type: DataTypes.BOOLEAN, defaultValue:true }
}, {
  tableName: "admin_bans",
  timestamps: true,
  createdAt: "createdAt",
  updatedAt: "updatedAt"
});
module.exports = AdminBan;
