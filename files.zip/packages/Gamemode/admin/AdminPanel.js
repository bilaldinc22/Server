const Actions = require("./AdminActions");
const { requireLevel, PERMS, getLevel } = require("./AdminPermissions");
const { asInt, safeStr } = require("./AdminUtil");

function need(admin, lvl) {
  if (!requireLevel(admin, lvl)) { admin.outputChatBox("~r~Keine Berechtigung."); return false; }
  return true;
}
function targetById(id) { return (typeof id === "number") ? mp.players.at(id) : null; }

mp.events.add("admin:panel:action", async (admin, act, json) => {
  try {
    let d = {};
    try { d = JSON.parse(json || "{}"); } catch { d = {}; }
    const t = targetById(d.id);

    switch (act) {
      case "toggleDuty":
        if (!need(admin, PERMS.SUPPORT)) return;
        admin.adminDuty = !admin.adminDuty;
        admin.outputChatBox(`~g~Admin-Dienst: ${admin.adminDuty ? "AN" : "AUS"}`);
        return;

      case "adminChat":
        if (!need(admin, PERMS.SUPPORT)) return;
        const msg = safeStr(d.msg, "").trim();
        if (!msg) return;
        mp.players.forEach(p => { if (getLevel(p) >= PERMS.SUPPORT) p.outputChatBox(`~b~[A] ${admin.name}: ~w~${msg}`); });
        return;

      case "refresh":
        if (!need(admin, PERMS.SUPPORT)) return mp.events.call("admin:panel:refresh", admin);
        return;

      case "remove":
        if (!need(admin, PERMS.MODERATOR)) return;
        if (t) Actions.remove(admin, t, d.reason || "Admin Remove");
        return;

      case "permban":
        if (!need(admin, PERMS.MODERATOR)) return;
        if (t) await Actions.permban(admin, t, d.reason);
        return;

      case "tempban":
        if (!need(admin, PERMS.MODERATOR)) return;
        if (t) await Actions.tempban(admin, t, asInt(d.minutes, 60), d.reason);
        return;

      case "unban":
        if (!need(admin, PERMS.MODERATOR)) return;
        if (d.socialclub) await Actions.unban(admin, d.socialclub);
        return;

      case "freeze":
        if (!need(admin, PERMS.MODERATOR)) return;
        if (t) Actions.freeze(admin, t);
        return;

      case "unfreeze":
        if (!need(admin, PERMS.MODERATOR)) return;
        if (t) Actions.unfreeze(admin, t);
        return;

      case "god":
        if (!need(admin, PERMS.ADMIN)) return;
        if (t) Actions.setGod(admin, t, true);
        return;

      case "ungod":
        if (!need(admin, PERMS.ADMIN)) return;
        if (t) Actions.setGod(admin, t, false);
        return;

      case "heal":
        if (!need(admin, PERMS.SUPPORT)) return;
        if (t) Actions.heal(admin, t);
        return;

      case "armor":
        if (!need(admin, PERMS.ADMIN)) return;
        if (t) Actions.armor(admin, t);
        return;

      case "revive":
        if (!need(admin, PERMS.MODERATOR)) return;
        if (t) Actions.revive(admin, t);
        return;

      case "invis":
        if (!need(admin, PERMS.ADMIN)) return;
        if (t) Actions.invis(admin, t);
        return;

      case "tp":
        if (!need(admin, PERMS.ADMIN)) return;
        if (t) Actions.tpTo(admin, t);
        return;

      case "bring":
        if (!need(admin, PERMS.ADMIN)) return;
        if (t) Actions.bring(admin, t);
        return;

      case "spectate":
        if (!need(admin, PERMS.MODERATOR)) return;
        if (t) Actions.spectate(admin, t);
        return;

      case "spectateStop":
        if (!need(admin, PERMS.MODERATOR)) return;
        Actions.stopSpectate(admin);
        return;

      case "tpwp":
        if (!need(admin, PERMS.ADMIN)) return;
        Actions.tpToWaypoint(admin);
        return;

      case "vehSpawn":
        if (!need(admin, PERMS.ADMIN)) return;
        Actions.vehicleSpawn(admin, d.model || "adder");
        return;

      case "vehRepair":
        if (!need(admin, PERMS.ADMIN)) return;
        Actions.vehicleRepair(admin);
        return;

      case "vehDelete":
        if (!need(admin, PERMS.ADMIN)) return;
        Actions.vehicleDelete(admin);
        return;
    }
  } catch (e) {
    console.error("[ADMIN][PANEL] Action Fehler:", e?.message || e);
  }
});

mp.events.add("admin:tpwp:coords", (admin, x, y, z) => {
  if (!requireLevel(admin, PERMS.ADMIN)) return;
  if (![x,y,z].every(v => Number.isFinite(Number(v)))) return;
  admin.position = new mp.Vector3(Number(x), Number(y), Number(z) + 1.0);
});
