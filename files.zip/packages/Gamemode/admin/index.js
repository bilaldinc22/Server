require("./AdminBootstrap");
require("./AdminEvents");
require("./AdminPanel");
require("./AdminPanelData");
require("./AdminPanelLifecycle");
require("./AdminVehiclePersistence");

console.log("[ADMIN] FINAL Admin System geladen");
