const Bans = require("./db/BanRepository");
mp.events.add("playerJoin", (p) => {
  (async () => {
    try {
      const ban = await Bans.active(p.socialClub);
      if (!ban) return;
      const msg = ban.expiresAt ? `Bis ${ban.expiresAt}` : "Permanent";
      p.kick(`BAN: ${ban.reason}\n${msg}`);
    } catch (e) {
      console.error("[ADMIN][BAN] DB Fehler:", e?.message || e);
    }
  })();
});
