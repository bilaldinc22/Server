const BanRepo = require("./db/BanRepository");
const { getLevel, PERMS } = require("./AdminPermissions");

function buildPlayers() {
  const out = [];
  mp.players.forEach(p => {
    out.push({ id:p.id, name:p.name, ping:p.ping, health:p.health, armour:p.armour, socialclub:p.socialClub||"" });
  });
  return out;
}

async function buildPayload(admin) {
  const level = getLevel(admin);
  let bans = [];
  try { bans = await BanRepo.list(200); }
  catch (e) { console.error("[ADMIN][BANS] list DB Fehler:", e?.message || e); bans = []; }

  return JSON.stringify({
    self: { name: admin.name, adminLevel: level, duty: !!admin.adminDuty },
    perms: PERMS,
    players: buildPlayers(),
    bans: (bans||[]).map(b => ({
      id: b.id,
      playerName: b.targetName,
      socialclub: b.targetSocialClub,
      reason: b.reason,
      adminName: b.adminName,
      createdAt: b.createdAt,
      banUntil: b.expiresAt,
      type: b.expiresAt ? "TEMP" : "PERM"
    }))
  });
}

mp.events.add("admin:panel:open", async (admin) => {
  const payload = await buildPayload(admin);
  admin.call("admin:panel:open", [payload]);
});

mp.events.add("admin:panel:refresh", async (admin) => {
  const payload = await buildPayload(admin);
  admin.call("admin:panel:data", [payload]);
});

setInterval(() => {
  mp.players.forEach(p => {
    if (!p.adminPanelOpen) return;
    p.call("admin:panel:players", [JSON.stringify(buildPlayers())]);
  });
}, 2000);
