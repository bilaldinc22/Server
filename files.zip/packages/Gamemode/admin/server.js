// Consolidated admin server-side bootstrap/events/panel/data/lifecycle.
// Goal: fewer files, same external events.

const Actions = require("./AdminActions");
const Bans = require("./db/BanRepository");
const VehiclePersistence = require("./AdminVehiclePersistence");
const { getAdminLevelByPlayer, setAdminLevelForSocialClub } = require("./AdminRankProvider");
const { requireLevel, PERMS, getLevel } = require("./AdminPermissions");
const { asInt, safeStr } = require("./AdminUtil");
const BanRepo = require("./db/BanRepository");

// --- Bootstrap / join guards

mp.events.add("playerJoin", (p) => {
  // rank
  p.adminLevel = getAdminLevelByPlayer(p);

  // ban check
  (async () => {
    try {
      const ban = await Bans.active(p.socialClub);
      if (!ban) return;
      const msg = ban.expiresAt ? `Bis ${ban.expiresAt}` : "Permanent";
      p.kick(`BAN: ${ban.reason}\n${msg}`);
    } catch (e) {
      console.error("[ADMIN][BAN] DB Fehler:", e?.message || e);
    }
  })();
});

// /setadmin <id> <level>
mp.events.addCommand("setadmin", (p, _, id, level) => {
  if (Number(p.adminLevel || 0) < PERMS.OWNER) return p.outputChatBox("~r~Keine Berechtigung. (Owner benötigt)");
  const t = mp.players.at(parseInt(id, 10));
  const lvl = parseInt(level, 10);
  if (!t || !Number.isFinite(lvl)) return p.outputChatBox("~r~Usage: /setadmin <id> <level>");
  t.adminLevel = lvl;
  setAdminLevelForSocialClub(t.socialClub, lvl);
  p.outputChatBox(`~g~Admin gesetzt: ${t.name} (${t.socialClub}) -> Level ${lvl}`);
});

// --- Panel lifecycle + data

function buildPlayers() {
  const out = [];
  mp.players.forEach((p) => {
    out.push({
      id: p.id,
      name: p.name,
      ping: p.ping,
      health: p.health,
      armour: p.armour,
      socialclub: p.socialClub || "",
    });
  });
  return out;
}

async function buildPayload(admin) {
  const level = getLevel(admin);
  let bans = [];
  try {
    bans = await BanRepo.list(200);
  } catch (e) {
    console.error("[ADMIN][BANS] list DB Fehler:", e?.message || e);
    bans = [];
  }

  return JSON.stringify({
    self: { name: admin.name, adminLevel: level, duty: !!admin.adminDuty },
    perms: PERMS,
    players: buildPlayers(),
    bans: (bans || []).map((b) => ({
      id: b.id,
      playerName: b.targetName,
      socialclub: b.targetSocialClub,
      reason: b.reason,
      adminName: b.adminName,
      createdAt: b.createdAt,
      banUntil: b.expiresAt,
      type: b.expiresAt ? "TEMP" : "PERM",
    })),
  });
}

mp.events.add("admin:panel:opened", (admin) => {
  if (!requireLevel(admin, PERMS.SUPPORT)) return;
  admin.adminPanelOpen = true;
});

mp.events.add("admin:panel:closed", (admin) => {
  admin.adminPanelOpen = false;
});

mp.events.add("admin:panel:open", async (admin) => {
  const payload = await buildPayload(admin);
  admin.call("admin:panel:open", [payload]);
});

mp.events.add("admin:panel:refresh", async (admin) => {
  const payload = await buildPayload(admin);
  admin.call("admin:panel:data", [payload]);
});

setInterval(() => {
  mp.players.forEach((p) => {
    if (!p.adminPanelOpen) return;
    p.call("admin:panel:players", [JSON.stringify(buildPlayers())]);
  });
}, 2000);

// --- Panel action router (same event name used by client/cef)

function need(admin, lvl) {
  if (!requireLevel(admin, lvl)) {
    admin.outputChatBox("~r~Keine Berechtigung.");
    return false;
  }
  return true;
}

function targetById(id) {
  return typeof id === "number" ? mp.players.at(id) : null;
}

const ACTIONS = {
  toggleDuty: (admin) => {
    if (!need(admin, PERMS.SUPPORT)) return;
    admin.adminDuty = !admin.adminDuty;
    admin.outputChatBox(`~g~Admin-Dienst: ${admin.adminDuty ? "AN" : "AUS"}`);
  },

  adminChat: (admin, d) => {
    if (!need(admin, PERMS.SUPPORT)) return;
    const msg = safeStr(d.msg, "").trim();
    if (!msg) return;
    mp.players.forEach((p) => {
      if (getLevel(p) >= PERMS.SUPPORT) p.outputChatBox(`~b~[A] ${admin.name}: ~w~${msg}`);
    });
  },

  refresh: (admin) => {
    if (!need(admin, PERMS.SUPPORT)) return;
    mp.events.call("admin:panel:refresh", admin);
  },

  remove: (admin, d, t) => {
    if (!need(admin, PERMS.MODERATOR)) return;
    if (t) Actions.remove(admin, t, d.reason || "Admin Remove");
  },

  permban: async (admin, d, t) => {
    if (!need(admin, PERMS.MODERATOR)) return;
    if (t) await Actions.permban(admin, t, d.reason);
  },

  tempban: async (admin, d, t) => {
    if (!need(admin, PERMS.MODERATOR)) return;
    if (t) await Actions.tempban(admin, t, asInt(d.minutes, 60), d.reason);
  },

  unban: async (admin, d) => {
    if (!need(admin, PERMS.MODERATOR)) return;
    if (d.socialclub) await Actions.unban(admin, d.socialclub);
  },

  freeze: (admin, d, t) => {
    if (!need(admin, PERMS.MODERATOR)) return;
    if (t) Actions.freeze(admin, t);
  },
  unfreeze: (admin, d, t) => {
    if (!need(admin, PERMS.MODERATOR)) return;
    if (t) Actions.unfreeze(admin, t);
  },

  god: (admin, d, t) => {
    if (!need(admin, PERMS.ADMIN)) return;
    if (t) Actions.setGod(admin, t, true);
  },
  ungod: (admin, d, t) => {
    if (!need(admin, PERMS.ADMIN)) return;
    if (t) Actions.setGod(admin, t, false);
  },

  heal: (admin, d, t) => {
    if (!need(admin, PERMS.SUPPORT)) return;
    if (t) Actions.heal(admin, t);
  },

  armor: (admin, d, t) => {
    if (!need(admin, PERMS.ADMIN)) return;
    if (t) Actions.armor(admin, t);
  },

  revive: (admin, d, t) => {
    if (!need(admin, PERMS.MODERATOR)) return;
    if (t) Actions.revive(admin, t);
  },

  invis: (admin, d, t) => {
    if (!need(admin, PERMS.ADMIN)) return;
    if (t) Actions.invis(admin, t);
  },

  tp: (admin, d, t) => {
    if (!need(admin, PERMS.ADMIN)) return;
    if (t) Actions.tpTo(admin, t);
  },

  bring: (admin, d, t) => {
    if (!need(admin, PERMS.ADMIN)) return;
    if (t) Actions.bring(admin, t);
  },

  spectate: (admin, d, t) => {
    if (!need(admin, PERMS.MODERATOR)) return;
    if (t) Actions.spectate(admin, t);
  },

  spectateStop: (admin) => {
    if (!need(admin, PERMS.MODERATOR)) return;
    Actions.stopSpectate(admin);
  },

  tpwp: (admin) => {
    if (!need(admin, PERMS.ADMIN)) return;
    Actions.tpToWaypoint(admin);
  },

  vehSpawn: (admin, d) => {
    if (!need(admin, PERMS.ADMIN)) return;
    Actions.vehicleSpawn(admin, d.model || "adder");
  },

  vehRepair: (admin) => {
    if (!need(admin, PERMS.ADMIN)) return;
    Actions.vehicleRepair(admin);
  },

  vehDelete: (admin) => {
    if (!need(admin, PERMS.ADMIN)) return;
    Actions.vehicleDelete(admin);
  },
};

mp.events.add("admin:panel:action", async (admin, act, json) => {
  try {
    let d = {};
    try {
      d = JSON.parse(json || "{}");
    } catch {
      d = {};
    }

    const handler = ACTIONS[String(act)];
    if (!handler) return;

    const t = targetById(d.id);

    const res = handler(admin, d, t);
    if (res && typeof res.then === "function") await res;
  } catch (e) {
    console.error("[ADMIN][PANEL] Action Fehler:", e?.message || e);
  }
});

// TP to waypoint: coords received from client
mp.events.add("admin:tpwp:coords", (admin, x, y, z) => {
  if (!requireLevel(admin, PERMS.ADMIN)) return;
  if (![x, y, z].every((v) => Number.isFinite(Number(v)))) return;
  admin.position = new mp.Vector3(Number(x), Number(y), Number(z) + 1.0);
});

// --- Vehicle persistence boot
(async () => {
  try {
    await VehiclePersistence.loadAll();
    VehiclePersistence.startAutoSave();
  } catch (e) {
    console.error("[ADMIN][VEH] Persist init Fehler:", e?.message || e);
  }
})();
