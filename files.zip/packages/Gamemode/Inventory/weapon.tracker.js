const PlayerWeapon = require('../models/PlayerWeapon');

mp.events.add('playerWeaponChange', async (player, oldWeapon) => {
    if (!player?.character?.id) return;
    if (!oldWeapon || oldWeapon === 0) return;

    await PlayerWeapon.upsert({
        characterId: player.character.id,
        hash: oldWeapon,
        ammo: player.getAmmo(oldWeapon)
    });
});