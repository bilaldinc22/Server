const WeaponMap = require('./weapon.map');

function useItem(player, item) {

    if (WeaponMap[item.name]) {
        const hash = WeaponMap[item.name];

        if (player.hasWeapon(hash)) return;

        player.giveWeapon(hash, 0);
        removeItemFromInventory(player, item);
        return;
    }
}

module.exports = { useItem };