'use strict';

const PlayerItem = require('./item');
const ItemTemplate = require('../models/ItemTemplate');

const MAX_SLOTS = 40;
const MAX_WEIGHT = 50;

// In-memory world drops (simple + stable)
const worldDrops = new Map(); // dropId -> { id, pos, dim, items:[{templateId, amount, meta}] }
let nextDropId = 1;

function getOwnerId(player) {
    try {
        if (player && player.character && player.character.id) return player.character.id;
        if (player && player.characterId) return player.characterId;

        const v1 = player.getVariable && player.getVariable('characterId');
        if (v1) return v1;
        const v2 = player.getVariable && player.getVariable('character_id');
        if (v2) return v2;
    } catch (e) {}
    return null;
}

async function getFreeSlot(ownerId) {
    const items = await PlayerItem.findAll({
        where: { owner_id: ownerId },
        attributes: ['slot']
    });

    const used = items.map(i => i.slot);
    for (let i = 1; i <= MAX_SLOTS; i++) {
        if (!used.includes(i)) return i;
    }
    return null;
}

function safeParseMeta(meta) {
    if (!meta) return {};
    if (typeof meta === 'object') return meta;
    try { return JSON.parse(String(meta)); } catch { return {}; }
}

async function getInventoryByOwner(ownerId) {
    return PlayerItem.findAll({
        where: { owner_id: ownerId },
        include: [{
            model: ItemTemplate,
            as: 'template'
        }],
        order: [['slot', 'ASC']]
    });
}

function getMaxWeight(player) {
    // You can later make this depend on player level/bags, etc.
    return MAX_WEIGHT;
}

async function getInventoryWeight(ownerId) {
    const rows = await getInventoryByOwner(ownerId);
    let w = 0;
    for (const r of rows) {
        const weight = Number(r.template?.weight ?? 1);
        const amount = Number(r.amount ?? 1);
        w += weight * amount;
    }
    return w;
}

async function giveItemToPlayer(player, templateName, amount = 1, meta = {}) {
    try {
        // Only block "normal" inventory actions. Server scripts/shops can bypass.
        if (!player._serverGiveItem) {
            if (player.isInMenu || player.inventoryBlocked) {
                console.log('[INV] Blocked (menu/login)');
                return false;
            }
        }

        const ownerId = getOwnerId(player);
        if (!ownerId) {
            console.log('[INV] NO OWNER ID');
            return false;
        }

        const template = await ItemTemplate.findOne({ where: { name: templateName } });
        if (!template) {
            console.log('[INV] TEMPLATE NOT FOUND:', templateName);
            return false;
        }

        const slot = await getFreeSlot(ownerId);
        if (!slot) {
            console.log('[INV] NO FREE SLOT');
            return false;
        }

        const strMeta = (meta && typeof meta === 'object') ? JSON.stringify(meta) : meta;

        await PlayerItem.create({
            owner_id: ownerId,
            item_template_id: template.id,
            slot,
            amount: Number(amount) || 1,
            meta: strMeta
        });

        console.log('[INV] ITEM CREATED FOR OWNER', ownerId, templateName);
        return true;
    } catch (e) {
        console.log('[INV] giveItemToPlayer ERROR', e);
        return false;
    }
}

async function useItem(player, itemId) {
    const ownerId = getOwnerId(player);
    if (!ownerId) return;

    const row = await PlayerItem.findOne({
        where: { id: Number(itemId), owner_id: ownerId },
        include: [{ model: ItemTemplate, as: 'template' }]
    });
    if (!row || !row.template) return;

    const tname = String(row.template.name || '').toLowerCase();
    const meta = safeParseMeta(row.meta);

    if (tname === 'clothing') {
        // Required meta keys: component/drawable/texture
        const component = Number(meta.component ?? meta.slot ?? 0);
        const drawable  = Number(meta.drawable ?? -1);
        const texture   = Number(meta.texture ?? 0);
        if (component >= 0 && drawable >= 0) {
            player.setClothes(component, drawable, texture, 0);
            // Persist outfit if module is loaded
            try { mp.events.call('SERVER::OUTFIT:SAVE', player); } catch (e) {}
        }
        return;
    }

    // Other item types can be added here later
}

async function moveItem(player, itemId, newSlot) {
    const ownerId = getOwnerId(player);
    if (!ownerId) return;

    const slot = Number(newSlot);
    if (!slot || slot < 1 || slot > MAX_SLOTS) return;

    const row = await PlayerItem.findOne({ where: { id: Number(itemId), owner_id: ownerId } });
    if (!row) return;

    const occupied = await PlayerItem.findOne({ where: { owner_id: ownerId, slot } });
    if (occupied && occupied.id !== row.id) return;

    row.slot = slot;
    await row.save();
}

async function splitItem(player, itemId, amount) {
    const ownerId = getOwnerId(player);
    if (!ownerId) return;

    const a = Number(amount);
    if (!a || a <= 0) return;

    const row = await PlayerItem.findOne({ where: { id: Number(itemId), owner_id: ownerId } });
    if (!row) return;
    if (Number(row.amount) <= a) return;

    const free = await getFreeSlot(ownerId);
    if (!free) return;

    row.amount = Number(row.amount) - a;
    await row.save();

    await PlayerItem.create({
        owner_id: ownerId,
        item_template_id: row.item_template_id,
        slot: free,
        amount: a,
        meta: row.meta
    });
}

function dist2(a, b) {
    const dx = (a.x - b.x);
    const dy = (a.y - b.y);
    const dz = (a.z - b.z);
    return dx*dx + dy*dy + dz*dz;
}

async function dropItemToWorld(player, itemId, amount) {
    const ownerId = getOwnerId(player);
    if (!ownerId) return;

    const row = await PlayerItem.findOne({
        where: { id: Number(itemId), owner_id: ownerId },
        include: [{ model: ItemTemplate, as: 'template' }]
    });
    if (!row) return;

    const a = Math.max(1, Number(amount) || 1);
    const take = Math.min(a, Number(row.amount) || 1);

    // remove from inventory
    if ((Number(row.amount) || 1) <= take) {
        await row.destroy();
    } else {
        row.amount = (Number(row.amount) || 1) - take;
        await row.save();
    }

    // create/append drop
    const pos = player.position;
    const dim = player.dimension || 0;

    const dropId = nextDropId++;
    worldDrops.set(dropId, {
        id: dropId,
        pos: { x: pos.x, y: pos.y, z: pos.z },
        dim,
        items: [{
            templateId: row.item_template_id,
            amount: take,
            meta: row.meta
        }]
    });
}

async function listNearbyDrops(player) {
    const pos = player.position;
    const dim = player.dimension || 0;
    const out = [];

    for (const d of worldDrops.values()) {
        if (d.dim !== dim) continue;
        if (dist2(pos, d.pos) > (5*5)) continue;
        out.push({ id: d.id, pos: d.pos, count: d.items.length });
    }
    return out;
}

async function pickupWorldItem(player, dropId) {
    const d = worldDrops.get(Number(dropId));
    if (!d) return;

    const pos = player.position;
    const dim = player.dimension || 0;
    if (d.dim !== dim) return;
    if (dist2(pos, d.pos) > (5*5)) return;

    // take all items for simplicity
    for (const it of d.items) {
        const tpl = await ItemTemplate.findByPk(it.templateId);
        if (!tpl) continue;
        await giveItemToPlayer(player, tpl.name, it.amount, safeParseMeta(it.meta));
    }

    worldDrops.delete(d.id);
}

function findNearestPlayer(player, maxDist = 3.0) {
    const pos = player.position;
    const dim = player.dimension || 0;
    let best = null;
    let bestD2 = (maxDist * maxDist);

    mp.players.forEach(p => {
        if (!p || p.id === player.id) return;
        if ((p.dimension || 0) !== dim) return;
        const d2 = dist2(pos, p.position);
        if (d2 < bestD2) { bestD2 = d2; best = p; }
    });

    return best;
}

// Weapon helpers (minimal stubs to satisfy controller)
async function storeWeaponToInventory(player) { return; }
async function restoreWeaponsForPlayer(player) { return; }

module.exports = {
    MAX_SLOTS,
    MAX_WEIGHT,
    getOwnerId,
    getMaxWeight,
    getInventoryWeight,
    getInventoryByOwner,
    giveItemToPlayer,
    useItem,
    moveItem,
    splitItem,
    dropItemToWorld,
    listNearbyDrops,
    pickupWorldItem,
    findNearestPlayer,
    storeWeaponToInventory,
    restoreWeaponsForPlayer
};
