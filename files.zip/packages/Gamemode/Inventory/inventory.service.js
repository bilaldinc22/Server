const { loadWeapons, saveWeaponsSafe } = require('./weapon.persistence');

function getOwnerId(player) {
    return player?.character?.id ?? null;
}

async function restoreInventoryForPlayer(player) {
    // existing inventory load logic
}

async function restoreWeaponsForPlayer(player) {
    await loadWeapons(player);
}

function savePlayerInventory(player) {
    saveWeaponsSafe(player);
}

module.exports = {
    restoreInventoryForPlayer,
    restoreWeaponsForPlayer,
    savePlayerInventory,
    getOwnerId
};