// Beispielhafte Server-Implementierung für Inventar mit
// - MOVE
// - GIVE
// - DROP
// - PICKUP
//
// Passe die Model-Imports und Charakter-Logik an dein Projekt an.

const itemsModel = require("./models/items"); // Platzhalter: an dein Projekt anpassen

// In-Memory Liste für gedroppte Items
let worldDrops = [];
let nextDropId = 1;

function getCharacterId(player) {
    return player.getVariable("playingCharacter"); // ggf. anpassen
}

function distance(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

// Alle Items eines Spielers
mp.events.addProc("SERVER::FETCH:ITEMS", async (player) => {
    try {
        const characterId = getCharacterId(player);
        if (!characterId) return "[]";

        const items = await itemsModel.findAll({
            where: { owner: characterId },
        });

        const result = items.map(i => ({
            id: i.id,
            name: i.name,
            label: i.label,
            amount: i.amount,
            slot: i.slot,
            weight: i.weight || 0
        }));

        return JSON.stringify(result);
    } catch (e) {
        return "[]";
    }
});

// Spieler in der Nähe (für "Geben")
mp.events.addProc("SERVER::FETCH:NEARBY_PLAYERS", (player) => {
    const maxDist = 5.0;
    const pos = player.position;
    const list = [];

    mp.players.forEachInRange(pos, maxDist, (p) => {
        if (p === player) return;
        const d = distance(pos, p.position);
        list.push({
            id: p.id,
            name: p.name,
            distance: d
        });
    });

    return JSON.stringify(list);
});

// Gedroppte Items in der Nähe
mp.events.addProc("SERVER::FETCH:DROPPED_ITEMS", (player) => {
    const maxDist = 5.0;
    const pos = player.position;
    const list = [];

    for (const drop of worldDrops) {
        const d = distance(pos, drop.position);
        if (d <= maxDist) {
            list.push({
                id: drop.id,
                name: drop.name,
                label: drop.label,
                amount: drop.amount,
                distance: d
            });
        }
    }

    return JSON.stringify(list);
});

// Item verschieben
mp.events.add("SERVER::MOVE:ITEM", async (player, itemId, newSlot) => {
    try {
        const characterId = getCharacterId(player);
        if (!characterId) return;

        const item = await itemsModel.findOne({
            where: { id: itemId, owner: characterId },
        });
        if (!item) return;

        const slot = parseInt(newSlot);
        if (isNaN(slot) || slot < 1 || slot > 50) return;

        item.slot = slot;
        await item.save();
    } catch (e) {
        // Logging nach Bedarf
    }
});

// Item benutzen (nur Beispiel)
mp.events.add("SERVER::USE:ITEM", async (player, itemId) => {
    try {
        const characterId = getCharacterId(player);
        if (!characterId) return;

        const item = await itemsModel.findOne({
            where: { id: itemId, owner: characterId },
        });
        if (!item) return;

        const amount = item.amount || 1;
        if (amount <= 1) {
            await item.destroy();
        } else {
            item.amount = amount - 1;
            await item.save();
        }

        player.call("CLIENT::INVENTORY:REFRESH");
    } catch (e) {
        // Logging
    }
});

// Item droppen
mp.events.add("SERVER::DROP:ITEM", async (player, itemId, amount) => {
    try {
        const characterId = getCharacterId(player);
        if (!characterId) return;

        const item = await itemsModel.findOne({
            where: { id: itemId, owner: characterId },
        });
        if (!item) return;

        const toDrop = parseInt(amount);
        if (isNaN(toDrop) || toDrop < 1) return;

        const currentAmount = item.amount || 1;
        if (toDrop > currentAmount) return;

        // Item im Inventar anpassen
        if (toDrop === currentAmount) {
            await item.destroy();
        } else {
            item.amount = currentAmount - toDrop;
            await item.save();
        }

        // Drop auf dem Boden erzeugen
        const pos = player.position;
        const drop = {
            id: nextDropId++,
            name: item.name,
            label: item.label,
            amount: toDrop,
            position: { x: pos.x, y: pos.y, z: pos.z }
        };

        worldDrops.push(drop);

        // Optional: Marker/Label erstellen oder Client informieren
        player.call("CLIENT::INVENTORY:REFRESH");
    } catch (e) {
        // Logging
    }
});

// Item aufheben
mp.events.add("SERVER::PICKUP:ITEM", async (player, dropId) => {
    try {
        const characterId = getCharacterId(player);
        if (!characterId) return;

        const dropIndex = worldDrops.findIndex(d => d.id === dropId);
        if (dropIndex === -1) return;

        const drop = worldDrops[dropIndex];

        const d = distance(player.position, drop.position);
        if (d > 5.0) return;

        // Freien Slot finden
        const items = await itemsModel.findAll({
            where: { owner: characterId },
        });

        const usedSlots = items.map(i => i.slot);
        let freeSlot = null;
        for (let s = 1; s <= 50; s++) {
            if (!usedSlots.includes(s)) {
                freeSlot = s;
                break;
            }
        }
        if (!freeSlot) return;

        // Item erzeugen oder mit Stack mergen
        let invItem = items.find(i => i.name === drop.name);
        if (invItem && invItem.slot === freeSlot) {
            invItem.amount = (invItem.amount || 0) + drop.amount;
            await invItem.save();
        } else {
            await itemsModel.create({
                owner: characterId,
                name: drop.name,
                label: drop.label,
                amount: drop.amount,
                slot: freeSlot
            });
        }

        worldDrops.splice(dropIndex, 1);

        player.call("CLIENT::INVENTORY:REFRESH");
    } catch (e) {
        // Logging
    }
});

// Item an anderen Spieler geben
mp.events.add("SERVER::GIVE:ITEM", async (player, itemId, targetId, amount) => {
    try {
        const characterId = getCharacterId(player);
        if (!characterId) return;

        const target = mp.players.at(targetId);
        if (!target || !target.handle) return;

        const targetCharId = getCharacterId(target);
        if (!targetCharId) return;

        const dist = distance(player.position, target.position);
        if (dist > 5.0) return;

        const item = await itemsModel.findOne({
            where: { id: itemId, owner: characterId },
        });
        if (!item) return;

        const giveAmount = parseInt(amount);
        if (isNaN(giveAmount) || giveAmount < 1) return;

        const currentAmount = item.amount || 1;
        if (giveAmount > currentAmount) return;

        // Item beim Geber anpassen
        if (giveAmount === currentAmount) {
            await item.destroy();
        } else {
            item.amount = currentAmount - giveAmount;
            await item.save();
        }

        // Freien Slot beim Empfänger finden
        const targetItems = await itemsModel.findAll({
            where: { owner: targetCharId },
        });

        const usedSlots = targetItems.map(i => i.slot);
        let freeSlot = null;
        for (let s = 1; s <= 50; s++) {
            if (!usedSlots.includes(s)) {
                freeSlot = s;
                break;
            }
        }
        if (!freeSlot) return;

        // Stack beim Empfänger suchen
        let targetItem = targetItems.find(i => i.name === item.name);
        if (targetItem && targetItem.slot === freeSlot) {
            targetItem.amount = (targetItem.amount || 0) + giveAmount;
            await targetItem.save();
        } else {
            await itemsModel.create({
                owner: targetCharId,
                name: item.name,
                label: item.label,
                amount: giveAmount,
                slot: freeSlot
            });
        }

        player.call("CLIENT::INVENTORY:REFRESH");
        target.call("CLIENT::INVENTORY:REFRESH");
    } catch (e) {
        // Logging
    }
});
