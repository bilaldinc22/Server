//requires
const logger = require('../Logger/discord');
const character = require('../models/character.model');

mp.events.add('playerCommand', (player, command) => {        
    player.outputChatBox(`type /help to view player commands`);
});


mp.events.addCommand("ping", (player) => {
    const name = player.getVariable("playingCharacter");
    player.outputChatBox(`${lightred} [PING] : ${green} ${player.ping}`);
    logger.sendlog('command_logs', `${name} used /ping`);
});


mp.events.addCommand("pm", (player, _, id, ...text) => {
    if(!id || isNaN(id) || !text) return player.outputChatBox(`Syntax : /pm id text`);
    const name = player.getVariable("playingCharacter");
    const target = mp.players.at(id);
    if(!target) return player.outputChatBox(`Player not found!`);
    const targetName = target.getVariable("playingCharacter");
    text = text.join(' ');
    target.outputChatBox(`${pink}[PM Recieved] ${white} [${player.getVariable('playingCharacter')}]` + `(( ${text} ))`);
    player.outputChatBox(`${pink}[PM Sent] ${white} [${target.getVariable('playingCharacter')}]` + `(( ${text} ))`);
    logger.sendlog('chat_logs', `${name} Sent PM to ${targetName}` + `(( ${text} ))`);
});


mp.events.addCommand('stats', async (player) => {
    const charactername = player.getVariable('playingCharacter');

    try {
            const findstats = await character.findOne({ where: { character_name: charactername }});
            if(!findstats) return player.outputChatBox(`Error: using stats, report to server admininstration`);

            player.outputChatBox(`${pink}Stats for ${white}: ${charactername} ${pink} Current ID ${white}: ${player.id}`);
            player.outputChatBox(`${pink}Bank ${white}: ${findstats.bank_money}$ ${pink}Pocket Money ${white}: ${findstats.pocket_money}$ ${pink}Salary ${white} : ${findstats.salary}`);
            player.outputChatBox(`${pink}House Slots ${white}: ${findstats.house_slots} ${pink}Business Slots ${white}: ${findstats.business_slots} ${pink}Vehicle Slots ${white}: ${findstats.vehicle_slots}`);

    } catch (err) {
        logger.sendlog('server_logs', `Stats Command ${err}`);
    }
});