// Color defines 
let darkred = "!{#B30000}";
let lightred = "!{#FF0000}";
let green = "!{#00B30E}";
let blue = "!{#0054B3}";
let orange = "!{#EA7F00}";
let yellow = "!{#FFF009}";
let pink = "!{#FF009B}";
let white = "!{#FFFFFF}";
let purple = "!{#A200FF}";
let skyblue = "!{#00FFFF}";
let gray = "!{#808080}";
let black = "!{#000000}";


 mp.events.add("playerDeath", (player) => {
    player.call('CLIENT::INJURED');
    player.outputChatBox(`${lightred} Injured ${white} call EMS to take you to the hospital`);
    player.playAnimation('combat@damage@injured_pistol@to_writhe', 'variation_b', 1, 49);
    
    setTimeout(function() {
        player.health = 50;
    },250);
 });

