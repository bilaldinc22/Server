'use strict';

/**
 * Zentrales Persistenz-System
 * - arbeitet mit Sequelize-Modellen aus packages/Gamemode/models/index.js
 * - speichert ALLES in separaten Tabellen (Accounts, Items, Waffen, Outfits)
 * - speichert auf Wunsch bei JEDER Änderung (über Events / Funktionsaufrufe)
 */

const {
  Account,
  Vehicle,
  ItemTemplate,
  PlayerItem,
  PlayerWeapon,
  PlayerOutfit
} = require('./models');

// ------------------------------------------------------
// Hilfsfunktionen
// ------------------------------------------------------

function normalizeMeta(meta) {
  if (!meta) return null;
  if (typeof meta === 'object') return meta;
  if (typeof meta === 'string') {
    try { return JSON.parse(meta); } catch (e) { return { raw: meta }; }
  }
  return { value: meta };
}

/**
 * Account anhand Socialclub holen/erstellen.
 * Ergebnis: player.accountId wird gesetzt.
 */
async function ensureAccount(player) {
  const socialclub = player.socialClub || player.socialclub || player.name;

  if (!socialclub) {
    throw new Error('Kein Socialclub auf Player gefunden');
  }

  if (player.accountId) {
    const existing = await Account.findByPk(player.accountId);
    if (existing) return existing;
  }

  let account = await Account.findOne({ where: { socialclub } });

  if (!account) {
    // Falls deine rp_accounts zusätzliche NOT NULL Felder ohne Default haben,
    // müssen sie hier ergänzt werden.
    account = await Account.create({
      socialclub,
      last_pos_x: 0,
      last_pos_y: 0,
      last_pos_z: 72,
      last_dimension: 0
    });
  }

  player.accountId = account.id;
  return account;
}

/**
 * Serverseitige Player-State-Struktur initialisieren und zurückgeben.
 * Wir hängen NICHT direkt an player.inventory / player.weapons,
 * um keine readonly-Properties von RAGE:MP zu überschreiben.
 */
function getState(player) {
  if (!player._rpState) {
    player._rpState = {
      inventory: [],    // [{templateId, amount, meta, slot, dbId}]
      weapons: [],      // [{hash, ammo, isEquipped, dbId}]
      outfit: {         // {components, props, model, dbId}
        components: null,
        props: null,
        model: null,
        dbId: null
      }
    };
  } else {
    if (!player._rpState.inventory) player._rpState.inventory = [];
    if (!player._rpState.weapons) player._rpState.weapons = [];
    if (!player._rpState.outfit) {
      player._rpState.outfit = { components: null, props: null, model: null, dbId: null };
    }
  }
  return player._rpState;
}

// ------------------------------------------------------
// Laden aus der DB beim Login / Join
// ------------------------------------------------------

/**
 * Spieler-Komplettdaten aus DB laden:
 * - Account
 * - Items (rp_player_items + rp_item_templates)
 * - Waffen (rp_player_weapons)
 * - Outfit (rp_player_outfits)
 * und auf player-Objekt spiegeln.
 */
async function loadPlayerFull(player) {
  const account = await ensureAccount(player);
  const state = getState(player);

  // PlayerItems laden
  const items = await PlayerItem.findAll({
    where: { owner_id: account.id },
    include: [{ model: ItemTemplate, as: 'template', required: false }]
  });

  state.inventory = items.map(it => ({
    dbId: it.id,
    templateId: it.item_template_id,
    amount: it.amount || 1,
    slot: it.slot || 0,
    meta: normalizeMeta(it.meta),
    templateName: it.template ? it.template.name : null,
    templateType: it.template ? it.template.type : null
  }));

  // PlayerWeapons laden
  const weapons = await PlayerWeapon.findAll({
    where: { owner_id: account.id }
  });

  state.weapons = weapons.map(w => ({
    dbId: w.id,
    hash: w.weapon_hash,
    ammo: w.ammo || 0,
    isEquipped: w.is_equipped !== undefined ? w.is_equipped : true
  }));

  // Outfits: wir laden einfach das erste Outfit als "current"
  const outfit = await PlayerOutfit.findOne({
    where: { owner_id: account.id }
  });

  if (outfit) {
    state.outfit = {
      dbId: outfit.id,
      components: outfit.components || null,
      props: outfit.props || null,
      model: outfit.model || null
    };
  } else {
    state.outfit = {
      dbId: null,
      components: null,
      props: null,
      model: null
    };
  }

  // Waffen serverseitig geben
  try {
    if (typeof player.removeAllWeapons === 'function') {
      player.removeAllWeapons();
    }
  } catch (e) {
    // ältere RAGE:MP-Versionen – ignorieren
  }

  for (const w of state.weapons) {
    try {
      if (typeof player.giveWeapon === 'function') {
        player.giveWeapon(w.hash, w.ammo);
      }
    } catch (e) {
      // falscher Hash o.Ä. – ignorieren
    }
  }
}

// ------------------------------------------------------
// Speichern einzelner Bereiche
// ------------------------------------------------------

/**
 * Position & Dimension in Account speichern.
 */
async function savePositionAndDimension(player) {
  const account = await ensureAccount(player);
  const pos = player.position;
  const dim = player.dimension || 0;

  if (!pos) return;

  await account.update({
    last_pos_x: pos.x || 0,
    last_pos_y: pos.y || 0,
    last_pos_z: pos.z || 0,
    last_dimension: dim
  });
}

/**
 * Inventar speichern:
 * - alle bisherigen Einträge des Spielers löschen
 * - aktuellen Zustand state.inventory in rp_player_items schreiben
 */
async function saveInventory(player) {
  const account = await ensureAccount(player);
  const state = getState(player);

  await PlayerItem.destroy({ where: { owner_id: account.id } });

  const inv = state.inventory || [];
  for (const item of inv) {
    await PlayerItem.create({
      owner_id: account.id,
      item_template_id: item.templateId,
      amount: item.amount || 1,
      slot: item.slot || 0,
      meta: normalizeMeta(item.meta)
    });
  }
}

/**
 * Waffen speichern:
 * - alle bisherigen Waffen des Spielers löschen
 * - aktuellen Zustand state.weapons in rp_player_weapons schreiben
 */
async function saveWeapons(player) {
  const account = await ensureAccount(player);
  const state = getState(player);

  await PlayerWeapon.destroy({ where: { owner_id: account.id } });

  const weapons = state.weapons || [];
  for (const w of weapons) {
    await PlayerWeapon.create({
      owner_id: account.id,
      weapon_hash: w.hash,
      ammo: w.ammo || 0,
      is_equipped: w.isEquipped !== undefined ? !!w.isEquipped : true
    });
  }
}

/**
 * Outfit speichern:
 * Wird auch nach außen exportiert (für andere Scripts).
 */
async function saveOutfit(player, outfitData) {
  const account = await ensureAccount(player);
  const state = getState(player);

  const data = outfitData || state.outfit || {};
  const payload = {
    owner_id: account.id,
    components: data.components || null,
    props: data.props || null,
    model: data.model || null
  };

  if (data.dbId) {
    const existing = await PlayerOutfit.findByPk(data.dbId);
    if (existing) {
      await existing.update(payload);
      state.outfit.dbId = existing.id;
      return existing;
    }
  }

  const created = await PlayerOutfit.create(payload);
  state.outfit.dbId = created.id;
  return created;
}

/**
 * Komplettsave: Position, Inventar, Waffen, Outfit.
 */
async function savePlayerFull(player) {
  if (!player || !player.handle) return;
  try {
    await ensureAccount(player);
    await Promise.all([
      savePositionAndDimension(player),
      saveInventory(player),
      saveWeapons(player),
      saveOutfit(player)
    ]);
  } catch (e) {
    console.log('Fehler in savePlayerFull:', e);
  }
}

// ------------------------------------------------------
// High-Level-API für Items & Waffen (Admin + Gameplay)
// ------------------------------------------------------

/**
 * Item geben:
 * - templateIdentifier: Name des ItemTemplates (z.B. 'bread') → ItemTemplate.name
 * - amount: Menge
 * - meta: optionales Meta (Objekt oder JSON-String)
 * Speichert sofort in DB und in state.inventory.
 */
async function givePlayerItem(player, templateIdentifier, amount = 1, meta = null, slot = 0) {
  const account = await ensureAccount(player);
  const state = getState(player);

  const template = await ItemTemplate.findOne({ where: { name: templateIdentifier } });
  if (!template) {
    throw new Error(`ItemTemplate "${templateIdentifier}" nicht gefunden`);
  }

  const qty = parseInt(amount, 10) || 1;
  if (qty <= 0) {
    throw new Error('Menge muss > 0 sein');
  }

  const created = await PlayerItem.create({
    owner_id: account.id,
    item_template_id: template.id,
    amount: qty,
    slot,
    meta: normalizeMeta(meta)
  });

  state.inventory.push({
    dbId: created.id,
    templateId: template.id,
    amount: qty,
    slot,
    meta: normalizeMeta(meta),
    templateName: template.name,
    templateType: template.type
  });

  await saveInventory(player);
}

/**
 * Item entfernen:
 * - entfernt „amount“ Stacks des Templates beim Spieler
 */
async function removePlayerItem(player, templateIdentifier, amount = 1) {
  const account = await ensureAccount(player);
  const state = getState(player);

  const template = await ItemTemplate.findOne({ where: { name: templateIdentifier } });
  if (!template) {
    throw new Error(`ItemTemplate "${templateIdentifier}" nicht gefunden`);
  }

  const qty = parseInt(amount, 10) || 1;
  if (qty <= 0) return;

  for (let i = 0; i < qty; i++) {
    const index = state.inventory.findIndex(it => it.templateId === template.id);
    if (index === -1) break;

    const invItem = state.inventory[index];
    if (invItem.dbId) {
      await PlayerItem.destroy({ where: { id: invItem.dbId, owner_id: account.id } });
    }
    state.inventory.splice(index, 1);
  }

  await saveInventory(player);
}

/**
 * Waffe geben:
 * - weaponName: z.B. 'WEAPON_PISTOL'
 * - ammo: Munitionsmenge
 * Speichert sofort PlayerWeapon + gibt Waffe im Spiel.
 */
async function givePlayerWeapon(player, weaponName, ammo = 0) {
  const account = await ensureAccount(player);
  const state = getState(player);

  const qty = parseInt(ammo, 10) || 0;
  const hash = mp.joaat(weaponName);

  await PlayerWeapon.create({
    owner_id: account.id,
    weapon_hash: hash,
    ammo: qty,
    is_equipped: true
  });

  state.weapons.push({
    dbId: null,
    hash,
    ammo: qty,
    isEquipped: true
  });

  try {
    if (typeof player.giveWeapon === 'function') {
      player.giveWeapon(hash, qty);
    }
  } catch (e) {
    console.log('Fehler bei giveWeapon:', e);
  }

  await saveWeapons(player);
}

/**
 * Entfernt eine Waffe dauerhaft:
 * - aus rp_player_weapons
 * - aus dem In-Memory-State (state.weapons)
 * - optional direkt vom Spieler
 */
async function removePlayerWeapon(player, weaponHash, removeFromPed = false) {
  const account = await ensureAccount(player);
  const state = getState(player);

  const hash = parseInt(weaponHash, 10) || 0;
  if (!hash) return false;

  await PlayerWeapon.destroy({
    where: { owner_id: account.id, weapon_hash: hash }
  });

  state.weapons = (state.weapons || []).filter(w => (parseInt(w.hash, 10) || 0) !== hash);

  if (removeFromPed) {
    try {
      if (typeof player.removeWeapon === 'function') player.removeWeapon(hash);
    } catch (e) {}
  }

  await saveWeapons(player);
  return true;
}

/**
 * Munition zu einer vorhandenen Waffe addieren (RageMP 1.1 kompatibel):
 * - aktualisiert In-Memory-State (state.weapons)
 * - gibt die Waffe serverseitig erneut mit neuer Ammo (überschreibt Ammo korrekt)
 * - speichert rp_player_weapons
 *
 * Hinweis: RageMP 1.1 kann Ammo/Attachments NICHT zuverlässig clientseitig setzen.
 */
async function addAmmoToWeapon(player, weaponHash, addAmount = 0) {
  const account = await ensureAccount(player);
  const state = getState(player);

  const hash = parseInt(weaponHash, 10) || 0;
  const add = parseInt(addAmount, 10) || 0;
  if (!hash || add <= 0) return false;

  if (!Array.isArray(state.weapons)) state.weapons = [];

  let entry = state.weapons.find(w => (parseInt(w.hash, 10) || 0) === hash);
  if (!entry) {
    // Wenn die Waffe (noch) nicht im State ist, legen wir sie an.
    entry = { dbId: null, hash, ammo: 0, isEquipped: true };
    state.weapons.push(entry);
  }

  entry.ammo = (parseInt(entry.ammo, 10) || 0) + add;
  if (entry.ammo < 0) entry.ammo = 0;

  try {
    // "giveWeapon" überschreibt Ammo für diese Waffe auf dem Client zuverlässig (server-autoritätlich).
    if (typeof player.giveWeapon === 'function') player.giveWeapon(hash, entry.ammo);
  } catch (e) {}

  await saveWeapons(player);
  return true;
}

/**
 * Ammo-State regelmäßig nachführen (optional):
 * - bei jedem Schuss versuchen wir serverseitig die Ammo auszulesen
 * - funktioniert nur, wenn player.getAmmo(...) in deinem Build existiert
 */
mp.events.add('playerWeaponShot', (player, targetPosition, targetEntity) => {
  try {
    if (!player) return;
    if (typeof player.getAmmo !== 'function') return;

    const state = getState(player);
    if (!Array.isArray(state.weapons)) state.weapons = [];

    const hash = parseInt(player.weapon, 10) || 0;
    if (!hash) return;

    const ammoNow = parseInt(player.getAmmo(hash), 10);
    if (!Number.isFinite(ammoNow)) return;

    let entry = state.weapons.find(w => (parseInt(w.hash, 10) || 0) === hash);
    if (!entry) {
      entry = { dbId: null, hash, ammo: ammoNow, isEquipped: true };
      state.weapons.push(entry);
    } else {
      entry.ammo = ammoNow;
    }
  } catch (e) {}
});

// Event, damit andere Scripts (z.B. Weaponshop) nur mp.events.call(...) nutzen müssen.
mp.events.add('PERSISTENCE:AddAmmo', (player, weaponHash, addAmount) => {
  addAmmoToWeapon(player, weaponHash, addAmount).catch(() => {});
});
// ------------------------------------------------------
// Events für „bei jeder Änderung speichern“
// ------------------------------------------------------

/**
 * Diese Events kannst du aus ALLEN anderen Server-Scripten aufrufen,
 * sobald sich etwas ändert. Dann wird sofort gespeichert.
 *
 * Beispiele:
 *   mp.events.call('PERSISTENCE:SaveInventory', player, serverInventoryArray);
 *   mp.events.call('PERSISTENCE:SaveWeapons', player, serverWeaponsArray);
 *   mp.events.call('PERSISTENCE:SaveOutfit', player, outfitData);
 *   mp.events.call('PERSISTENCE:SavePosition', player);
 */

mp.events.add('PERSISTENCE:SaveInventory', (player, inventoryData) => {
  try {
    const state = getState(player);
    if (Array.isArray(inventoryData)) {
      state.inventory = inventoryData;
    }
    saveInventory(player).catch(e => console.log('Fehler SaveInventory:', e));
  } catch (e) {
    console.log('Fehler PERSISTENCE:SaveInventory:', e);
  }
});

mp.events.add('PERSISTENCE:SaveWeapons', (player, weaponsData) => {
  try {
    const state = getState(player);
    if (Array.isArray(weaponsData)) {
      state.weapons = weaponsData;
    }
    saveWeapons(player).catch(e => console.log('Fehler SaveWeapons:', e));
  } catch (e) {
    console.log('Fehler PERSISTENCE:SaveWeapons:', e);
  }
});

mp.events.add('PERSISTENCE:SaveOutfit', (player, outfitData) => {
  try {
    const state = getState(player);
    if (outfitData) {
      state.outfit = outfitData;
    }
    saveOutfit(player, outfitData).catch(e => console.log('Fehler SaveOutfit:', e));
  } catch (e) {
    console.log('Fehler PERSISTENCE:SaveOutfit:', e);
  }
});

mp.events.add('PERSISTENCE:SavePosition', (player) => {
  savePositionAndDimension(player).catch(e => console.log('Fehler SavePosition:', e));
});

// ------------------------------------------------------
// Globale Player-Lifecycle Events
// ------------------------------------------------------

/**
 * Beim Ready:
 * - Account anlegen/finden
 * - Inventar, Waffen, Outfit laden
 */
mp.events.add('playerReady', async (player) => {
  try {
    await loadPlayerFull(player);
  } catch (e) {
    console.log('Fehler bei playerReady (Persistence):', e);
    try {
      player.kick('DB Fehler beim Laden deiner Daten');
    } catch (_) {}
  }
});

/**
 * Beim Quit:
 * - Komplettsave (Position, Inventar, Waffen, Outfit)
 */
mp.events.add('playerQuit', (player) => {
  savePlayerFull(player).catch(e => console.log('Fehler savePlayerFull (quit):', e));
});

/**
 * Optional: Autosave alle 60 Sekunden für alle Spieler mit accountId.
 * Wenn du wirklich NUR bei Änderungen speichern willst, kannst du das hier entfernen.
 */
setInterval(() => {
  mp.players.forEach(p => {
    if (p && p.accountId) {
      savePlayerFull(p);
    }
  });
}, 60000);

// ------------------------------------------------------
// Exports für andere Module (z.B. Admin-Items)
// ------------------------------------------------------

module.exports = {
  savePlayerFull,
  saveOutfit,
  givePlayerItem,
  removePlayerItem,
  givePlayerWeapon,
  removePlayerWeapon,
  addAmmoToWeapon
};


mp.events.add("character:loaded", (player) => {
  const state = player._rpState;
  const outfit = state?.outfit;
  if (!outfit) return;

  const components = outfit.components || {};
  const props = outfit.props || {};

  // Komponenten
  for (const key of Object.keys(components)) {
    const c = components[key];
    const componentId = Number(key);
    const drawable = Number(c.drawable);
    const texture = Number(c.texture);
    if (Number.isFinite(componentId) && Number.isFinite(drawable) && Number.isFinite(texture)) {
      player.setClothes(componentId, drawable, texture, 0);
    }
  }

  // Props (drawable -1 = none)
  for (const key of Object.keys(props)) {
    const p = props[key];
    const propId = Number(key);
    const drawable = Number(p.drawable);
    const texture = Number(p.texture);
    if (!Number.isFinite(propId) || !Number.isFinite(drawable)) continue;

    if (drawable === -1) player.setProp(propId, -1, 0);
    else player.setProp(propId, drawable, Number.isFinite(texture) ? texture : 0);
  }
});

