// packages/Gamemode/Database/index.js
// Zentrales DB-Modul für Admin & andere Server-Skripte.

// Stellt die Sequelize-Instanz und wichtige Models bereit.
// Admin-Script erwartet z.B. db.Character.

require('../sequelize'); // setzt global.sequelize und global.seq

const sequelize = global.sequelize;
const seq = global.seq;

if (!sequelize || !seq) {
    console.log('[Database] WARNUNG: Sequelize ist nicht initialisiert. Prüfe sequelize.js.');
}

// Kern-Models laden
const Character = require('../models/character.model');

// Weitere Models können bei Bedarf hier ergänzt werden, z.B.:
// const Account   = require('../models/account.model');
// const Vehicle   = require('../models/vehicle.model');
// ...

module.exports = {
    sequelize,
    seq,
    Character,
    // Account,
    // Vehicle,
};
