// packages/Gamemode/Database/models/PdMember.js

const sequelize = global.sequelize;
const seq = global.seq;

if (!sequelize || !seq) {
    console.log('[PD] WARNUNG: Sequelize ist nicht initialisiert (global.sequelize/global.seq fehlt).');
}

const PdMember = sequelize.define('pd_members', {
    id: {
        type: seq.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    socialclub: {
        type: seq.STRING(64),
        allowNull: false,
        unique: true
    },
    pd_rank: {
        type: seq.STRING(16),
        allowNull: false
    }
}, {
    tableName: 'pd_members',
    timestamps: false
});

PdMember.sync()
    .then(function () { console.log('[PD] Tabelle pd_members bereit (Sequelize).'); })
    .catch(function (err) { console.log('[PD] Fehler beim Sync von pd_members:', err); });

module.exports = PdMember;
