const { Op, DataTypes } = require("sequelize");

const sequelize = global.sequelize;
if (!sequelize) throw new Error("global.sequelize ist nicht gesetzt (sequelize.js muss vorher geladen werden).");

const AdminBan = sequelize.define("admin_bans", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  player_name: { type: DataTypes.STRING(64), allowNull: false },
  socialclub: { type: DataTypes.STRING(64), allowNull: false },
  reason: { type: DataTypes.STRING(255), allowNull: false },
  admin_name: { type: DataTypes.STRING(64), allowNull: false },
  ban_until: { type: DataTypes.DATE, allowNull: true }
}, {
  timestamps: true,
  createdAt: "created_at",
  updatedAt: false
});

module.exports = {
  async ban({ player, sc, reason, admin, until }) {
    await AdminBan.create({
      player_name: player,
      socialclub: sc,
      reason,
      admin_name: admin,
      ban_until: until
    });
  },

  async active(sc) {
    return await AdminBan.findOne({
      where: {
        socialclub: sc,
        [Op.or]: [{ ban_until: null }, { ban_until: { [Op.gt]: new Date() } }]
      },
      order: [["id", "DESC"]]
    });
  },

  async unban(sc) {
    await AdminBan.destroy({ where: { socialclub: sc } });
  }
};
