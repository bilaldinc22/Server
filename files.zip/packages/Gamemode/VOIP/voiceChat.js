mp.events.add("add_voice_listener", (player, target) =>
{
	if(target)
	{
		player.enableVoiceTo(target);
	}
});

mp.events.add("remove_voice_listener", (player, target) =>
{
	if(target)
	{	
		player.disableVoiceTo(target);
	}
});

mp.events.add('SERVER:SET:VOICE:STATE', (player, state) => {
	switch(state) {
		case 1: 
		{
			player.setVariable('istalking', 1);
			break;
		}
		case 2: 
		{
			player.setVariable('istalking', 0);
			break;
		}
	}
});