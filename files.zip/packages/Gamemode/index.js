require('./sequelize');


//A
require("./Authorization/authorization");
require("./admin/AdminActions");
require("./admin/AdminEvents");
require("./admin/AdminLogger");
require("./admin/AdminPanel");
require("./admin/AdminPanelData");
require("./admin/AdminPanelLifecycle");
require("./admin/AdminPermissions");
require("./admin/AdminUtil");
require("./admin/index");
require("./admin/permissions");
require("./BanRepository");
require("./admin/db/AdminSpawnedVehicle.model");
require("./admin/db/AdminSpawnedVehicleRepository");
require("./dbid_autofix.js");
require('./admin/giveveh');

//B
require("./Bank/bank");
require("./Bank/atm");

//C
require("./Character/character");
require("./colors");


//F
require("./Factions/factions");
require("./Factions/pd");




//I
require("./Inventory/item");
require('./Inventory/inventory.controller');
require('./Inventory/inventory.service');


// P
require("./Player/chat");
require("./Player/commands");
require("./PropertySystem/house")



//U
require("./updatePlayer");

//V
require("./VOIP/voiceChat");


require("./AirportRental/rental");
require("./garage/index");
require("./garage/garages");

require("./syncedComponents");
require("./exampleCommands");