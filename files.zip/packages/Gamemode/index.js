require('./sequelize');


//A
require("./Authorization/authorization");
require("./admin/AdminActions");
require("./admin/AdminLogger");
require("./admin/AdminPermissions");
require("./admin/AdminUtil");
require("./admin/index");
require("./admin/permissions");
require("./admin/db/BanRepository");
require("./admin/db/AdminSpawnedVehicle.model");
require("./admin/db/AdminSpawnedVehicleRepository");
require("./admin/db/Ban.model");
require("./dbid_autofix.js");
require('./admin/giveveh');
require('./admin/admin.commands');
//B
require("./Bank/bank");
require("./Bank/atm");

//C
require("./Character/character");
require("./colors");


//F
require("./Factions/factions");
require("./Factions/pd");




//I;
require("./Inventory/item");
require('./Inventory/inventory.controller');
require('./Inventory/inventory.service');
require('./Inventory/inventory.use');
require('./Inventory/useItem.clothing');
require('./Inventory/weapon.map');
require('./Inventory/weapon.persistence');
require('./Inventory/weapon.tracker');

// P
require("./Player/chat");
require("./Player/commands");
require("./PropertySystem/house")
require('./persistence');


//U
require("./updatePlayer");

//V
require("./VOIP/voiceChat");

//W
require("./weaponshop/index");
require("./1weaponcomponents/index");


require("./AirportRental/rental");
require("./Hud/moneyhud");