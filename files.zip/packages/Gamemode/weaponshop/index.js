// Server: nur Geld/Checks + Waffen geben.
// Ammo + Attachments: server calls client event if supported; client also can apply locally for testing.

mp.events.add("weaponshop:buyWeapon", (player, weaponHash, price) => {
    if (player.money < price) return player.outputChatBox("~r~Nicht genug Geld.");
    player.money -= price;
    player.giveWeapon(weaponHash, 100);
    player.outputChatBox("~g~Waffe gekauft.");
});

mp.events.add("weaponshop:buyAmmo", (player, amount, price) => {
    if (player.money < price) return player.outputChatBox("~r~Nicht genug Geld.");
    if (!player.weapon) return player.outputChatBox("~r~Keine Waffe ausgerüstet.");
    player.money -= price;

    // Try to apply on client (if supported by your build)
    try { player.call("weaponshop:applyAmmo", [amount]); } catch (e) {}

    player.outputChatBox("~g~Munition gekauft.");
});

mp.events.add("weaponshop:buyAttachment", (player, componentHash, price) => {
    if (player.money < price) return player.outputChatBox("~r~Nicht genug Geld.");
    if (!player.weapon) return player.outputChatBox("~r~Keine Waffe ausgerüstet.");
    player.money -= price;

    try { player.call("weaponshop:applyAttachment", [componentHash]); } catch (e) {}

    player.outputChatBox("~g~Anbauteil angebracht.");
});
