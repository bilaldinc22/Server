const logger = require('../Logger/discord');

const Characters = require('../models/character.model');
const BankTransaction = require('../models/bank_transaction.model');

const BankAccount = require('../models/bank_account.model');
const BankAccountMember = require('../models/bank_account_member.model');
const BankInvoice = require('../models/bank_invoice.model');
const BankStandingOrder = require('../models/bank_standing_order.model');
const BankLedger = require('../models/bank_ledger.model');

const BANK_LOCATIONS = [
  // Fleeca / Small banks (exteriors)
  { name: 'Fleeca Bank (Legion)',  pos: new mp.Vector3(150.10, -1040.20, 29.30), dim: 0, radius: 1.6 },
  { name: 'Fleeca Bank (Del Perro)', pos: new mp.Vector3(-1212.98, -330.84, 37.78), dim: 0, radius: 1.6 },
  { name: 'Fleeca Bank (Great Ocean)', pos: new mp.Vector3(-2962.59, 482.19, 15.70), dim: 0, radius: 1.6 },
  { name: 'Fleeca Bank (Paleto)', pos: new mp.Vector3(-112.00, 6469.00, 31.60), dim: 0, radius: 1.6 },
  { name: 'Fleeca Bank (Hawick/Alta)', pos: new mp.Vector3(314.20, -278.80, 54.20), dim: 0, radius: 1.6 },

  // State bank / interior entrance (keep your original if you use it)
  { name: 'Los Santos Bank (State)', pos: new mp.Vector3(241.1140, 224.9760, 106.2869), dim: 0, radius: 1.2 },
];

const ATM_WITHDRAW_PIN_THRESHOLD = 5000;
const BANK_WITHDRAW_PIN_THRESHOLD = 10000;
const TRANSFER_PIN_THRESHOLD = 5000;

// ATM behavior
const ATM_FEE_PERCENT = 1.5; // percent of withdraw amount
const ATM_FEE_MIN = 5;
const ATM_FEE_MAX = 5000;

const MAX_AMOUNT = 50_000_000;

const RATE = new Map(); // player.id -> {k:ts}
function rateLimit(player, key, ms){
  const now = Date.now();
  const m = RATE.get(player.id) || {};
  if (m[key] && (now - m[key]) < ms) return false;
  m[key] = now;
  RATE.set(player.id, m);
  return true;
}

function isDigits(s){ return typeof s === 'string' && /^[0-9]+$/.test(s); }
function parseAmount(v){
  const n = parseInt(v, 10);
  if (!Number.isFinite(n) || isNaN(n)) return null;
  if (n <= 0 || n > MAX_AMOUNT) return null;
  return n;
}

function randomDigits(len){
  let out = '';
  for (let i=0;i<len;i++) out += Math.floor(Math.random()*10).toString();
  return out;
}

async function generateUniqueIban(){
  // simple deterministic-like format: LS + 2 digits + 14 digits
  for (let i=0;i<50;i++){
    const iban = 'LS' + randomDigits(2) + randomDigits(14);
    const existsChar = await Characters.findOne({ where: { bank_iban: iban }});
    const existsAcc = await BankAccount.findOne({ where: { iban }});
    if (!existsChar && !existsAcc) return iban;
  }
  return 'LS' + randomDigits(2) + randomDigits(14);
}

async function generateUniqueAccountNumber(){
  for (let i=0;i<50;i++){
    const acc = randomDigits(10);
    const existsChar = await Characters.findOne({ where: { bank_account_number: acc }});
    const existsAcc = await BankAccount.findOne({ where: { account_number: acc }});
    if (!existsChar && !existsAcc) return acc;
  }
  return randomDigits(10);
}

function hashPin(pin, salt){
  const crypto = require('crypto');
  return crypto.createHash('sha256').update(`${salt}:${pin}`).digest('hex');
}

async function getPlayingCharacter(player){
  const name = player.getVariable('playingCharacter');
  if (!name) return null;
  return Characters.findOne({ where: { character_name: name }});
}

async function ensurePersonalBankIdentity(character){
  if (!character.bank_iban) character.bank_iban = await generateUniqueIban();
  if (!character.bank_account_number) character.bank_account_number = await generateUniqueAccountNumber();
  if (!character.bank_locked_until) character.bank_locked_until = 0;
  await character.save();
}

async function resolveIbanOrAccount(target){
  const t = (target || '').toString().trim();
  if (!t) return null;
  // Try exact match
  const byIbanChar = await Characters.findOne({ where: { bank_iban: t }});
  if (byIbanChar) return { type: 'personal', iban: byIbanChar.bank_iban, character: byIbanChar };

  const byAccChar = await Characters.findOne({ where: { bank_account_number: t }});
  if (byAccChar) return { type: 'personal', iban: byAccChar.bank_iban, character: byAccChar };

  const byIbanAcc = await BankAccount.findOne({ where: { iban: t }});
  if (byIbanAcc) return { type: 'company', iban: byIbanAcc.iban, account: byIbanAcc };

  const byAccAcc = await BankAccount.findOne({ where: { account_number: t }});
  if (byAccAcc) return { type: 'company', iban: byAccAcc.iban, account: byAccAcc };

  return null;
}

async function getActiveAccountContext(player, character){
  const activeIban = player.getVariable('active_bank_iban') || character.bank_iban;
  // personal
  if (activeIban === character.bank_iban) {
    return { kind: 'personal', iban: character.bank_iban, balance: character.bank_money, role: 'owner' };
  }

  const account = await BankAccount.findOne({ where: { iban: activeIban, is_closed: false }});
  if (!account) return { kind: 'personal', iban: character.bank_iban, balance: character.bank_money, role: 'owner' };

  const member = await BankAccountMember.findOne({ where: { account_iban: activeIban, character_id: character.character_id }});
  if (!member) return { kind: 'personal', iban: character.bank_iban, balance: character.bank_money, role: 'owner' };

  return { kind: 'company', iban: activeIban, balance: account.balance, role: member.role, account };
}

function canManageCompany(role){ return role === 'owner' || role === 'treasurer'; }
function canOwner(role){ return role === 'owner'; }

async function ledgerAdd(iban, type, amount, balanceBefore, balanceAfter, info, meta){
  try {
    await BankLedger.create({ iban, type, amount, balance_before: balanceBefore, balance_after: balanceAfter, info: info || '', meta: meta || {} });
  } catch(e) {
    try { logger.sendlog('server_logs', `[Bank] ledger insert failed: ${e}`); } catch(_) {}
  }
}

async function txLogCharacter(characterName, type, amount, pocketBefore, pocketAfter, bankBefore, bankAfter, meta){
  try {
    await BankTransaction.create({
      character_name: characterName,
      type,
      amount,
      pocket_before: pocketBefore,
      pocket_after: pocketAfter,
      bank_before: bankBefore,
      bank_after: bankAfter,
      meta: meta || {}
    });
  } catch(e) {
    try { logger.sendlog('server_logs', `[Bank] bank_transactions insert failed: ${e}`); } catch(_) {}
  }
}

async function sendUIData(player){
  try {
    const character = await getPlayingCharacter(player);
    if (!character) return;

    await ensurePersonalBankIdentity(character);

    // Build accounts list: personal + company memberships
    const accounts = [];
    accounts.push({
      iban: character.bank_iban,
      name: character.character_name,
      type: 'personal',
      balance: Number(character.bank_money || 0),
      role: 'owner'
    });

    const memberships = await BankAccountMember.findAll({ where: { character_id: character.character_id }});
    const memberIbans = memberships.map(m => m.account_iban);
    if (memberIbans.length){
      const companyAccounts = await BankAccount.findAll({ where: { iban: memberIbans, is_closed: false }});
      for (const acc of companyAccounts){
        const m = memberships.find(x => x.account_iban === acc.iban);
        accounts.push({
          iban: acc.iban,
          name: acc.name,
          type: acc.type,
          balance: Number(acc.balance || 0),
          role: m ? m.role : 'member'
        });
      }
    }

    const activeIban = player.getVariable('active_bank_iban') || character.bank_iban;
    if (!accounts.some(a => a.iban === activeIban)) player.setVariable('active_bank_iban', character.bank_iban);

    // invoices
    const invoicesInDb = await BankInvoice.findAll({ where: { to_iban: character.bank_iban }, order: [['created_at','DESC']], limit: 30 });
    const invoicesOutDb = await BankInvoice.findAll({ where: { from_iban: character.bank_iban }, order: [['created_at','DESC']], limit: 30 });

    // standing orders: only from personal (keeps it simple; company standing orders can be added later)
    const soDb = await BankStandingOrder.findAll({ where: { from_iban: activeIban }, order: [['created_at','DESC']], limit: 30 });

    // company members for accounts you manage
    const companyMembers = {};
    for (const a of accounts.filter(x => x.type !== 'personal')){
      if (!canManageCompany(a.role)) continue;
      const rows = await BankAccountMember.findAll({ where: { account_iban: a.iban }});
      const memberCharIds = rows.map(r => r.character_id);
      const chars = memberCharIds.length ? await Characters.findAll({ where: { character_id: memberCharIds }}) : [];
      companyMembers[a.iban] = rows.map(r => {
        const ch = chars.find(c => c.character_id === r.character_id);
        return { character_id: r.character_id, character_name: ch ? ch.character_name : `#${r.character_id}`, role: r.role };
      });
    }

    // history
    const hist = await BankLedger.findAll({ where: { iban: activeIban }, order: [['created_at','DESC']], limit: 40 });
    const history = hist.map(h => ({
      date: new Date(h.created_at).toLocaleString('de-DE'),
      type: h.type,
      amount: Number(h.amount || 0),
      info: h.info || ''
    }));

    const where = player.getVariable('bank_context') || 'BANK';
    const restrictions = where === 'ATM'
      ? {
          hiddenPanels: ['transfer', 'company', 'invoices', 'standing', 'security'],
          disableDeposit: true,
          atmFeePercent: ATM_FEE_PERCENT
        }
      : { hiddenPanels: [], disableDeposit: false };

    const payload = {
      context: { where, restrictions },
      cash: Number(character.pocket_money || 0),
      personal: { iban: character.bank_iban, account: character.bank_account_number },
      accounts,
      activeIban: player.getVariable('active_bank_iban') || character.bank_iban,
      invoicesIn: invoicesInDb.map(x => ({ id: x.invoice_id, from: x.from_iban, amount: Number(x.amount), reason: x.reason, status: x.status })),
      invoicesOut: invoicesOutDb.map(x => ({ id: x.invoice_id, to: x.to_iban, amount: Number(x.amount), reason: x.reason, status: x.status })),
      standingOrders: soDb.map(x => ({ id: x.so_id, target: x.to_iban, amount: Number(x.amount), intervalHours: x.interval_hours, reason: x.reason, enabled: !!x.enabled })),
      companyMembers,
      history,
      security: { hasPin: !!character.bank_pin_hash, lockedUntil: Number(character.bank_locked_until || 0) }
    };

    player.call('CLIENT::BANK:UI_DATA', [JSON.stringify(payload)]);
  } catch (err) {
    try { logger.sendlog('server_logs', `[Bank] sendUIData failed: ${err}`); } catch(_) {}
  }
}

function notify(player, ok, msg){
  player.call('CLIENT::BANK:NOTIFY', [!!ok, msg]);
  sendUIData(player);
}


// Fallback: open bank if player is near any bank location (useful if colshape/marker issues occur)
mp.events.add('SERVER::BANK:OPEN_NEAR', (player) => {
  try {
    const p = player.position;
    for (const b of BANK_LOCATIONS) {
      const dx = p.x - b.pos.x;
      const dy = p.y - b.pos.y;
      const dz = p.z - b.pos.z;
      const dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
      if (dist <= (b.radius || 1.6) + 1.0) {
        player.setVariable('bank_context', 'BANK');
        player.call('CLIENT::OPEN:BANK', ['BANK']);
        return;
      }
    }
  } catch (_) {}
});

// Create bank markers/colshapes
for (const b of BANK_LOCATIONS){
  const shape = mp.colshapes.newSphere(b.pos.x, b.pos.y, b.pos.z, b.radius);
  shape.setVariable('bank', true);
  mp.labels.new(b.name, new mp.Vector3(b.pos.x, b.pos.y, b.pos.z + 1.0), { los: true, font: 0, drawDistance: 10 });
  mp.markers.new(29, b.pos, 0.9, { visible: true, color: [194, 53, 203, 100] });
}

mp.events.add('playerEnterColshape', (player, shape) => {
  if (shape && shape.getVariable('bank') === true){
    player.setVariable('bank_context', 'BANK');
    player.call('CLIENT::OPEN:BANK', ['BANK']);
  }
});

mp.events.add('playerExitColshape', (player, shape) => {
  if (shape && shape.getVariable('bank') === true){
    player.call('CLIENT::CLOSE:BANK');
  }
});

// UI lifecycle
mp.events.add('SERVER::BANK:UI_OPEN', async (player, context) => {
  if (!rateLimit(player, 'ui_open', 300)) return;
  player.setVariable('bank_context', (context === 'ATM') ? 'ATM' : 'BANK');
  await sendUIData(player);
});
mp.events.add('SERVER::BANK:UI_CLOSE', (player) => {
  // no-op currently
});

// Set active account
mp.events.add('SERVER::BANK:SET_ACTIVE', async (player, iban) => {
  if (!rateLimit(player, 'set_active', 250)) return;
  const character = await getPlayingCharacter(player);
  if (!character) return;

  await ensurePersonalBankIdentity(character);

  const requested = (iban || '').toString().trim();
  if (!requested) return notify(player, false, 'Invalid account');

  // allow personal
  if (requested === character.bank_iban){
    player.setVariable('active_bank_iban', character.bank_iban);
    return notify(player, true, 'Active account set');
  }

  // allow membership
  const m = await BankAccountMember.findOne({ where: { account_iban: requested, character_id: character.character_id }});
  if (!m) return notify(player, false, 'No access to this account');

  player.setVariable('active_bank_iban', requested);
  return notify(player, true, 'Active account set');
});

// Deposit / Withdraw / Transfer
mp.events.add('SERVER::DEPOSIT:MONEY', async (player, value) => {
  if (!rateLimit(player, 'deposit', 500)) return;
  const amount = parseAmount(value);
  if (!amount) return notify(player, false, 'Invalid amount');

  const character = await getPlayingCharacter(player);
  if (!character) return;

  await ensurePersonalBankIdentity(character);
  const ctx = await getActiveAccountContext(player, character);

  const where = player.getVariable('bank_context') || 'BANK';
  if (where === 'ATM') return notify(player, false, 'Deposits are not available at ATMs');

  if (character.pocket_money < amount) return notify(player, false, 'Not enough cash');

  // role check for company deposits
  if (ctx.kind === 'company' && !canManageCompany(ctx.role)) return notify(player, false, 'No permission');

  const pocketBefore = Number(character.pocket_money);
  const bankBefore = (ctx.kind === 'personal') ? Number(character.bank_money) : Number(ctx.account.balance);

  character.pocket_money = pocketBefore - amount;

  if (ctx.kind === 'personal'){
    character.bank_money = bankBefore + amount;
    await character.save();
  } else {
    ctx.account.balance = bankBefore + amount;
    await ctx.account.save();
    await character.save();
  }

  await ledgerAdd(ctx.iban, 'DEPOSIT', amount, bankBefore, bankBefore + amount, `Deposit by ${character.character_name}`, { fromCash: true });
  await txLogCharacter(character.character_name, 'DEPOSIT', amount, pocketBefore, pocketBefore - amount, (ctx.kind === 'personal' ? bankBefore : Number(character.bank_money)), (ctx.kind === 'personal' ? bankBefore + amount : Number(character.bank_money)), { account: ctx.iban });

  notify(player, true, `Deposited ${amount}$`);
});

function pinRequired(where, amount, kind){
  if (kind !== 'personal' && kind !== 'company') return false;
  if (where === 'ATM') return amount >= ATM_WITHDRAW_PIN_THRESHOLD;
  // BANK context:
  return amount >= BANK_WITHDRAW_PIN_THRESHOLD;
}

async function verifyPin(character, pin){
  const lockedUntil = Number(character.bank_locked_until || 0);
  if (lockedUntil > Date.now()) return { ok: false, msg: 'Account locked (PIN)' };

  if (!character.bank_pin_hash) return { ok: false, msg: 'No PIN set' };
  if (!isDigits(pin) || pin.length < 4 || pin.length > 8) return { ok: false, msg: 'Invalid PIN' };

  const salt = character.bank_pin_salt || '';
  const h = hashPin(pin, salt);

  if (h !== character.bank_pin_hash){
    // lock after 3 bad attempts within a short time window (simple: store counter in player variable)
    const bad = (character._pin_bad_count || 0) + 1;
    character._pin_bad_count = bad;
    if (bad >= 3){
      character.bank_locked_until = Date.now() + (5 * 60 * 1000);
      character._pin_bad_count = 0;
      await character.save();
      return { ok: false, msg: 'PIN locked for 5 minutes' };
    }
    return { ok: false, msg: 'Wrong PIN' };
  }

  character._pin_bad_count = 0;
  return { ok: true };
}

mp.events.add('SERVER::WITHDRAW:MONEY', async (player, value, pin) => {
  if (!rateLimit(player, 'withdraw', 500)) return;
  const amount = parseAmount(value);
  if (!amount) return notify(player, false, 'Invalid amount');

  const character = await getPlayingCharacter(player);
  if (!character) return;

  await ensurePersonalBankIdentity(character);
  const ctx = await getActiveAccountContext(player, character);

	const where = player.getVariable('bank_context') || 'BANK';
  const needsPin = pinRequired(where, amount, ctx.kind);

  if (needsPin){
    const v = await verifyPin(character, (pin || '').toString());
    if (!v.ok) return notify(player, false, v.msg);
  }

  // permission
  if (ctx.kind === 'company' && !canManageCompany(ctx.role)) return notify(player, false, 'No permission');

  const pocketBefore = Number(character.pocket_money);
  const bankBefore = (ctx.kind === 'personal') ? Number(character.bank_money) : Number(ctx.account.balance);
  const fee = (where === 'ATM') ? Math.min(ATM_FEE_MAX, Math.max(ATM_FEE_MIN, Math.ceil(amount * (ATM_FEE_PERCENT / 100)))) : 0;
  const totalDebit = amount + fee;
  if (bankBefore < totalDebit) return notify(player, false, fee ? `Not enough balance (need ${totalDebit}$ incl. fee)` : 'Not enough balance');

  character.pocket_money = pocketBefore + amount;

  if (ctx.kind === 'personal'){
    character.bank_money = bankBefore - totalDebit;
    await character.save();
  } else {
    ctx.account.balance = bankBefore - totalDebit;
    await ctx.account.save();
    await character.save();
  }

  await ledgerAdd(ctx.iban, 'WITHDRAW', amount, bankBefore, bankBefore - totalDebit, `Withdraw by ${character.character_name}`, { toCash: true, fee });
  if (fee > 0) await ledgerAdd(ctx.iban, 'ATM_FEE', fee, bankBefore - amount, bankBefore - totalDebit, `ATM fee`, { feePercent: ATM_FEE_PERCENT });
  await txLogCharacter(character.character_name, 'WITHDRAW', amount, pocketBefore, pocketBefore + amount, (ctx.kind === 'personal' ? bankBefore : Number(character.bank_money)), (ctx.kind === 'personal' ? bankBefore - totalDebit : Number(character.bank_money)), { account: ctx.iban, fee });

  notify(player, true, fee ? `Withdrew ${amount}$ (fee ${fee}$, debited ${totalDebit}$)` : `Withdrew ${amount}$`);
});

mp.events.add('SERVER::TRANSFER:MONEY', async (player, target, value, pin) => {
  if (!rateLimit(player, 'transfer', 700)) return;
  const amount = parseAmount(value);
  if (!amount) return notify(player, false, 'Invalid amount');

  const character = await getPlayingCharacter(player);
  if (!character) return;

  await ensurePersonalBankIdentity(character);
  const ctx = await getActiveAccountContext(player, character);

  const where = player.getVariable('bank_context') || 'BANK';
  if (where === 'ATM') return notify(player, false, 'Deposits are not available at ATMs');

  // PIN required for larger transfers
  if (amount >= TRANSFER_PIN_THRESHOLD){
    const v = await verifyPin(character, (pin || '').toString());
    if (!v.ok) return notify(player, false, v.msg);
  }

  // permission
  if (ctx.kind === 'company' && !canManageCompany(ctx.role)) return notify(player, false, 'No permission');

  const resolved = await resolveIbanOrAccount(target);
  if (!resolved) return notify(player, false, 'Target not found');

  if (resolved.iban === ctx.iban) return notify(player, false, 'Cannot transfer to same account');

  const fromBefore = (ctx.kind === 'personal') ? Number(character.bank_money) : Number(ctx.account.balance);
  if (fromBefore < amount) return notify(player, false, 'Not enough balance');

  // debit
  if (ctx.kind === 'personal'){
    character.bank_money = fromBefore - amount;
    await character.save();
  } else {
    ctx.account.balance = fromBefore - amount;
    await ctx.account.save();
  }

  // credit
  let toBefore = 0;
  let toAfter = 0;
  if (resolved.type === 'personal'){
    const c = resolved.character;
    await ensurePersonalBankIdentity(c);
    toBefore = Number(c.bank_money);
    c.bank_money = toBefore + amount;
    await c.save();
    toAfter = Number(c.bank_money);
  } else {
    const a = resolved.account;
    toBefore = Number(a.balance);
    a.balance = toBefore + amount;
    await a.save();
    toAfter = Number(a.balance);
  }

  await ledgerAdd(ctx.iban, 'TRANSFER_OUT', amount, fromBefore, fromBefore - amount, `To ${resolved.iban}`, { to: resolved.iban, by: character.character_name });
  await ledgerAdd(resolved.iban, 'TRANSFER_IN', amount, toBefore, toAfter, `From ${ctx.iban}`, { from: ctx.iban, by: character.character_name });

  await txLogCharacter(character.character_name, 'TRANSFER_OUT', amount, Number(character.pocket_money), Number(character.pocket_money), (ctx.kind === 'personal' ? fromBefore : Number(character.bank_money)), (ctx.kind === 'personal' ? fromBefore - amount : Number(character.bank_money)), { to: resolved.iban, from: ctx.iban });

  notify(player, true, `Transferred ${amount}$ to ${resolved.iban}`);
});

// PIN management
mp.events.add('SERVER::BANK:PIN_SET', async (player, newPin) => {
  if (!rateLimit(player, 'pin_set', 800)) return;
  const character = await getPlayingCharacter(player);
  if (!character) return;

  const pin = (newPin || '').toString().trim();
  if (!isDigits(pin) || pin.length < 4 || pin.length > 8) return notify(player, false, 'PIN must be 4-8 digits');

  const crypto = require('crypto');
  const salt = crypto.randomBytes(8).toString('hex');
  character.bank_pin_salt = salt;
  character.bank_pin_hash = hashPin(pin, salt);
  character.bank_locked_until = 0;
  await character.save();

  notify(player, true, 'PIN set');
});

mp.events.add('SERVER::BANK:PIN_CHANGE', async (player, oldPin, newPin) => {
  if (!rateLimit(player, 'pin_change', 800)) return;
  const character = await getPlayingCharacter(player);
  if (!character) return;

  const v = await verifyPin(character, (oldPin || '').toString());
  if (!v.ok) return notify(player, false, v.msg);

  const pin = (newPin || '').toString().trim();
  if (!isDigits(pin) || pin.length < 4 || pin.length > 8) return notify(player, false, 'PIN must be 4-8 digits');

  const crypto = require('crypto');
  const salt = crypto.randomBytes(8).toString('hex');
  character.bank_pin_salt = salt;
  character.bank_pin_hash = hashPin(pin, salt);
  character.bank_locked_until = 0;
  await character.save();

  notify(player, true, 'PIN changed');
});

// Invoices (personal account based)
mp.events.add('SERVER::BANK:INVOICE_CREATE', async (player, target, value, reason) => {
  if (!rateLimit(player, 'inv_create', 700)) return;
  const amount = parseAmount(value);
  if (!amount) return notify(player, false, 'Invalid amount');

  const character = await getPlayingCharacter(player);
  if (!character) return;
  await ensurePersonalBankIdentity(character);

  const resolved = await resolveIbanOrAccount(target);
  if (!resolved) return notify(player, false, 'Target not found');

  if (resolved.iban === character.bank_iban) return notify(player, false, 'Cannot invoice yourself');

  const r = (reason || '').toString().trim().slice(0, 64) || 'Invoice';

  await BankInvoice.create({ from_iban: character.bank_iban, to_iban: resolved.iban, amount, reason: r, status: 'OPEN' });
  notify(player, true, 'Invoice created');
});

mp.events.add('SERVER::BANK:INVOICE_CANCEL', async (player, invoiceId) => {
  if (!rateLimit(player, 'inv_cancel', 700)) return;
  const id = parseInt(invoiceId, 10);
  if (!id) return notify(player, false, 'Invalid invoice');

  const character = await getPlayingCharacter(player);
  if (!character) return;
  await ensurePersonalBankIdentity(character);

  const inv = await BankInvoice.findOne({ where: { invoice_id: id, from_iban: character.bank_iban }});
  if (!inv) return notify(player, false, 'Invoice not found');
  if (inv.status !== 'OPEN') return notify(player, false, 'Invoice not open');

  inv.status = 'CANCELLED';
  await inv.save();
  notify(player, true, 'Invoice cancelled');
});

mp.events.add('SERVER::BANK:INVOICE_PAY', async (player, invoiceId, pin) => {
  if (!rateLimit(player, 'inv_pay', 800)) return;
  const id = parseInt(invoiceId, 10);
  if (!id) return notify(player, false, 'Invalid invoice');

  const character = await getPlayingCharacter(player);
  if (!character) return;
  await ensurePersonalBankIdentity(character);

  const inv = await BankInvoice.findOne({ where: { invoice_id: id, to_iban: character.bank_iban }});
  if (!inv) return notify(player, false, 'Invoice not found');
  if (inv.status !== 'OPEN') return notify(player, false, 'Invoice not open');

  // PIN required if amount large
  if (inv.amount >= TRANSFER_PIN_THRESHOLD){
    const v = await verifyPin(character, (pin || '').toString());
    if (!v.ok) return notify(player, false, v.msg);
  }

  // pay from active account (can be company if permitted)
  const ctx = await getActiveAccountContext(player, character);
  if (ctx.kind === 'company' && !canManageCompany(ctx.role)) return notify(player, false, 'No permission');
  const fromBefore = (ctx.kind === 'personal') ? Number(character.bank_money) : Number(ctx.account.balance);
  if (fromBefore < inv.amount) return notify(player, false, 'Not enough balance');

  // debit payer
  if (ctx.kind === 'personal'){
    character.bank_money = fromBefore - Number(inv.amount);
    await character.save();
  } else {
    ctx.account.balance = fromBefore - Number(inv.amount);
    await ctx.account.save();
  }

  // credit issuer
  const issuer = await resolveIbanOrAccount(inv.from_iban);
  let toBefore = 0;
  let toAfter = 0;
  if (issuer && issuer.type === 'personal'){
    await ensurePersonalBankIdentity(issuer.character);
    toBefore = Number(issuer.character.bank_money);
    issuer.character.bank_money = toBefore + Number(inv.amount);
    await issuer.character.save();
    toAfter = Number(issuer.character.bank_money);
  } else if (issuer && issuer.type === 'company'){
    toBefore = Number(issuer.account.balance);
    issuer.account.balance = toBefore + Number(inv.amount);
    await issuer.account.save();
    toAfter = Number(issuer.account.balance);
  }

  inv.status = 'PAID';
  await inv.save();

  await ledgerAdd(ctx.iban, 'INVOICE_PAY', Number(inv.amount), fromBefore, fromBefore - Number(inv.amount), `Invoice #${inv.invoice_id} to ${inv.from_iban}`, { invoiceId: inv.invoice_id });
  if (issuer) await ledgerAdd(inv.from_iban, 'INVOICE_IN', Number(inv.amount), toBefore, toAfter, `Invoice #${inv.invoice_id} from ${ctx.iban}`, { invoiceId: inv.invoice_id });

  notify(player, true, `Invoice #${inv.invoice_id} paid`);
});

// Standing orders (from active account)
mp.events.add('SERVER::BANK:SO_CREATE', async (player, target, value, intervalHours, reason, pin) => {
  if (!rateLimit(player, 'so_create', 900)) return;
  const amount = parseAmount(value);
  if (!amount) return notify(player, false, 'Invalid amount');

  const interval = parseInt(intervalHours, 10);
  if (!interval || interval < 1 || interval > 24*30) return notify(player, false, 'Invalid interval');

  const character = await getPlayingCharacter(player);
  if (!character) return;
  await ensurePersonalBankIdentity(character);

  const ctx = await getActiveAccountContext(player, character);
  if (ctx.kind === 'company' && !canManageCompany(ctx.role)) return notify(player, false, 'No permission');

  const resolved = await resolveIbanOrAccount(target);
  if (!resolved) return notify(player, false, 'Target not found');
  if (resolved.iban === ctx.iban) return notify(player, false, 'Cannot target same account');

  if (amount >= TRANSFER_PIN_THRESHOLD){
    const v = await verifyPin(character, (pin || '').toString());
    if (!v.ok) return notify(player, false, v.msg);
  }

  const r = (reason || '').toString().trim().slice(0, 64) || 'Standing order';
  const nextRunAt = Date.now() + interval * 3600 * 1000;

  await BankStandingOrder.create({
    from_iban: ctx.iban,
    to_iban: resolved.iban,
    amount,
    interval_hours: interval,
    reason: r,
    enabled: true,
    next_run_at: nextRunAt
  });

  notify(player, true, 'Standing order created');
});

mp.events.add('SERVER::BANK:SO_TOGGLE', async (player, soId, enabled) => {
  if (!rateLimit(player, 'so_toggle', 700)) return;
  const id = parseInt(soId, 10);
  if (!id) return notify(player, false, 'Invalid order');

  const character = await getPlayingCharacter(player);
  if (!character) return;
  await ensurePersonalBankIdentity(character);

  const ctx = await getActiveAccountContext(player, character);
  const so = await BankStandingOrder.findOne({ where: { so_id: id, from_iban: ctx.iban }});
  if (!so) return notify(player, false, 'Order not found');

  so.enabled = !!enabled;
  if (so.enabled && (!so.next_run_at || so.next_run_at < Date.now())) {
    so.next_run_at = Date.now() + Number(so.interval_hours) * 3600 * 1000;
  }
  await so.save();
  notify(player, true, 'Standing order updated');
});

mp.events.add('SERVER::BANK:SO_DELETE', async (player, soId) => {
  if (!rateLimit(player, 'so_delete', 700)) return;
  const id = parseInt(soId, 10);
  if (!id) return notify(player, false, 'Invalid order');

  const character = await getPlayingCharacter(player);
  if (!character) return;
  await ensurePersonalBankIdentity(character);

  const ctx = await getActiveAccountContext(player, character);
  const so = await BankStandingOrder.findOne({ where: { so_id: id, from_iban: ctx.iban }});
  if (!so) return notify(player, false, 'Order not found');

  await so.destroy();
  notify(player, true, 'Standing order deleted');
});

// Company accounts
mp.events.add('SERVER::BANK:COMPANY_CREATE', async (player, name) => {
  if (!rateLimit(player, 'co_create', 1200)) return;

  const character = await getPlayingCharacter(player);
  if (!character) return;
  await ensurePersonalBankIdentity(character);

  const n = (name || '').toString().trim().slice(0, 40);
  if (!n) return notify(player, false, 'Name required');

  const iban = await generateUniqueIban();
  const accNum = await generateUniqueAccountNumber();

  const acc = await BankAccount.create({
    iban,
    account_number: accNum,
    name: n,
    type: 'company',
    balance: 0,
    created_by_character_id: character.character_id
  });

  await BankAccountMember.create({ account_iban: acc.iban, character_id: character.character_id, role: 'owner' });

  notify(player, true, `Company account created: ${acc.iban}`);
});

mp.events.add('SERVER::BANK:COMPANY_MEMBER_ADD', async (player, accountIban, characterName, role) => {
  if (!rateLimit(player, 'co_add', 900)) return;

  const character = await getPlayingCharacter(player);
  if (!character) return;

  const iban = (accountIban || '').toString().trim();
  const targetName = (characterName || '').toString().trim();

  if (!iban || !targetName) return notify(player, false, 'Missing data');

  const acc = await BankAccount.findOne({ where: { iban, is_closed: false }});
  if (!acc) return notify(player, false, 'Account not found');

  const me = await BankAccountMember.findOne({ where: { account_iban: iban, character_id: character.character_id }});
  if (!me || !canManageCompany(me.role)) return notify(player, false, 'No permission');

  const targetChar = await Characters.findOne({ where: { character_name: targetName }});
  if (!targetChar) return notify(player, false, 'Character not found');

  const r = (role || 'member').toString();
  const roleClean = (r === 'owner' || r === 'treasurer') ? r : 'member';

  const exists = await BankAccountMember.findOne({ where: { account_iban: iban, character_id: targetChar.character_id }});
  if (exists) return notify(player, false, 'Already a member');

  await BankAccountMember.create({ account_iban: iban, character_id: targetChar.character_id, role: roleClean });
  notify(player, true, 'Member added');
});

mp.events.add('SERVER::BANK:COMPANY_MEMBER_ROLE', async (player, accountIban, characterId, role) => {
  if (!rateLimit(player, 'co_role', 900)) return;

  const character = await getPlayingCharacter(player);
  if (!character) return;

  const iban = (accountIban || '').toString().trim();
  const cid = parseInt(characterId, 10);
  if (!iban || !cid) return notify(player, false, 'Invalid data');

  const me = await BankAccountMember.findOne({ where: { account_iban: iban, character_id: character.character_id }});
  if (!me || !canOwner(me.role)) return notify(player, false, 'Only owner can change roles');

  const row = await BankAccountMember.findOne({ where: { account_iban: iban, character_id: cid }});
  if (!row) return notify(player, false, 'Member not found');

  const r = (role || 'member').toString();
  const roleClean = (r === 'owner' || r === 'treasurer') ? r : 'member';
  row.role = roleClean;
  await row.save();

  notify(player, true, 'Role updated');
});

mp.events.add('SERVER::BANK:COMPANY_MEMBER_REMOVE', async (player, accountIban, characterId) => {
  if (!rateLimit(player, 'co_rm', 900)) return;

  const character = await getPlayingCharacter(player);
  if (!character) return;

  const iban = (accountIban || '').toString().trim();
  const cid = parseInt(characterId, 10);
  if (!iban || !cid) return notify(player, false, 'Invalid data');

  const me = await BankAccountMember.findOne({ where: { account_iban: iban, character_id: character.character_id }});
  if (!me || !canManageCompany(me.role)) return notify(player, false, 'No permission');

  // owner cannot remove themselves here (avoid orphan)
  if (cid === character.character_id && me.role === 'owner') return notify(player, false, 'Owner cannot remove self');

  const row = await BankAccountMember.findOne({ where: { account_iban: iban, character_id: cid }});
  if (!row) return notify(player, false, 'Member not found');

  await row.destroy();
  notify(player, true, 'Member removed');
});

// Standing order runner (every 30s)
setInterval(async () => {
  try {
    const now = Date.now();
    const due = await BankStandingOrder.findAll({ where: { enabled: true, next_run_at: { [require('sequelize').Op.lte]: now } }, limit: 50 });
    for (const so of due){
      // debit from iban (personal or company)
      const fromIban = so.from_iban;
      const toIban = so.to_iban;
      const amount = Number(so.amount);

      // resolve from
      let fromKind = null;
      let fromBalance = 0;
      let fromSave = async () => {};
      const fromChar = await Characters.findOne({ where: { bank_iban: fromIban }});
      if (fromChar){
        await ensurePersonalBankIdentity(fromChar);
        fromKind = 'personal';
        fromBalance = Number(fromChar.bank_money);
        fromSave = async (newBal) => { fromChar.bank_money = newBal; await fromChar.save(); };
      } else {
        const fromAcc = await BankAccount.findOne({ where: { iban: fromIban, is_closed: false }});
        if (!fromAcc) { so.enabled = false; await so.save(); continue; }
        fromKind = 'company';
        fromBalance = Number(fromAcc.balance);
        fromSave = async (newBal) => { fromAcc.balance = newBal; await fromAcc.save(); };
      }

      if (fromBalance < amount){
        // skip this run; schedule next
        so.next_run_at = now + Number(so.interval_hours) * 3600 * 1000;
        await so.save();
        continue;
      }

      // resolve to
      const resolvedTo = await resolveIbanOrAccount(toIban);
      if (!resolvedTo){
        so.enabled = false;
        await so.save();
        continue;
      }

      // debit
      await fromSave(fromBalance - amount);

      // credit
      let toBefore=0,toAfter=0;
      if (resolvedTo.type === 'personal'){
        const c = resolvedTo.character;
        await ensurePersonalBankIdentity(c);
        toBefore = Number(c.bank_money);
        c.bank_money = toBefore + amount;
        await c.save();
        toAfter = Number(c.bank_money);
      } else {
        const a = resolvedTo.account;
        toBefore = Number(a.balance);
        a.balance = toBefore + amount;
        await a.save();
        toAfter = Number(a.balance);
      }

      await ledgerAdd(fromIban, 'SO_OUT', amount, fromBalance, fromBalance - amount, `Standing order to ${toIban}`, { soId: so.so_id, reason: so.reason });
      await ledgerAdd(toIban, 'SO_IN', amount, toBefore, toAfter, `Standing order from ${fromIban}`, { soId: so.so_id, reason: so.reason });

      so.next_run_at = now + Number(so.interval_hours) * 3600 * 1000;
      await so.save();
    }
  } catch(e) {
    // ignore
  }
}, 30000);


// =========================
// Bank Blips (client-side)
// =========================
const BANK_BLIPS = [
  { name: "Los Santos Bank", pos: { x: 150.1, y: -1040.2, z: 29.3 } },        // Legion/Pillbox area
  { name: "Fleeca Bank", pos: { x: -1212.98, y: -330.84, z: 37.78 } },        // Del Perro
  { name: "Fleeca Bank", pos: { x: -2962.59, y: 482.19, z: 15.7 } },          // Great Ocean Hwy
  { name: "Fleeca Bank", pos: { x: -112.0, y: 6469.0, z: 31.6 } },            // Paleto Bay
  { name: "Fleeca Bank", pos: { x: 314.2, y: -278.8, z: 54.2 } },             // Hawick/Alta
];

mp.events.add("BANK::BLIPS:REQUEST", (player) => {
  try {
    player.call("BANK::BLIPS:SET", [JSON.stringify(BANK_BLIPS)]);
  } catch (e) {}
});
