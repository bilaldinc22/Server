const logger = require('../Logger/discord');

// Recurring payments between IBANs.
// interval: DAILY|WEEKLY|MONTHLY

const BankRecurring = sequelize.define('bank_recurring', {
  recurring_id: { type: seq.BIGINT, autoIncrement: true, primaryKey: true },
  issuer_iban: { type: seq.STRING, allowNull: false },
  target_iban: { type: seq.STRING, allowNull: false },
  amount: { type: seq.BIGINT, allowNull: false },
  reason: { type: seq.STRING, allowNull: false, defaultValue: 'Dauerauftrag' },
  interval: { type: seq.STRING, allowNull: false, defaultValue: 'MONTHLY' },
  next_run_at: { type: seq.BIGINT, allowNull: false },
  is_active: { type: seq.BOOLEAN, allowNull: false, defaultValue: true },
  meta: {
    type: seq.TEXT,
    get: function () { try { return JSON.parse(this.getDataValue('meta') || '{}'); } catch (e) { return {}; } },
    set: function (value) { this.setDataValue('meta', JSON.stringify(value || {})); }
  },
}, {
  timestamps: true,
  underscored: true,
});

(async () => {
  try {
    await BankRecurring.sync();
    console.log('[Bank] bank_recurring synced');
  } catch (err) {
    try { logger.sendlog('server_logs', `[Bank] bank_recurring sync failed: ${err}`); } catch (e) {}
    console.log('[Bank] bank_recurring sync failed', err);
  }
})();

module.exports = BankRecurring;
