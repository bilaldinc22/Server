// packages/Gamemode/models/player_outfit.model.js

module.exports = (sequelize, DataTypes) => {
  return sequelize.define("player_outfits", {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    accountKey: { type: DataTypes.STRING(64), allowNull: false, unique: true },
    components: { type: DataTypes.TEXT("long"), allowNull: false, defaultValue: "{}" },
    props: { type: DataTypes.TEXT("long"), allowNull: false, defaultValue: "{}" }
  }, {
    timestamps: false
  });
};
