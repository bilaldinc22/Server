const logger = require('../Logger/discord');

/**
 * Bank PINs (per character_name)
 * Uses existing global sequelize + seq initialized in packages/Gamemode/sequelize.js
 */

const BankPin = sequelize.define('bank_pins', {
    id: { type: seq.INTEGER, primaryKey: true, autoIncrement: true },
    character_name: { type: seq.STRING(64), allowNull: false, unique: true },
    pin_salt: { type: seq.STRING(64), allowNull: false },
    pin_hash: { type: seq.STRING(128), allowNull: false },
    pin_updated_at: { type: seq.DATE, allowNull: false, defaultValue: seq.NOW },
}, {
    timestamps: false,
    tableName: 'bank_pins',
});

BankPin.sync()
    .then(() => {
        console.log('[DB] bank_pins table synced');
    })
    .catch((err) => {
        try { logger.sendlog('server_logs', `BankPin Sync Failed : ${err}`); } catch (e) {}
        console.log(`[DB] bank_pins sync failed: ${err}`);
    });

module.exports = BankPin;
