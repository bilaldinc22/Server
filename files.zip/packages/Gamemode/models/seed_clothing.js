'use strict';

const ItemTemplate = require('./ItemTemplate');

async function seedClothingTemplate() {
    const existing = await ItemTemplate.findOne({ where: { name: 'Clothing' } });
    if (existing) return;

    await ItemTemplate.create({
        name: 'Clothing',
        label: 'Kleidung',
        type: 1,
        max_stack: 1,
        icon: 'clothes.png'
    });

    console.log('[ITEMTEMPLATE] Clothing template created');
}

module.exports = seedClothingTemplate;
