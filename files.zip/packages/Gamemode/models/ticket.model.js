
const tickets = sequelize.define('tickets', {
    createdby: { type: seq.STRING },
    playerid: { type: seq.INTEGER },
    content: { type: seq.TEXT },
    assignedto: { type: seq.STRING }
} , {
        timestamps: true,
        underscrored: true,
        createdAt: "regester_date",
        updatedAt: "updated_date"
 });

 tickets.prototype.login = function () { 
    // compare passwods return ? true false;
};

 // Sync
(async () => {
   await tickets.sync();
   console.log(`Tickets Synced!`);
 })();
 

module.exports = tickets;