/*
|===========================================================================================================================|
|                                                                                                                           |
|         ////\\\\                 |||||           @@@@        ||||            ||||       |||||||||||||||||||||||||         |
|        /////\\\\\                |||||         @@@@          ||||            ||||                          /////          |
|       /////  \\\\\               |||||      @@@@             ||||            ||||                         /////           |
|      /////    \\\\\              |||||   @@@@                ||||            ||||                        /////            |
|     /////      \\\\\             |||||@@@@                   ||||            ||||                       /////             |
|    /////        \\\\\            |||||@@@@                   ||||||||||||||||||||                      /////              |
|   //////////\\\\\\\\\\           |||||   @@@@                                ||||                     /////               |
|  /////            \\\\\          |||||      @@@@                             ||||                    /////                |
| /////              \\\\\         |||||         @@@@                          ||||                   /////                 |
|/////                \\\\\        |||||           @@@@                        ||||                  /////                  |
|                                                                                                                           |
|                                                                                                                           |    
|   Coded By Ramon Mikhailov                                                                                                |
|   Discord : Ak47#5519                                                                                                     |
|   Project Name : Social RP                                                                                                |
|===========================================================================================================================|
*/

const logger = require('../Logger/discord');

const vehicles = sequelize.define('vehicles', {
    // ID + IP
    veh_id: { type: seq.INTEGER, autoIncrement: true, primaryKey: true },
    veh_owner: { type: seq.STRING },
    veh_name: { type: seq.STRING }, 

    veh_parked: { type: seq.BOOLEAN, defaultValue: false },

    veh_pos: 
    {
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('veh_pos')); },
        set: function (value) { this.setDataValue('veh_pos', JSON.stringify(value)); }
    },   

    veh_angle: { type: seq.INTEGER },   

    veh_dimension: { type: seq.INTEGER, defaultValue: 0 },
    // More details
    veh_color: 
    { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('veh_color')); },
        set: function (value) { this.setDataValue('veh_color', JSON.stringify(value)); }  
    },

    veh_plate: { type: seq.STRING },
    veh_lock: { type: seq.BOOLEAN, defaultValue: true },
    veh_engine: { type: seq.BOOLEAN, defaultValue: true },
    veh_fuel: { type: seq.INTEGER, defaultValue: 100 },
    veh_health: { type: seq.INTEGER, defaultValue: 1000 },
    veh_sale: { type: seq.BOOLEAN },


    veh_inventory: 
    { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('veh_inventory')); },
        set: function (value) { this.setDataValue('veh_inventory', JSON.stringify(value)); }    
    },

    veh_mods: 
    { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('veh_mods')); },
        set: function (value) { this.setDataValue('veh_mods', JSON.stringify(value)); }    
    }

} , {
        timestamps: true,
        underscrored: true,
        createdAt: "regester_date",
        updatedAt: "updated_date"
 });

vehicles.prototype.login = function () { 
    // compare passwods return ? true false;
};


 // Sync
 (async () => {
    await vehicles.sync();

    try {
            const veh = await vehicles.findAll();
            veh.forEach((veh) => { 
            spawnVeh(veh);
        });
        console.log(`Vehicles Synced!`);
    } catch (err) {
        logger.serverLog(`${err}`);
    }


 })();


async function spawnVeh(veh) {  
    try {
        if(veh.veh_parked === true) return; // do not spawn the vehicle if its parked on the database

        const vehicle = mp.vehicles.new(mp.joaat(veh.veh_name), new mp.Vector3(veh.veh_pos.x, veh.veh_pos.y, veh.veh_pos.z), {
            heading: parseInt(veh.veh_angle),
            numberPlate: veh.veh_plate,
            locked: veh.veh_lock,
            engine: veh.veh_engine,
            dimension: parseInt(veh.veh_dimension)
        });

        if(!vehicle) return logger.serverLog(`Error Can not spawn vehicle ${vehicle} vehicle model line 102`);


        vehicle.setColor(Number(veh.veh_color.color1), Number(veh.veh_color.color2));
        vehicle.health = veh.veh_health;


        vehicle.setVariable('veh_id', veh.veh_id);
        vehicle.setVariable('veh_fuel', veh.veh_fuel);
        vehicle.setVariable('veh_health', veh.veh_health);
        vehicle.setVariable('engine', veh.veh_engine);

        vehicle.locked = veh.veh_lock;
        vehicle.engine = false;

    } catch (err) {
        logger.serverLog(`${err}`);
   }
}
    
async function createVeh(ownername, name, color1, color2, plate, pos) {  
    try {


            const vehicle = await mp.vehicles.new(mp.joaat(name), new mp.Vector3(pos.x, pos.y, pos.z), {
                heading: 0,
                numberPlate: plate,
                locked: true,
                engine: true,
                dimension: 0
            });

            if(!vehicle) return logger.serverLog(`Can not create vehicle line 133 vehicle model : Details : ${vehicle}`);

        const createvehicle = await vehicles.create({ 
            veh_owner: ownername, 
            veh_name: name,  
            veh_parked: false,
            veh_pos: pos,
            veh_angle: 0,
            veh_dimension: 0,
            veh_color: { color1, color2 },
            veh_plate: plate,
            veh_lock: true,
            veh_engine: true,
            veh_fuel: 100,
            veh_health: 1000,
            veh_sale: false,
            veh_inventory: null,
            veh_mods: null
        });

        if(!createvehicle) return player.outputChatBox(`Error: While creating your vehicle, Loc : vehicle model 124 line ${createvehicle} && ${vehicle}`);


        vehicle.setColor(Number(color1), Number(color2));
        vehicle.setVariable('veh_id', createvehicle.veh_id);
        vehicle.setVariable('veh_fuel', createvehicle.veh_fuel);
        vehicle.setVariable('veh_health', createvehicle.veh_health);
        vehicle.setVariable('engine', createvehicle.veh_engine);
 
    } catch (err) {
        logger.serverLog(err);
    }
}


module.exports = vehicles;
module.exports.createVeh = createVeh;
module.exports.spawnVeh = spawnVeh;