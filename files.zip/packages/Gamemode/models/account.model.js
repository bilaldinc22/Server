const bcrypt = require('bcryptjs');
let salt = bcrypt.genSaltSync(10);

const accounts = sequelize.define('accounts', {
    // ID + IP
    SRPID: { type: seq.INTEGER, autoIncrement: true, primaryKey: true },
    username: { type: seq.STRING },
    password: { type: seq.STRING }, 
    email: {type: seq.STRING },            // unique
    socialclub: { type: seq.STRING },      // unique

    // More details
    character_slots: { type: seq.INTEGER, defaultValue: 2 },
    online: { type: seq.BOOLEAN },
    vip: { type: seq.INTEGER, defaultValue: 0 },
    vipRank: { type: seq.INTEGER, defaultValue: 0 },

    // ADMIN
    admin: { type: seq.INTEGER, defaultValue: 0 },
    admin_skin: { type: seq.STRING },

    // Hardware
    ipaddress: { type: seq.STRING },
    hardwareid: { type: seq.STRING }

} , {
        timestamps: true,
        underscrored: true,
        createdAt: "regester_date",
        updatedAt: "updated_date"
 });


 
// bcrypt password
 accounts.beforeCreate(async (account, options) => {
    const Hashed = await bcrypt.hash(account.password, salt);
    account.password = Hashed;
 });



// password compare 
accounts.prototype.login = function (password) { 
    return bcrypt.compareSync(password, this.password);
};


 // Sync
(async () => {
    await accounts.sync();
    console.log(`Accounts Synced!`);
 })();
 

 module.exports = accounts;