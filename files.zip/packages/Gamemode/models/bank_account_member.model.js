const logger = require('../Logger/discord');

const BankAccountMember = sequelize.define('bank_account_members', {
  id: { type: seq.BIGINT, autoIncrement: true, primaryKey: true },
  account_iban: { type: seq.STRING, allowNull: false },
  character_id: { type: seq.INTEGER, allowNull: false },
  role: { type: seq.STRING, allowNull: false, defaultValue: 'member' }, // owner | treasurer | member
}, {
  timestamps: true,
  underscored: true,
});

(async () => {
  try {
    await BankAccountMember.sync();
    console.log('[Bank] bank_account_members synced');
  } catch (err) {
    try { logger.sendlog('server_logs', `[Bank] bank_account_members sync failed: ${err}`); } catch(e) {}
    console.log('[Bank] bank_account_members sync failed', err);
  }
})();

module.exports = BankAccountMember;
