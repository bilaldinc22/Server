
const bans = sequelize.define('ban', {
    SRPID: { type: seq.INTEGER },
    username: { type: seq.STRING },
    ip_address: { type: seq.STRING },
    hardware_id: { type: seq.STRING },
    social_club: { type: seq.STRING },
    ban_reason: { type: seq.STRING },
    ban_issued_by: { type: seq.STRING },
    ban_type: { type: seq.STRING },

} , {
        timestamps: true,
        underscrored: true,
        createdAt: "regester_date",
        updatedAt: "updated_date"
 });

bans.prototype.login = function () { 
    // compare passwods return ? true false;
};

 // Sync
(async () => {
    await bans.sync();
    console.log(`Bans Synced!`);
 })();
 

module.exports = bans;