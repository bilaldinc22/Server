'use strict';

require('../sequelize');
const { DataTypes } = global.seq;

const PlayerItem = global.sequelize.define('PlayerItem', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    owner_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
    },
    item_template_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
    },
    amount: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 1
    },
    slot: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    meta: {
        type: DataTypes.JSON,
        allowNull: true
    }
}, {
    tableName: 'rp_player_items',
    timestamps: false
});

module.exports = PlayerItem;
