'use strict';

const { DataTypes } = require('sequelize');
const db = require('../database'); // this exports { sequelize }

module.exports = db.sequelize.define('rp_item_templates', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },

    name: {
        type: DataTypes.STRING(64),
        allowNull: false
    },

    label: {
        type: DataTypes.STRING(64),
        allowNull: false
    },

    type: {
        type: DataTypes.INTEGER,
        allowNull: false
    },

    max_stack: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 1
    },

    icon: {
        type: DataTypes.STRING(64),
        allowNull: true
    }
}, {
    timestamps: false
});
