// packages/Gamemode/models/adminlog.model.js

const adminLogs = sequelize.define('admin_log', {
    admin_name:        { type: seq.STRING },
    admin_socialclub:  { type: seq.STRING },
    admin_id_ingame:   { type: seq.INTEGER },

    action:            { type: seq.STRING },

    target_name:       { type: seq.STRING },
    target_socialclub: { type: seq.STRING },
    target_id_ingame:  { type: seq.INTEGER },

    info:              { type: seq.TEXT },
}, {
    timestamps:  true,
    underscrored: true // gleicher Tippfehler wie in ban.model.js, für Konsistenz
});

// Sync
(async () => {
    await adminLogs.sync();
    console.log(`AdminLogs Synced!`);
})();

module.exports = adminLogs;