'use strict';

module.exports = (sequelize, Sequelize) => {
    const Items = sequelize.define("items", {

        id: {
            type: Sequelize.INTEGER,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true
        },

        name: {
            type: Sequelize.STRING,
            allowNull: false
        },

        type: {
            type: Sequelize.STRING,
            allowNull: false
        },

        description: {
            type: Sequelize.STRING,
            allowNull: true
        },

        model: {
            type: Sequelize.INTEGER,
            allowNull: true
        },

        // Stack-Menge
        amount: {
            type: Sequelize.INTEGER,
            allowNull: false,
            defaultValue: 1
        },

        spawned: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },

        // Owner = characterId
        owner: {
            type: Sequelize.INTEGER,
            allowNull: true
        },

        // Inventarslot
        slot: {
            type: Sequelize.INTEGER,
            allowNull: true
        },

        equiped: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },

        position: {
            type: Sequelize.JSON,
            allowNull: true
        },

        rotation: {
            type: Sequelize.JSON,
            allowNull: true
        },

        last_owners: {
            type: Sequelize.JSON,
            allowNull: true
        },

        data: {
            type: Sequelize.JSON,
            allowNull: true
        }
    });

    return Items;
};
