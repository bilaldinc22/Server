'use strict';

module.exports = (sequelize, DataTypes) => {
  const Outfit = sequelize.define('Outfit', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    owner_id: { type: DataTypes.INTEGER, allowNull: false },
    name: { type: DataTypes.STRING(64), allowNull: false },
    last_used: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
    model_hash: { type: DataTypes.BIGINT, allowNull: true },
    components: { type: DataTypes.JSON, allowNull: false },
    props: { type: DataTypes.JSON, allowNull: false },
  }, {
    tableName: 'rp_player_outfits',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    indexes: [
      { unique: true, fields: ['owner_id', 'name'] },
      { fields: ['owner_id'] }
    ]
  });

  return Outfit;
};
