
const send = require('request-promise');

const join_leave_logs = 'Put discord webhook link here';
const chat_logs = 'Put discord webhook link here';
const command_logs = 'Put discord webhook link here';
const admin_logs = 'Put discord webhook link here';
const kill_logs = 'Put discord webhook link here';



function sendlog(type, log) {

   switch(type)
   {
      case 'server_logs': 
      {
         send({
            method: 'POST',
            uri: server_logs,
            body: { username: 'Test', embeds: [{ title: 'Server', description: log, color: 13632027 } ]},
            json: true
         }).catch(e => console.log(e));
         break;
      }

      case 'join_leave_logs': 
      {
         send({
            method: 'POST',
            uri: join_leave_logs,
            body: { username: 'Test', embeds: [{ title: 'Join / Leave', description: log, color: 13632027 } ]},
            json: true
         }).catch(e => console.log(e));
         break;
      }

      case 'chat_logs':
         {
            send({
               method: 'POST',
               uri: chat_logs,
               body: { username: 'Test', embeds: [{ title: 'Chat', description: log, color: 13632027 } ]},
               json: true
            }).catch(e => console.log(e));
            break;
         }

      case 'command_logs': 
         {
            send({
               method: 'POST',
               uri: command_logs,
               body: { username: 'Test', embeds: [{ title: 'Command', description: log, color: 13632027 } ]},
               json: true
            }).catch(e => console.log(e));
            break;
         }

         case 'admin_logs': 
         {
            send({
               method: 'POST',
               uri: admin_logs,
               body: { username: 'Test', embeds: [{ title: 'Admin', description: log, color: 13632027 } ]},
               json: true
            }).catch(e => console.log(e));
            break;
         }

         case 'kill_logs': 
         {
            send({
               method: 'POST',
               uri: kill_logs,
               body: { username: 'Test', embeds: [{ title: 'Kill', description: log, color: 13632027 } ]},
               json: true
            }).catch(e => console.log(e));
            break;
         }
   }

 }

function serverLog(log) {
   
   send({
      method: 'POST',
      uri: server_logs,
      body: { username: 'Test', embeds: [{ title: 'Server', description: log, color: 13632027 } ]},
      json: true
   }).catch(e => console.log(e));

}


module.exports.serverLog = serverLog;
module.exports.sendlog = sendlog;

module.exports.serverlog = serverLog;
module.exports.sendLog = sendlog;