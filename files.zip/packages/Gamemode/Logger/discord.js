
const send = require('request-promise');

const server_logs = 'https://discord.com/api/webhooks/1451230926196572270/BuIgU7_xPsjxwm3jmmynfnSdQyGQt51qW9U5ZhCuuLdlRjwxts1l7_oyFqOXBdwKmoX9';
const join_leave_logs = 'https://discord.com/api/webhooks/1451230926196572270/BuIgU7_xPsjxwm3jmmynfnSdQyGQt51qW9U5ZhCuuLdlRjwxts1l7_oyFqOXBdwKmoX9';
const chat_logs = 'https://discord.com/api/webhooks/1451230926196572270/BuIgU7_xPsjxwm3jmmynfnSdQyGQt51qW9U5ZhCuuLdlRjwxts1l7_oyFqOXBdwKmoX9';
const command_logs = 'https://discord.com/api/webhooks/1451230926196572270/BuIgU7_xPsjxwm3jmmynfnSdQyGQt51qW9U5ZhCuuLdlRjwxts1l7_oyFqOXBdwKmoX9';
const admin_logs = 'https://discord.com/api/webhooks/1451230926196572270/BuIgU7_xPsjxwm3jmmynfnSdQyGQt51qW9U5ZhCuuLdlRjwxts1l7_oyFqOXBdwKmoX9';
const kill_logs = 'https://discord.com/api/webhooks/1451230926196572270/BuIgU7_xPsjxwm3jmmynfnSdQyGQt51qW9U5ZhCuuLdlRjwxts1l7_oyFqOXBdwKmoX9';



function sendlog(type, log) {

   switch(type)
   {
      case 'server_logs': 
      {
         send({
            method: 'POST',
            uri: server_logs,
            body: { username: 'Test', embeds: [{ title: 'Server', description: log, color: 13632027 } ]},
            json: true
         }).catch(e => console.log(e));
         break;
      }

      case 'join_leave_logs': 
      {
         send({
            method: 'POST',
            uri: join_leave_logs,
            body: { username: 'Test', embeds: [{ title: 'Join / Leave', description: log, color: 13632027 } ]},
            json: true
         }).catch(e => console.log(e));
         break;
      }

      case 'chat_logs':
         {
            send({
               method: 'POST',
               uri: chat_logs,
               body: { username: 'Test', embeds: [{ title: 'Chat', description: log, color: 13632027 } ]},
               json: true
            }).catch(e => console.log(e));
            break;
         }

      case 'command_logs': 
         {
            send({
               method: 'POST',
               uri: command_logs,
               body: { username: 'Test', embeds: [{ title: 'Command', description: log, color: 13632027 } ]},
               json: true
            }).catch(e => console.log(e));
            break;
         }

         case 'admin_logs': 
         {
            send({
               method: 'POST',
               uri: admin_logs,
               body: { username: 'Test', embeds: [{ title: 'Admin', description: log, color: 13632027 } ]},
               json: true
            }).catch(e => console.log(e));
            break;
         }

         case 'kill_logs': 
         {
            send({
               method: 'POST',
               uri: kill_logs,
               body: { username: 'Test', embeds: [{ title: 'Kill', description: log, color: 13632027 } ]},
               json: true
            }).catch(e => console.log(e));
            break;
         }
   }

 }

function serverLog(log) {
   
   send({
      method: 'POST',
      uri: server_logs,
      body: { username: 'Test', embeds: [{ title: 'Server', description: log, color: 13632027 } ]},
      json: true
   }).catch(e => console.log(e));

}


module.exports.serverLog = serverLog;
module.exports.sendlog = sendlog;

module.exports.serverlog = serverLog;
module.exports.sendLog = sendlog;