
const logger = require('../Logger/discord');
const accounts = require('../models/account.model');
const characters = require('../models/character.model')

 
 mp.events.add("SERVER::CHANGE:ROTATION", (player, value) => {
     player.heading = parseInt(value);
 });
 
 
 mp.events.addProc('SERVER::CHECK:CHARACTER:SLOTS', async (player) => {
     const username = player.getVariable('username');
     
     try 
     {
         const findslots = await accounts.findOne({ where: { username: username }});
         player.setVariable("freeze", true);
         player.heading = 180;
         return findslots.character_slots;
      
     }
     catch(err) 
     {
         logger.sendlog(`server_logs`, `Character slots checking failed ${err}`);
     }
 });
 
 
 mp.events.add("SERVER::CREATE:CHARACTER", async (player, characterData) => {

     try 
     {
        const username = player.getVariable("username");
 
        const data = JSON.parse(characterData);
    
        const age = data.age;
        const accent = data.accent;
        const features = data.features;
    
        //appearance
        const gender = data.gender;
        const mom = data.mom;
        const dad = data.dad;
        const shapeMix = data.shapeMix;
        const skin1 = data.skin1;
        const skin2 = data.skin2;
        const skinMix = data.skinMix;
        const noseWidth = data.noseWidth;
        const noseHeight = data.noseHeight;
        const noseTip = data.noseTip;
    
        const jawWidth = data.jawWidth;
        const jawHeight = data.jawHeight
        const chinWidth = data.chinWidth;
        const chinLength = data.chinLength;
        const neckWidth = data.neckWidth;
        const eyes = data.eyes;
        const eyesColor = data.eyesColor;
        const eyebrows = data.eyebrows;
        const lips = data.lips;
    
    
        const hairStyle = data.hairStyle;
        const hairStyleColor = data.hairColor;
        const beard = data.beard;
        const beardColor = data.beardColor;
    
        // Clothes Defines
    
        const tops = data.tops;
        const topsColor = data.topsColor;
    
        const legs = data.legs;
        const legsColor = data.legsColor;
    
        const undershirt = data.undershirt;
        const undershirtColor = data.undershirtColor;
    
        const torso = data.torso;
    
        const shoes = data.shoes;
        const shoesColor = data.shoesColor;
        //default spawn position
        const x = -1030.5916748046875;
        const y = -2668.14111328125;
        const z = 13.830760955810547;
        const heading = -145.08395385742188;

         const checkslots = await accounts.findOne({ where: { username: username }});
         if(!checkslots) return;
         if(checkslots.character_slots < 1) return player.call('Createinfo', [`You dont have any character slots left, to purchase additional slot , donate please!`, 170, 0, 0, 'top']);
         const checkoldifexist = await characters.findOne({ where: { character_name: data.name }});
         if(checkoldifexist) return player.call('Createinfo', [`Error : Character Name already exists please create a new name`, 170, 0, 0, 'top']);
     
         const created = await characters.create(
             {   username: player.getVariable('username'), 
                 character_name: data.name, 
                 character_gender: gender, 
     
                 //Appearance
                 character_appearance: { mom, dad, shapeMix, skin1, skin2, skinMix, noseWidth, noseHeight, noseTip, jawWidth, jawHeight, chinWidth,
                 chinLength, neckWidth, eyes, eyesColor, eyebrows, lips, hairStyle, hairStyleColor, beard, beardColor },
                 // Clothing
                 character_clothes: { tops, topsColor, legs, legsColor, undershirt, undershirtColor, torso, shoes, shoesColor },
                 // Features 
                 character_features: { age, accent, features },
     
                 character_position: { x, y, z },
                 character_heading: heading,
                 character_dimension: 0,
     
             });
 
             if(!created) return player.call('Createinfo', [`Error : Character Creating Failed , Please try again`, 170, 0, 0, 'top']);
 
             if(created.character_gender == true) {
                 player.setHeadOverlay(1, [parseInt(beard), 100, parseInt(beardColor), parseInt(beardColor)]); // BEARD
             }
 
             player.setClothes(2, parseInt(hairStyle), 0, 2); // Hair NEW
             player.setHairColor(parseInt(hairStyleColor), 0);
 
             player.setCustomization(created.character_gender, 
                parseInt(mom), 
                parseInt(dad), 0, 
                parseInt(skin1), 
                parseInt(skin2), 0, 
                parseInt(shapeMix), 
                parseInt(shapeMix), 0, 1, 0, 0, 

                [parseInt(neckWidth), 
                parseInt(noseHeight), 0, 0, 
                parseInt(noseTip), 0, 0, 0, 0, 0, 0,
                parseInt(eyes), 
                parseInt(lips), 
                parseInt(jawWidth), 
                parseInt(jawHeight), 
                parseInt(chinLength), 0, 
                parseInt(chinWidth), 0, 
                parseInt(neckWidth)]
                );
          
 
             if(parseInt(undershirt) == 15) {
                 player.setClothes(8, 15, 0, 0); // undershirt default
             } else {
                 player.setClothes(8, parseInt(undershirt), 0, 0);
             }
 
             player.setHeadOverlay(2, [parseInt(eyebrows), 100, 0, 0]); // eyebrows
             player.setClothes(3, parseInt(torso), 0, 0) // torso
 
             player.setClothes(11, parseInt(tops), parseInt(topsColor), 0); // tops
             player.setClothes(4, parseInt(legs), parseInt(legsColor), 0); // legs
             player.setClothes(6, parseInt(shoes), parseInt(shoesColor), 0); // shoes
 
             // variables
             player.dimension = 0;
             player.heading = heading;
             player.call('CLIENT::SPAWN:PLAYER', [x, y, z]);
             checkslots.decrement('character_slots', { by: 1 });
             checkslots.save();
 
             player.setVariable('freeze', false);
             player.setVariable('playing', true);
             player.setVariable('playingCharacter', created.character_name);
             player.setVariable('gender', created.character_gender);
             player.setVariable('bank_money', created.bank_money);
             player.setVariable('pocket_money', created.pocket_money);
 
        
             player.call('DISCORD::SHOW:PLAYER', [created.character_name]);
     }   
     catch(err)
     {
         logger.sendlog(`server_logs`, `Creating Character Failed , ${err}`);
     }
 
 });
 
 mp.events.add('SERVER::PLAY:CHARACTER', async (player, characterName) => {
     try {
         const findcharacter = await characters.findOne({ where: { character_name: characterName } });
     
         if(findcharacter) {
     
             const apearance = findcharacter.character_appearance;
             const clothes = findcharacter.character_clothes;
             const name = findcharacter.character_name;
             const position = findcharacter.character_position;

 
             if(findcharacter.character_gender == true) {
                 player.setHeadOverlay(1, [parseInt(apearance.beard), 100, parseInt(apearance.beardColor), parseInt(apearance.beardColor)]); // BEARD
             }
             
 
             if(parseInt(clothes.undershirt) == 15) {
                 player.setClothes(8, 15, 0, 0); // undershirt default
             } else {
                 player.setClothes(8, parseInt(clothes.undershirt), 0, 0);
             }
     
             player.setHeadOverlay(2, [parseInt(apearance.eyebrows), 100, 0, 0]); // eyebrows
             player.setClothes(3, parseInt(clothes.torso), 0, 0) // torso
 
             player.setClothes(2, parseInt(apearance.hairStyle), 0, 2); // Hair NEW
             player.setHairColor(parseInt(apearance.hairStyleColor), 0);
 
 
             player.setCustomization(findcharacter.character_gender, 
                parseInt(apearance.mom), 
                parseInt(apearance.dad), 0, 
                parseInt(apearance.skin1), 
                parseInt(apearance.skin2), 0, 
                parseInt(apearance.shapeMix), 
                parseInt(apearance.skinMix), 0, 1, 0, 0, 

                [parseInt(apearance.noseWidth), 
                parseInt(apearance.noseHeight), 0, 0, 
                parseInt(apearance.noseTip), 0, 0, 0, 0, 0, 0, 
                parseInt(apearance.eyes), 
                parseInt(apearance.lips), 
                parseInt(apearance.jawWidth), 
                parseInt(apearance.jawHeight), 
                parseInt(apearance.chinLength), 0, 
                parseInt(apearance.chinWidth), 0, 
                parseInt(apearance.neckWidth)]
                );
     
             player.setClothes(11, parseInt(clothes.tops), parseInt(clothes.topsColor), 0); // tops
             player.setClothes(4, parseInt(clothes.legs), parseInt(clothes.legsColor), 0); // legs
             player.setClothes(6, parseInt(clothes.shoes), parseInt(clothes.shoesColor), 0); // shoes
     
             player.dimension = parseInt(findcharacter.character_dimension);
             player.heading = parseFloat(findcharacter.character_heading);
             player.call('CLIENT::SPAWN:PLAYER', [position.x, position.y, position.z]);
             player.setVariable("freeze", false);
             player.setVariable('playing', true);
             player.setVariable('playingCharacter', name);
             player.setVariable('bank_money', findcharacter.bank_money);
             player.setVariable('pocket_money', findcharacter.pocket_money);
             player.setVariable('gender', findcharacter.character_gender);

             player.setVariable("faction", findcharacter.faction_data); 

             player.call('DISCORD::SHOW:PLAYER', [findcharacter.character_name]);
             
             logger.sendlog('join_leave_logs', `${findcharacter.character_name}has joined the server, IP : ${player.ip} Social Club : ${player.socialClub}`);
             return;
         } else return;
     
         } catch (err) {
             logger.sendlog(`server_logs`, `Play Character Failed ${err}`);
         }
   
 });

 async function setApearance(player, characterName) {
    try {
        const findcharacter = await characters.findOne({ where: { character_name: characterName } });
    
        if(findcharacter) {
    
            const apearance = findcharacter.character_appearance;
            const clothes = findcharacter.character_clothes;
    

            if(findcharacter.character_gender == true) {
                player.setHeadOverlay(1, [parseInt(apearance.beard), 100, parseInt(apearance.beardColor), parseInt(apearance.beardColor)]); // BEARD
            }
            

            if(parseInt(clothes.undershirt) == 15) {
                player.setClothes(8, 15, 0, 0); // undershirt default
            } else {
                player.setClothes(8, parseInt(clothes.undershirt), 0, 0);
            }
    
            player.setHeadOverlay(2, [parseInt(apearance.eyebrows), 100, 0, 0]); // eyebrows
            player.setClothes(3, parseInt(clothes.torso), 0, 0) // torso

            player.setClothes(2, parseInt(apearance.hairStyle), 0, 2); // Hair NEW

            player.setCustomization(findcharacter.character_gender, 
                parseInt(apearance.mom), 
                parseInt(apearance.dad), 0, 
                parseInt(apearance.skin1), 
                parseInt(apearance.skin2), 0, 
                parseInt(apearance.shapeMix), 
                parseInt(apearance.skinMix), 0, 1, 0, 0, 

                [parseInt(apearance.noseWidth), 
                parseInt(apearance.noseHeight), 0, 0, 
                parseInt(apearance.noseTip), 0, 0, 0, 0, 0, 0, 
                parseInt(apearance.eyes), 
                parseInt(apearance.lips), 
                parseInt(apearance.jawWidth), 
                parseInt(apearance.jawHeight), 
                parseInt(apearance.chinLength), 0, 
                parseInt(apearance.chinWidth), 0, 
                parseInt(apearance.neckWidth)]
                );
    
            player.setClothes(11, parseInt(clothes.tops), parseInt(clothes.topsColor), 0); // tops
            player.setClothes(4, parseInt(clothes.legs), parseInt(clothes.legsColor), 0); // legs
            player.setClothes(6, parseInt(clothes.shoes), parseInt(clothes.shoesColor), 0); // shoes
    
            player.setHairColor(parseInt(apearance.hairStyleColor), 0);

            return;
        } else return;
    
        } catch (err) {
            logger.sendlog(`server_logs`, `Play Character Failed ${err}`);
        }
 }
 module.exports.setApearance = setApearance;
