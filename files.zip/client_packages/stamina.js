const player = mp.players.local;


// disable slow running
mp.events.add('render', () => {
    if(player.isSprinting()) {
        mp.game.player.restoreStamina(100);
    }
});


// render to turn off vehicle radio on player enter vehicle
mp.events.add("render", () => {

    if (mp.players.local.vehicle) {
        mp.game.audio.setRadioToStationName("OFF");
        mp.game.audio.setUserRadioControlEnabled(false);
    }

});
