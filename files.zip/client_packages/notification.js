const maxMessages = 5; // The max messages that will show (on each bar)
const DefaultTime = 4; // The max time each message will show if time isn't defined.
const DefaultPos = 'top'; // Default position if not specified in calling the function.
const top = []; // Top Bar 
const bot = []; // Bottom Bar
const graphics = mp.game.graphics

mp.events.add('Createinfo', (msg, r, g, b, pos) => { // Event that will be global to call
    if (!msg) return false; // No message? No bar!
    if (pos == undefined) pos = DefaultPos;
    let data = { // Gathering Data to push to the bar
        text: msg,
        r: r,
        g: g,
        b: b,
        position: pos
    };
    if (pos.toLowerCase() === 'top') { // Sending data to Top
        top.push(data);
        setTimeout(_ => { // After 8 seconds, the message will be deleted
            if (top.includes(data)) top.splice(top.indexOf(data), 1)
        }, DefaultTime * 1000)
    } else if (pos.toLowerCase() === 'bot') { // Sending data to bot
        bot.push(data)
        setTimeout(_ => { // After 8 seconds, the message will be deleted
            if (bot.includes(data)) bot.splice(bot.indexOf(data), 1)
        }, DefaultTime * 1000)
    }
})

function renderbar() {

    if (top.length > 7) top.splice(0, 1) // if the messages are more than 7, Delete the first message.
    if (bot.length > 7) bot.splice(0, 1)

    for (let i in top) { // Top bar manager
        const margin = 0.01;
        const x = 0.5;
        const y = (0.03 + margin) * i; // Bar coordination management
        graphics.drawRect(x, y + 0.01, 0.5, 0.040, 0, 0, 0, 200)
        graphics.drawText(top[i].text, [x, y], { 
            font: 0, 
            color: [top[i].r, top[i].g, top[i].b, 185], 
            scale: [0.5, 0.5], 
            outline: false
          });
    }

    for (let z in bot) { // Bot bar manager
        const margin_ = 0.03;
        const x_ = 0.5;
        let y_ = 0.96 - margin_ * z // Bar coordination management
        //graphics.drawRect(x_, y_, 0.5, 0.030, 0, 0, 0, 200);
        graphics.drawText(bot[z].text, [x_, y_ - 0.01], { 
            font: 0, 
            color: [bot[z].r, bot[z].g, bot[z].b, 185], 
            scale: [0.4, 0.4], 
            outline: false
          });
    }
}

mp.events.add('render', renderbar); // Drawing the bar on each frame event.