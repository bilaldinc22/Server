mp.events.add("admin:tpwp:req", ()=>{
  const blip = mp.game.ui.getFirstBlipInfoId(8);
  if (!mp.game.ui.doesBlipExist(blip)) return;
  const c = mp.game.ui.getBlipInfoIdCoord(blip);
  let z = 0;
  for (let i=0;i<400;i++){
    const testZ = i*5.0;
    const ok = mp.game.gameplay.getGroundZFor3dCoord(c.x,c.y,testZ,0,false);
    if (ok){ z=testZ; break; }
  }
  mp.events.callRemote("admin:tpwp:coords", c.x, c.y, z);
});
