let panel = null;
let open = false;

function openPanel(payload){
  if (panel) panel.destroy();
  panel = mp.browsers.new("package://admin/cef/index.html");
  panel.execute(`window.adminPanelInitData(${JSON.stringify(payload)});`);
  open = true;
  mp.gui.cursor.show(true, true);
}

function closePanel(){
  if (!open) return;
  open = false;
  if (panel) { panel.destroy(); panel = null; }
  mp.gui.cursor.show(false, false);
  mp.events.callRemote("admin:panel:closed");
}

mp.events.add("admin:panel:open", (payload)=>{ openPanel(payload); mp.events.callRemote("admin:panel:opened"); });
mp.events.add("admin:panel:data", (payload)=>{ if (panel) panel.execute(`window.adminPanelInitData(${JSON.stringify(payload)});`); });
mp.events.add("admin:panel:players", (playersJson)=>{ if (panel) panel.execute(`window.adminPanelPlayersUpdate(${JSON.stringify(playersJson)});`); });

mp.keys.bind(0x74, true, ()=>{ if (open) closePanel(); else mp.events.callRemote("admin:panel:open"); }); // F5
mp.keys.bind(0x1B, true, ()=>{ if (open) closePanel(); }); // ESC
