let spectating=false; let lastPos=null;
mp.events.add("admin:spectate:start", (remoteId)=>{
  const t = mp.players.atRemoteId(remoteId);
  if (!t) return;
  if (!spectating) lastPos = mp.players.local.position;
  spectating=true;
  mp.players.local.attachTo(t.handle, 0, 0, 0, 5, 0, 0, 0, false, false, false, false, 2, true);
});
mp.events.add("admin:spectate:stop", ()=>{
  if (!spectating) return;
  spectating=false;
  mp.players.local.detach(true,true);
  if (lastPos) mp.players.local.position = lastPos;
  lastPos=null;
});
