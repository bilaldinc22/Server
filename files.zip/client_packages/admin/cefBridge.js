mp.events.add("admin:panel:action", (action, json) => {
  mp.events.callRemote("admin:panel:action", action, json);
});
