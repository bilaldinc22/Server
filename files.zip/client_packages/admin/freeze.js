mp.events.add("admin:freeze", (state)=>{ mp.players.local.freezePosition(!!state); });
