let invis=false;
mp.events.add("admin:invis", ()=>{ invis=!invis; mp.players.local.setVisible(!invis,false); });
