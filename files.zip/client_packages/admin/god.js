mp.events.add("admin:god", (state)=>{ mp.players.local.setInvincible(!!state); });
