var banBrowser;
var banCam;
const player = mp.players.local;





mp.events.add('CLIENT::SHOW:BAN:PAGE', (findban) => {

    mp.game.graphics.transitionToBlurred(1);
    mp.gui.chat.activate(false);
    mp.gui.chat.show(false); 
    mp.game.ui.displayRadar(false);

    player.position = new mp.Vector3(-1234.8541259765625, -1485.03076171875, 59.49446487426758);
    banCam = mp.cameras.new('default', new mp.Vector3(-1254.4293212890625, -1472.5008544921875, 57.557159423828125), new mp.Vector3(0, 0, 0), 40);
    banCam.pointAtCoord(-1437.3157958984375, -1340.056396484375, 49.74590301513672);
    banCam.setActive(true);
    mp.game.cam.renderScriptCams(true, false, 0, true, false);

    banBrowser = mp.browsers.new("package://ui/ui-ban/index.html");
    banBrowser.active = true;
    banBrowser.execute(`showDetails('${findban.ipaddress}', '${findban.socialclub}', '${findban.banreason}')`);
});