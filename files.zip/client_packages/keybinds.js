//======================================= mouse curosr script
mp.keys.bind(0x71, true, function() {   // F2
    mp.gui.cursor.visible = !mp.gui.cursor.visible;
});

mp.events.add('render', () => {
    mp.game.controls.disableControlAction(32, 36, true);
});


let hidden = false;

mp.keys.bind(0x76, true, function() {   // F7 for screenshots
    if(hidden == false) {
        mp.gui.chat.show(false);
        mp.gui.chat.activate(false);
        mp.game.ui.displayRadar(false);
        hidden = true;
    } else {
        mp.gui.chat.show(true);
        mp.gui.chat.activate(true);
        mp.game.ui.displayRadar(true);
        hidden = false;
    }
});
