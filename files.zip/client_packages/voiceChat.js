const localPlayer = mp.players.local;
const Use3d = true;
const UseAutoVolume = false;
const MaxRange = 6.0;

let activated = false;
mp.voiceChat.muted = true;

////mp.game.streaming.requestAnimDict("mp_facial");
//mp.game.streaming.requestAnimDict("facials@gen_male@variations@normal");

mp.keys.bind(0x4E, true, () => {
    if (mp.gui.cursor.visible || mp.chatActive || mp.consoleActive) return;
    activated = true;
	//localPlayer.playFacialAnim("mic_chatter", "mp_facial"); 
	mp.voiceChat.muted = false;
	mp.voiceChat.cleanupAndReload(true, true, true);
    mp.events.callRemote('SERVER:SET:VOICE:STATE', 1);
});
mp.keys.bind(0x4E, false, () => {
    if (mp.gui.cursor.visible || mp.chatActive || mp.consoleActive) return;
    activated = false;
	//localPlayer.playFacialAnim("mood_normal_1", "facials@gen_male@variations@normal");
	mp.voiceChat.muted = true;
    mp.events.callRemote('SERVER:SET:VOICE:STATE', 2);
});

mp.events.add("render", () => {
    let playing = localPlayer.getVariable('playing');
    if(playing == true) {
        if (activated) {
            mp.game.graphics.drawText("TALKING", [0.5, 0.94], {
                font: 2,
                color: [48, 197, 15, 185],
                scale: [0.8, 0.8],
                outline: true
            });
        } 
    }
});

let mute_player = false;

    let g_voiceMgr = {
        listeners: [],
        add: function(player) {
            this.listeners.push(player);

            player.isListening = true;
            mp.events.callRemote("add_voice_listener", player);

            if (UseAutoVolume) {
                player.voiceAutoVolume = true;
            } else {
                player.voiceVolume = 1.2;
            }
            if (Use3d) {
                player.voice3d = true;
            }
        },

        remove: function(player, notify) {
            let idx = this.listeners.indexOf(player);

            if (idx !== -1)
                this.listeners.splice(idx, 1);

            player.isListening = false;

            if (notify) {
                mp.events.callRemote("remove_voice_listener", player);
            }
        }
    };

    mp.events.add("playerQuit", (player) => {
        if (player.isListening) {
            g_voiceMgr.remove(player, false);
        }
    });


    setInterval(() => {
        let localPlayer = mp.players.local;
        let localPos = localPlayer.position;

        mp.players.forEachInStreamRange(player => {
            if (player != localPlayer) {
                if (!player.isListening) {
                    const playerPos = player.position;
                    let dist = mp.game.system.vdist(playerPos.x, playerPos.y, playerPos.z, localPos.x, localPos.y, localPos.z);

                    if (dist <= MaxRange) {
                        g_voiceMgr.add(player);
                    }
                }
            }
        });

        g_voiceMgr.listeners.forEach((player) => {
            if (player.handle !== 0) {
                const playerPos = player.position;
                let dist = mp.game.system.vdist(playerPos.x, playerPos.y, playerPos.z, localPos.x, localPos.y, localPos.z);

                if (dist > MaxRange) {
                    g_voiceMgr.remove(player, true);
                } else if (!UseAutoVolume) {
                    player.voiceVolume = 1 - (dist / MaxRange);
                }
            } else {
                g_voiceMgr.remove(player, true);
            }
        });
    }, 500);