var loginCam;
var loginBrowser;
const player = mp.players.local;


mp.events.add('CLIENT::SHOW:LOGIN:PAGE', () => {
    setTimeout(() => { mp.gui.cursor.show(true, true); }, 500);
    loginBrowser = mp.browsers.new("package://ui/ui-authorization/index.html");
    mp.game.graphics.transitionToBlurred(1);

    mp.gui.chat.activate(false);
    mp.gui.chat.show(false); 
    mp.game.ui.displayRadar(false);

    player.position = new mp.Vector3(-1829.8128662109375, -1068.7066650390625, 47.78288650512695);
    mp.players.local.freezePosition(true);

    loginCam = mp.cameras.new('default', new mp.Vector3(-1840.4212646484375, -1021.410888671875, 63.63906478881836), new mp.Vector3(0, 0, 0), 40);
    loginCam.pointAtCoord(-1807.6871337890625, -1167.3133544921875, 15.809928894042969);
    loginCam.setActive(true);
    mp.game.cam.renderScriptCams(true, false, 0, true, false);
});

mp.events.add('CLIENT::REMOVE:LOGIN:CAM', () => {
    loginCam.setActive(false);
    mp.game.graphics.transitionFromBlurred(1); 
});

mp.events.add('CLIENT::REMOVE:LOGIN:BROWSER', () => {
    loginBrowser.destroy();
});

//mp.game.graphics.transitionFromBlurred(1000);  remove blur


// Attempt register on server
mp.events.add('CLIENT::BROWSER:REGISTER:ATTEMPT', (username, email, password) => {
    mp.events.callRemote('SERVER::ATTEMPT:REGISTER', username, email, password);
});


// Attempt Login on server
mp.events.add('CLIENT::BROWSER:LOGIN:ATTEMPT', (username, password) => {
    mp.events.callRemote('SERVER::ATTEMPT:LOGIN', username, password);
});