const player = mp.players.local;
var houseBrowser; 
let active = false;


mp.events.add('CLIENT::OPEN:HOUSE:MENU', (house_id, house_owner, house_address) => {
    if(active == false) {
        houseBrowser = mp.browsers.new(`package://ui/ui-house/house.html`);
        houseBrowser.execute(`openMenu('${house_id}', '${house_owner}', '${house_address}')`);
        mp.gui.cursor.visible = true;
        active = true;
    }
});


mp.events.add('CLIENT::CLOSE:HOUSE:MENU', () => {
    if(active == true) {
        houseBrowser.destroy();
        active = false;
        mp.gui.cursor.visible = false;
    }
});


mp.events.add('CLIENT::ENTER:HOUSE', (house_id) => {
    mp.events.callRemote('SERVER::ENTER:HOUSE', house_id);
});


mp.keys.bind(0x45, true, function() {   // E for House 
    if (mp.gui.cursor.visible || mp.chatActive || mp.consoleActive) return;
    const detectHouse = mp.players.local.getVariable("inHouseColShape");
    if(!detectHouse) return;
    mp.events.callRemote(`SERVER::HOUSE:MENU`);
});

mp.keys.bind(0x59, true, function() {   // Y for House 
    if (mp.gui.cursor.visible || mp.chatActive || mp.consoleActive) return;
    const detectHouse = mp.players.local.getVariable("inHouseColShape");
    if(!detectHouse) return;
    mp.events.callRemote(`SERVER::HOUSE:ENTER`);
});


mp.events.add('CLIENT::HOUSE:LOCK', (house_id) => {
    mp.events.callRemote('SERVER::HOUSE:LOCK', house_id);
});

mp.events.add('CLIENT::HOUSE:UNLOCK', (house_id) => {
    mp.events.callRemote('SERVER::HOUSE:UNLOCK', house_id);
});

mp.events.add(`CLIENT::HOUSE:ADD:TENANT`, async (house_id, Name) => {
    mp.events.callRemote(`SERVER::HOUSE:ADD:TENANT`, house_id, Name);
});

mp.events.add(`CLIENT::HOUSE:KICK:TENANT`, async (house_id, Name) => {
    mp.events.callRemote(`SERVER::HOUSE:KICK:TENANT`, house_id, Name);
});