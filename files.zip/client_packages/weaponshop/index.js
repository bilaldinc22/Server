const NativeUI = require("nativeui");
const { Menu, UIMenuItem, Point } = NativeUI;

// ===== SETTINGS =====
const DEBUG = true;
// If true: apply ammo/attachments locally right after selecting buy (to verify natives work).
// Server still charges money, but this allows isolating "server->client call" issues.
const APPLY_LOCALLY = true;

// ----- CONFIG -----
const SHOP_POS = new mp.Vector3(22.0, -1107.0, 29.8);
const MARKER_TYPE = 1;
const MARKER_SCALE = 1.0;
const MARKER_COLOR = [255, 0, 0, 150];
const OPEN_KEY = 0x45; // E
const OPEN_RANGE = 2.0;

// Blip
const BLIP_SPRITE = 110;
const BLIP_COLOR = 1;
const BLIP_SCALE = 0.85;
const BLIP_NAME = "Waffenshop";
const BLIP_SHORT_RANGE = true;

// ----- HASH (mp.joaat ist bei dir nicht vorhanden) -----
function joaat(str) {
    if (mp.game && typeof mp.game.joaat === "function") return mp.game.joaat(str);
    str = String(str).toLowerCase();
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash += str.charCodeAt(i);
        hash += (hash << 10);
        hash ^= (hash >>> 6);
    }
    hash += (hash << 3);
    hash ^= (hash >>> 11);
    hash += (hash << 15);
    return hash >>> 0;
}

function log(msg) {
    if (!DEBUG) return;
    try { mp.gui.chat.push(`[WS] ${msg}`); } catch (e) {}
    try { mp.console.logInfo(`[WS] ${msg}`); } catch (e) {}
}

// ----- MENU POSITION (rechts) -----
function getMenuPointRight() {
    try {
        const res = mp.game.graphics.getScreenActiveResolution(0, 0);
        const w = Array.isArray(res) ? res[0] : (res && res.x ? res.x : 0);
        if (!w) return new Point(1100, 50);
        const x = Math.max(50, Math.floor(w - 420));
        return new Point(x, 50);
    } catch (e) {
        return new Point(1100, 50);
    }
}
const MENU_POINT = getMenuPointRight();

// ----- BLIP & MARKER -----
mp.blips.new(BLIP_SPRITE, SHOP_POS, { name: BLIP_NAME, color: BLIP_COLOR, scale: BLIP_SCALE, shortRange: BLIP_SHORT_RANGE });
mp.markers.new(MARKER_TYPE, SHOP_POS, MARKER_SCALE, { color: MARKER_COLOR, visible: true });

// ----- MENUS -----
const mainMenu = new Menu("Waffenshop", "Pistolen · Munition · Anbauteile", MENU_POINT);
const pistolMenu = new Menu("Pistolen", "Verfügbare Waffen", MENU_POINT);
const ammoMenu = new Menu("Munition", "Nachladen", MENU_POINT);
const attachMenu = new Menu("Anbauteile", "Zubehör", MENU_POINT);

mainMenu.Visible = false;
pistolMenu.Visible = false;
ammoMenu.Visible = false;
attachMenu.Visible = false;

let activeMenu = null;
let lastToggleTick = 0;

function now() { return Date.now(); }
function anyMenuVisible() { return !!activeMenu && activeMenu.Visible; }

function openMenu(menu) {
    mainMenu.Visible = false;
    pistolMenu.Visible = false;
    ammoMenu.Visible = false;
    attachMenu.Visible = false;

    activeMenu = menu;
    menu.Visible = true;
    mp.gui.cursor.visible = false;

    if (typeof menu.RefreshIndex === "function") menu.RefreshIndex();
    if (typeof menu.ResetIndex === "function") menu.ResetIndex();

    log(`openMenu: ${menu.Title || "menu"}`);
}

function closeAll() {
    mainMenu.Visible = false;
    pistolMenu.Visible = false;
    ammoMenu.Visible = false;
    attachMenu.Visible = false;
    activeMenu = null;
    mp.gui.cursor.visible = false;
    log("closeAll");
}

// ----- BUILD ITEMS -----
mainMenu.AddItem(new UIMenuItem("Pistolen", "Waffen kaufen"));
mainMenu.AddItem(new UIMenuItem("Munition", "Munition kaufen"));
mainMenu.AddItem(new UIMenuItem("Anbauteile", "Zubehör kaufen"));

pistolMenu.AddItem(new UIMenuItem("← Zurück", "Hauptmenü"));
ammoMenu.AddItem(new UIMenuItem("← Zurück", "Hauptmenü"));
attachMenu.AddItem(new UIMenuItem("← Zurück", "Hauptmenü"));

const pistols = [
    { name: "Pistol", hash: "weapon_pistol", price: 2500 },
    { name: "Combat Pistol", hash: "weapon_combatpistol", price: 3500 }
];
const ammoPacks = [
    { name: "Pistolen Munition (50)", amount: 50, price: 500 },
    { name: "Pistolen Munition (100)", amount: 100, price: 900 }
];
const attachments = [
    { name: "Extended Magazin", compName: "component_pistol_clip_02", price: 1000 },
    { name: "Taschenlampe", compName: "component_at_pi_flsh", price: 750 }
];

pistols.forEach(w => pistolMenu.AddItem(new UIMenuItem(w.name, `Preis: ${w.price}$`)));
ammoPacks.forEach(a => ammoMenu.AddItem(new UIMenuItem(a.name, `Preis: ${a.price}$`)));
attachments.forEach(a => attachMenu.AddItem(new UIMenuItem(a.name, `Preis: ${a.price}$`)));

// ----- WEAPON HASH & AMMO -----
function getCurrentWeaponHash() {
    if (mp.players.local && typeof mp.players.local.weapon === "number" && mp.players.local.weapon !== 0) {
        return mp.players.local.weapon >>> 0;
    }
    if (mp.game && mp.game.weapon && typeof mp.game.weapon.getSelectedPedWeapon === "function") {
        return mp.game.weapon.getSelectedPedWeapon(mp.players.local.handle) >>> 0;
    }
    return 0;
}

const NATIVE_GET_AMMO_IN_PED_WEAPON = 0x015A522136D7F951;
const NATIVE_SET_PED_AMMO = 0x14E56BC5B5DB6A19;
const NATIVE_GIVE_WEAPON_COMPONENT_TO_PED = 0xD966D51AA5B28BB9;
const NATIVE_HAS_PED_GOT_WEAPON_COMPONENT = 0xC593212475FAE340;

function applyAmmo(amount) {
    const ped = mp.players.local.handle;
    const weaponHash = getCurrentWeaponHash();
    if (!weaponHash) { log("applyAmmo: weaponHash=0"); return; }

    const cur = mp.game.invoke(NATIVE_GET_AMMO_IN_PED_WEAPON, ped, weaponHash) >>> 0;
    const next = (cur + (amount >>> 0)) >>> 0;

    mp.game.invoke(NATIVE_SET_PED_AMMO, ped, weaponHash, next);
    const after = mp.game.invoke(NATIVE_GET_AMMO_IN_PED_WEAPON, ped, weaponHash) >>> 0;

    log(`applyAmmo: weapon=${weaponHash} ammo ${cur} -> ${after}`);
}

function applyAttachment(componentHash) {
    const ped = mp.players.local.handle;
    const weaponHash = getCurrentWeaponHash();
    if (!weaponHash) { log("applyAttachment: weaponHash=0"); return; }

    mp.game.invoke(NATIVE_GIVE_WEAPON_COMPONENT_TO_PED, ped, weaponHash, componentHash);
    const ok = !!mp.game.invoke(NATIVE_HAS_PED_GOT_WEAPON_COMPONENT, ped, weaponHash, componentHash);

    log(`applyAttachment: weapon=${weaponHash} comp=${componentHash} ok=${ok}`);
}

// events from server (if your server->client call works)
mp.events.add("weaponshop:applyAmmo", (amount) => {
    log(`recv weaponshop:applyAmmo(${amount})`);
    applyAmmo(amount);
});

mp.events.add("weaponshop:applyAttachment", (componentHash) => {
    log(`recv weaponshop:applyAttachment(${componentHash})`);
    applyAttachment(componentHash);
});

// ----- MANUAL ACCEPT/BACK -----
function getMenuIndex(menu) {
    if (!menu) return 0;
    const keys = ["CurrentSelection","currentSelection","SelectedIndex","selectedIndex","_Index","_index","Index","index"];
    for (let i=0;i<keys.length;i++){
        const k=keys[i];
        if (typeof menu[k] === "number") return menu[k];
    }
    return 0;
}

function isAcceptPressed() {
    return mp.game.controls.isControlJustPressed(0, 176) || mp.game.controls.isControlJustPressed(0, 201);
}
function isBackPressed() {
    return mp.game.controls.isControlJustPressed(0, 177) || mp.game.controls.isControlJustPressed(0, 202);
}

function handleAccept() {
    const idx = getMenuIndex(activeMenu);

    if (activeMenu === mainMenu) {
        if (idx === 0) return openMenu(pistolMenu);
        if (idx === 1) return openMenu(ammoMenu);
        if (idx === 2) return openMenu(attachMenu);
        return;
    }

    if (activeMenu === pistolMenu) {
        if (idx === 0) return openMenu(mainMenu);
        const data = pistols[idx - 1];
        if (!data) return;
        log(`buyWeapon: ${data.name}`);
        mp.events.callRemote("weaponshop:buyWeapon", joaat(data.hash), data.price);
        return;
    }

    if (activeMenu === ammoMenu) {
        if (idx === 0) return openMenu(mainMenu);
        const data = ammoPacks[idx - 1];
        if (!data) return;
        log(`buyAmmo: +${data.amount}`);
        mp.events.callRemote("weaponshop:buyAmmo", data.amount, data.price);
        if (APPLY_LOCALLY) applyAmmo(data.amount);
        return;
    }

    if (activeMenu === attachMenu) {
        if (idx === 0) return openMenu(mainMenu);
        const data = attachments[idx - 1];
        if (!data) return;
        const ch = joaat(data.compName);
        log(`buyAttachment: ${data.name} ch=${ch}`);
        mp.events.callRemote("weaponshop:buyAttachment", ch, data.price);
        if (APPLY_LOCALLY) applyAttachment(ch);
        return;
    }
}

function handleBack() {
    if (activeMenu === mainMenu) return closeAll();
    return openMenu(mainMenu);
}

// ----- RENDER -----
function tickMenu(menu) {
    if (!menu || !menu.Visible) return;
    if (typeof menu.ProcessControl === "function") menu.ProcessControl();
    if (typeof menu.Draw === "function") menu.Draw();
}

function disableGameplayControlsForMenu() {
    const toDisable = [24,25,68,69,70,91,92,140,141,142,14,15,16,17,37,44,45];
    for (let i = 0; i < toDisable.length; i++) mp.game.controls.disableControlAction(0, toDisable[i], true);

    const allow = [172,173,174,175,176,177,188,187,189,190,201,202,199,200];
    for (let i = 0; i < allow.length; i++) mp.game.controls.enableControlAction(0, allow[i], true);
}

mp.events.add("render", () => {
    if (anyMenuVisible()) {
        disableGameplayControlsForMenu();
        if (isAcceptPressed()) handleAccept();
        else if (isBackPressed()) handleBack();
    }
    tickMenu(activeMenu);
});

// ----- KEY (open/close) -----
mp.keys.bind(OPEN_KEY, true, () => {
    const t = now();
    if ((t - lastToggleTick) < 250) return;
    lastToggleTick = t;

    const p = mp.players.local.position;
    const dx = p.x - SHOP_POS.x;
    const dy = p.y - SHOP_POS.y;
    const dz = p.z - SHOP_POS.z;
    if ((dx*dx + dy*dy + dz*dz) > (OPEN_RANGE * OPEN_RANGE)) return;

    if (!anyMenuVisible()) openMenu(mainMenu);
    else closeAll();
});
