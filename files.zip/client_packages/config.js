module.exports = {
    shopPosition: new mp.Vector3(22.0, -1107.0, 29.8),
    markerType: 1,
    markerScale: 1.0,
    markerColor: [255, 0, 0, 150],
    openKey: 0x45 // E
};
