let currentGarageId = null;
let browser = null;
const shapes = new Map();

mp.events.callRemote('garage:requestGarages');

mp.events.add('garage:syncGarages', (json) => {
  const garages = JSON.parse(json) || [];
  garages.forEach(g => {
    mp.markers.new(1, new mp.Vector3(g.marker.x, g.marker.y, g.marker.z - 1), g.radius, {
      color: [124, 92, 255, 120],
      visible: true
    });

    mp.blips.new(
      g.blip?.sprite ?? 357,
      new mp.Vector3(g.marker.x, g.marker.y, g.marker.z),
      { name: g.name, shortRange: true, color: g.blip?.color ?? 27, scale: g.blip?.scale ?? 0.8 }
    );

    const shape = mp.colshapes.newSphere(g.marker.x, g.marker.y, g.marker.z, g.radius);
    shapes.set(shape.id, g.id);
  });
});

mp.events.add('playerEnterColshape', (shape) => {
  if (!shapes.has(shape.id)) return;
  currentGarageId = shapes.get(shape.id);
  mp.game.graphics.notify('~g~Garage: Drücke ~w~E');
});

mp.events.add('playerExitColshape', (shape) => {
  if (!shapes.has(shape.id)) return;
  if (currentGarageId === shapes.get(shape.id)) currentGarageId = null;
});

mp.keys.bind(0x45, false, () => {
  if (!currentGarageId) return;
  mp.events.callRemote('garage:loadVehicles', currentGarageId);
});

mp.events.add('garage:openUI', (vehiclesJson, garageId, garageName) => {
  if (browser) return;
  browser = mp.browsers.new('package://garage/ui/index.html');
  mp.gui.cursor.show(true, true);
  browser.execute(`setGarage(${JSON.stringify(garageName)}, ${Number(garageId)})`);
  browser.execute(`loadVehicles(${JSON.stringify(vehiclesJson)})`);
});

mp.events.add('garage:close', () => {
  if (!browser) return;
  browser.destroy();
  browser = null;
  mp.gui.cursor.show(false, false);
});

mp.events.add('garage:refresh', () => {
  if (!currentGarageId) return;
  mp.events.callRemote('garage:loadVehicles', currentGarageId);
});

mp.events.add('garage:store', () => {
  if (!currentGarageId) return;
  mp.events.callRemote('garage:store', currentGarageId);
  setTimeout(() => mp.events.callRemote('garage:loadVehicles', currentGarageId), 350);
});

mp.events.add('garage:spawn', (vehId) => {
  if (!currentGarageId) return;
  mp.events.callRemote('garage:spawn', currentGarageId, vehId);
  mp.events.call('garage:close');
});
