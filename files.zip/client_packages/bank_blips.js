// client_packages/bank_blips.js
// Client-side bank map blips (reliable in RAGE:MP CEF/GTA V).
// Server sends the list via BANK::BLIPS:SET or client requests via BANK::BLIPS:REQUEST.

const BANK_SPRITE = 108; // Finance icon (change if you want another)
const BANK_COLOR = 2;
const BANK_SCALE = 0.85;

const bankBlips = [];

function clearBankBlips() {
  while (bankBlips.length) {
    const b = bankBlips.pop();
    try { b.destroy(); } catch (e) {}
  }
}

function createBankBlips(list) {
  clearBankBlips();
  if (!Array.isArray(list)) return;

  for (const item of list) {
    if (!item || !item.pos) continue;

    const blip = mp.blips.new(
      item.sprite ?? BANK_SPRITE,
      new mp.Vector3(item.pos.x, item.pos.y, item.pos.z),
      {
        name: item.name || "Bank",
        color: item.color ?? BANK_COLOR,
        scale: item.scale ?? BANK_SCALE,
        shortRange: item.shortRange ?? false, // false => visible globally
        alpha: item.alpha ?? 255,
        dimension: item.dimension ?? 0
      }
    );

    bankBlips.push(blip);
  }
}

// Server -> client: set blip list
mp.events.add("BANK::BLIPS:SET", (jsonStr) => {
  try {
    const list = JSON.parse(jsonStr);
    createBankBlips(list);
  } catch (e) {}
});

mp.events.add("BANK::BLIPS:CLEAR", () => clearBankBlips());

// Auto-request once after client is ready
mp.events.add("playerReady", () => {
  try { mp.events.callRemote("BANK::BLIPS:REQUEST"); } catch (e) {}
});
