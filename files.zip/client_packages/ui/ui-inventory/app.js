// app.js - click select fix + doubleclick use + drag/move + hotbar drag/drop

let inventoryItems = [];
let nearbyDrops = [];
let maxSlots = 30;
let selectedItemId = null;
let weight = 0;
let maxWeight = 0;

const hotbar = { 1: null, 2: null, 3: null, 4: null, 5: null };

const gridEl = document.getElementById('inv-grid');
const subtitleEl = document.getElementById('inv-subtitle');
const weightEl = document.getElementById('inv-weight');
const infoEl = document.getElementById('inv-item-info');
const dropsEl = document.getElementById('inv-drops');

const btnRefreshDrops = document.getElementById('btn-refresh-drops');
const btnClose = document.getElementById('btn-close');

const btnUse = document.getElementById('btn-use');
const btnDrop = document.getElementById('btn-drop');
const btnGive = document.getElementById('btn-give');
const btnSplit = document.getElementById('btn-split');

const modalBackdrop = document.getElementById('inv-modal-backdrop');
const modalTitle = document.getElementById('modal-title');
const modalAmount = document.getElementById('modal-amount');
const modalExtra = document.getElementById('modal-extra');
const modalCancel = document.getElementById('modal-cancel');
const modalConfirm = document.getElementById('modal-confirm');

const hbSlots = document.querySelectorAll('.hb-slot');

let modalAction = null;
let modalItemId = null;

function getTemplate(item) { return item?.template || null; }
function getDisplayName(item) {
  const t = getTemplate(item);
  if (t?.label && String(t.label).trim().length) return String(t.label);
  if (t?.name && String(t.name).trim().length) return String(t.name);
  if (item?.name && String(item.name).trim().length) return String(item.name);
  return 'unknown';
}
function getTechName(item) {
  const t = getTemplate(item);
  if (t?.name && String(t.name).trim().length) return String(t.name).toLowerCase();
  if (item?.name && String(item.name).trim().length) return String(item.name).toLowerCase();
  return 'unknown';
}
function getItemType(item) {
  const t = getTemplate(item);
  return (t?.type || item?.type || 'item');
}
function resolveIcon(item) {
  const t = getTemplate(item);
  const fallback = getTechName(item);
  let icon = t?.icon ? String(t.icon).trim() : '';
  if (icon) {
    if (icon.startsWith('items/')) return icon;
    if (icon.match(/\.(png|jpg|jpeg|webp)$/i)) return `items/${icon}`;
    return `items/${icon}.png`;
  }
  return `items/${fallback}.png`;
}

function buildSlots() {
  gridEl.innerHTML = '';
  for (let i = 1; i <= maxSlots; i++) {
    const slot = document.createElement('div');
    slot.className = 'inv-slot empty';
    slot.dataset.slot = String(i);

    slot.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; slot.classList.add('hover'); });
    slot.addEventListener('dragleave', () => slot.classList.remove('hover'));
    slot.addEventListener('drop', (e) => {
      e.preventDefault();
      slot.classList.remove('hover');
      const itemId = parseInt(e.dataTransfer.getData('text/itemId'));
      if (!itemId) return;
      const slotId = parseInt(slot.dataset.slot);
      if (!slotId) return;
      if (typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:MOVE', itemId, slotId);
    });

    gridEl.appendChild(slot);
  }
}

function setSelected(id) {
  selectedItemId = id;
  // highlight
  document.querySelectorAll('.inv-item.selected').forEach(el => el.classList.remove('selected'));
  const el = document.querySelector(`.inv-item[data-id="${id}"]`);
  if (el) el.classList.add('selected');

  const selected = inventoryItems.find(i => i && i.id === selectedItemId);
  if (infoEl) infoEl.textContent = selected ? `${getDisplayName(selected)} (x${selected.amount || 1}) – Typ: ${getItemType(selected)}` : 'Wähle ein Item aus.';
}

function renderHotbar() {
  hbSlots.forEach(el => {
    const s = parseInt(el.dataset.hb);
    const id = hotbar[s];
    el.classList.toggle('filled', !!id);

    el.ondragover = (e) => { e.preventDefault(); e.dataTransfer.dropEffect='move'; el.classList.add('hover'); };
    el.ondragleave = () => el.classList.remove('hover');
    el.ondrop = (e) => {
      e.preventDefault();
      el.classList.remove('hover');
      const itemId = parseInt(e.dataTransfer.getData('text/itemId'));
      if (!itemId) return;
      hotbar[s] = itemId;
      if (typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:HOTBAR_SET', s, itemId);
      renderHotbar();
    };

    el.onclick = () => {
      const useId = hotbar[s];
      if (useId && typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:USE', useId);
    };

    el.oncontextmenu = (e) => {
      e.preventDefault();
      hotbar[s] = null;
      if (typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:HOTBAR_SET', s, 0);
      renderHotbar();
    };
  });
}

function renderInventory() {
  buildSlots();

  const used = inventoryItems.filter(i => i && i.slot).length;
  if (subtitleEl) subtitleEl.textContent = `Slots: ${used}/${maxSlots}`;
  if (weightEl) weightEl.textContent = `Gewicht: ${Math.round(weight*10)/10}/${Math.round(maxWeight*10)/10}`;

  for (const item of inventoryItems) {
    if (!item || !item.slot) continue;
    const slotEl = gridEl.querySelector(`.inv-slot[data-slot="${item.slot}"]`);
    if (!slotEl) continue;
    slotEl.classList.remove('empty');

    const itemEl = document.createElement('div');
    itemEl.className = 'inv-item';
    itemEl.draggable = true;
    itemEl.dataset.id = String(item.id);

    // IMPORTANT: click select works even with draggable
    itemEl.addEventListener('mousedown', (e) => {
      e.stopPropagation();
      setSelected(item.id);
    });

    // Double click uses item
    itemEl.addEventListener('dblclick', (e) => {
      e.stopPropagation();
      setSelected(item.id);
      if (typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:USE', item.id);
    });

    itemEl.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/itemId', String(item.id));
      e.dataTransfer.effectAllowed = 'move';
    });

    if (selectedItemId === item.id) itemEl.classList.add('selected');

    const iconWrap = document.createElement('div');
    iconWrap.className = 'inv-item-icon';

    const img = document.createElement('img');
    img.src = resolveIcon(item);
    img.alt = getDisplayName(item);
    img.addEventListener('error', () => { img.src = 'items/placeholder.png'; });
    iconWrap.appendChild(img);

    const meta = document.createElement('div');
    meta.className = 'inv-item-meta';

    const nameSpan = document.createElement('span');
    nameSpan.className = 'inv-item-name';
    nameSpan.textContent = getDisplayName(item);

    const amountSpan = document.createElement('span');
    amountSpan.className = 'inv-item-amount';
    amountSpan.textContent = 'x' + (item.amount || 1);

    meta.appendChild(nameSpan);
    meta.appendChild(amountSpan);

    itemEl.appendChild(iconWrap);
    itemEl.appendChild(meta);
    slotEl.appendChild(itemEl);
  }

  if (infoEl) {
    if (selectedItemId) {
      const selected = inventoryItems.find(i => i && i.id === selectedItemId);
      infoEl.textContent = selected ? `${getDisplayName(selected)} (x${selected.amount || 1}) – Typ: ${getItemType(selected)}` : 'Wähle ein Item aus.';
    } else infoEl.textContent = 'Wähle ein Item aus.';
  }

  renderHotbar();
}

function openModal(action, itemId, title, extraHtml) {
  modalAction = action;
  modalItemId = itemId;
  if (modalTitle) modalTitle.textContent = title;
  if (modalAmount) modalAmount.value = '1';
  if (modalExtra) modalExtra.innerHTML = extraHtml || '';
  modalBackdrop?.classList.remove('hidden');
}
function closeModal() { modalBackdrop?.classList.add('hidden'); modalAction=null; modalItemId=null; }

modalCancel?.addEventListener('click', closeModal);
modalConfirm?.addEventListener('click', () => {
  if (!modalAction || !modalItemId) { closeModal(); return; }
  const val = parseInt(modalAmount?.value) || 1;

  if (modalAction === 'drop') if (typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:DROP', modalItemId, val);
  if (modalAction === 'give') if (typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:GIVE', '', modalItemId, val);
  if (modalAction === 'split') if (typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:SPLIT', modalItemId, val);

  closeModal();
});

btnUse?.addEventListener('click', () => { if (selectedItemId && typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:USE', selectedItemId); });
btnDrop?.addEventListener('click', () => { if (selectedItemId) openModal('drop', selectedItemId, 'Drop', ''); });
btnGive?.addEventListener('click', () => { if (selectedItemId) openModal('give', selectedItemId, 'Geben (nächster Spieler)', ''); });
btnSplit?.addEventListener('click', () => { if (selectedItemId) openModal('split', selectedItemId, 'Split', ''); });
btnClose?.addEventListener('click', () => { if (typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:CLOSE'); });
btnRefreshDrops?.addEventListener('click', () => { if (typeof mp !== 'undefined') mp.trigger('CLIENT::INVENTORY:REFRESH_DROPS'); });

document.addEventListener('contextmenu', (e) => { e.preventDefault(); });

// Payload from server
window.setInventoryData = function (json, slots) {
  let parsed = null;
  try { parsed = JSON.parse(json); } catch (e) { parsed = null; }

  if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
    inventoryItems = Array.isArray(parsed.items) ? parsed.items : [];
    nearbyDrops = Array.isArray(parsed.drops) ? parsed.drops : [];
    weight = parsed.weight || 0;
    maxWeight = parsed.maxWeight || 0;
  } else if (Array.isArray(parsed)) {
    inventoryItems = parsed;
    nearbyDrops = [];
    weight = 0; maxWeight = 0;
  } else {
    inventoryItems = [];
    nearbyDrops = [];
    weight = 0; maxWeight = 0;
  }

  maxSlots = slots || 30;
  renderInventory();

  // keep selection highlight
  if (selectedItemId) setSelected(selectedItemId);
};

buildSlots();
renderInventory();
