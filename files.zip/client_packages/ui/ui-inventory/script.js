const INVENTORY_SLOTS = 50;
let items = [];
let groundItems = [];
let selectedItemId = null;
let groundRefreshTimer = null;

$(document).ready(function () {
    initInventory();
    bindGlobalEvents();
});

async function initInventory() {
    buildSlots();
    await loadItems();
    await loadGroundItems();
    renderItems();
    setupDragAndDrop();
    updateMeta();

    if (groundRefreshTimer) clearInterval(groundRefreshTimer);
    groundRefreshTimer = setInterval(async () => {
        await loadGroundItems();
    }, 3000);
}

function buildSlots() {
    const grid = $("#inventory-grid");
    grid.empty();

    for (let i = 1; i <= INVENTORY_SLOTS; i++) {
        const slot = $(`
            <div class="inventory-slot empty" data-slot="${i}">
                <div class="inventory-slot-content"></div>
            </div>
        `);
        grid.append(slot);
    }
}

async function loadItems() {
    try {
        let raw = await mp.events.callProc("CLIENT::FETCH:ITEMS");
        if (!raw) raw = "[]";
        items = JSON.parse(raw);
    } catch (e) {
        console.log("Failed to load items", e);
        items = [];
    }
}

async function loadGroundItems() {
    try {
        let raw = await mp.events.callProc("CLIENT::FETCH:DROPPED_ITEMS");
        if (!raw) raw = "[]";
        groundItems = JSON.parse(raw);
    } catch (e) {
        console.log("Failed to load dropped items", e);
        groundItems = [];
    }
    renderGroundItems();
}

function renderItems() {
    $(".inventory-slot").addClass("empty").find(".inventory-slot-content").empty();

    items.forEach((item) => {
        const slot = $(`.inventory-slot[data-slot="${item.slot}"]`);
        if (!slot.length) return;

        slot.removeClass("empty");
        const content = slot.find(".inventory-slot-content");

        const label = item.label || item.displayName || item.name || "Item";
        const amount = item.amount || item.quantity || 1;

        const element = $(`
            <div class="item" data-id="${item.id}">
                <div class="item-icon">
                    <img src="./items/${item.name}.png" alt="${label}">
                </div>
                <div class="item-info">
                    <span class="item-name">${label}</span>
                    <span class="item-amount">x${amount}</span>
                </div>
            </div>
        `);

        content.append(element);
    });

    bindItemEvents();
    setupDragAndDrop();
}

function renderGroundItems() {
    const list = $("#ground-list");
    list.empty();

    if (!groundItems || groundItems.length === 0) {
        list.append('<div class="ground-empty">Keine Items in der Nähe.</div>');
        return;
    }

    groundItems.forEach(drop => {
        const label = drop.label || drop.displayName || drop.name || "Item";
        const amount = drop.amount || drop.quantity || 1;
        const distance = typeof drop.distance === "number"
            ? drop.distance.toFixed(1)
            : drop.distance;

        const row = $(`
            <div class="ground-item" data-id="${drop.id}">
                <div class="ground-main">
                    <span class="ground-name">${label}</span>
                    <span class="ground-amount">x${amount}</span>
                </div>
                <div class="ground-meta">${distance} m</div>
            </div>
        `);

        row.on("click", function () {
            const id = parseInt($(this).data("id"));
            mp.trigger("CLIENT::PICKUP:DROPPED_ITEM", id);
        });

        list.append(row);
    });
}

function bindItemEvents() {
    $(".item").off("click contextmenu");

    $(".item").on("click", function (e) {
        e.preventDefault();
        const id = parseInt($(this).data("id"));
        selectItem(id);
    });

    $(".item").on("contextmenu", function (e) {
        e.preventDefault();
        const id = parseInt($(this).data("id"));
        selectItem(id);
        openContextMenu(e.clientX, e.clientY);
    });
}

function selectItem(id) {
    selectedItemId = id;
    $(".item").removeClass("selected");
    $(`.item[data-id="${id}"]`).addClass("selected");
}

function setupDragAndDrop() {
    $(".item").draggable({
        revert: "invalid",
        containment: ".inventory-wrapper",
        scroll: false,
        start: function () {
            $(this).addClass("dragging");
        },
        stop: function () {
            $(this).removeClass("dragging");
        }
    });

    $(".inventory-slot").droppable({
        hoverClass: "slot-hover",
        drop: function (event, ui) {
            const targetSlot = $(this);
            const targetSlotId = parseInt(targetSlot.data("slot"));

            const draggedItem = ui.draggable;
            const fromSlot = draggedItem.closest(".inventory-slot");
            const fromSlotId = parseInt(fromSlot.data("slot"));

            if (fromSlotId === targetSlotId) return;

            const draggedItemId = parseInt(draggedItem.data("id"));
            const targetItem = targetSlot.find(".item");

            if (targetItem.length) {
                const targetItemId = parseInt(targetItem.data("id"));

                const originContent = fromSlot.find(".inventory-slot-content");
                const targetContent = targetSlot.find(".inventory-slot-content");

                targetItem.detach().appendTo(originContent);
                draggedItem.detach().appendTo(targetContent);

                fromSlot.removeClass("empty");
                targetSlot.removeClass("empty");

                const dragged = items.find(i => i.id === draggedItemId);
                const target = items.find(i => i.id === targetItemId);

                if (dragged) dragged.slot = targetSlotId;
                if (target) target.slot = fromSlotId;

                mp.trigger("CLIENT::MOVE:ITEM", draggedItemId, targetSlotId);
                mp.trigger("CLIENT::MOVE:ITEM", targetItemId, fromSlotId);
            } else {
                const originContent = fromSlot.find(".inventory-slot-content");
                const targetContent = targetSlot.find(".inventory-slot-content");

                draggedItem.detach().appendTo(targetContent);
                targetSlot.removeClass("empty");
                originContent.empty();
                fromSlot.addClass("empty");

                const dragged = items.find(i => i.id === draggedItemId);
                if (dragged) dragged.slot = targetSlotId;

                mp.trigger("CLIENT::MOVE:ITEM", draggedItemId, targetSlotId);
            }
        }
    });
}

function updateMeta() {
    const used = items.length;
    const max = INVENTORY_SLOTS;
    let totalWeight = 0;

    items.forEach((item) => {
        const amount = item.amount || item.quantity || 1;
        const weight = item.weight || 0;
        totalWeight += amount * weight;
    });

    $("#inventory-meta").text(
        `Slots: ${used}/${max} • Gewicht: ${totalWeight.toFixed(1)} kg`
    );
}

function bindGlobalEvents() {
    $("#inventory-close").on("click", function () {
        closeInventory();
    });

    $("#context-menu .context-menu-item").on("click", function () {
        const action = $(this).data("action");
        if (!selectedItemId) {
            closeContextMenu();
            return;
        }
        handleContextAction(action, selectedItemId);
        closeContextMenu();
    });

    $(document).on("click", function (e) {
        if (!$(e.target).closest("#context-menu").length) {
            closeContextMenu();
        }
    });

    $(document).on("contextmenu", function (e) {
        e.preventDefault();
    });
}

function openContextMenu(x, y) {
    const menu = $("#context-menu");
    menu.css({ left: x + "px", top: y + "px" });
    menu.show();
}

function closeContextMenu() {
    $("#context-menu").hide();
}

function handleContextAction(action, itemId) {
    switch (action) {
        case "use":
            useItem(itemId);
            break;
        case "drop":
            dropItem(itemId);
            break;
        case "give":
            giveItem(itemId);
            break;
    }
}

function useItem(itemId) {
    const item = items.find(i => i.id === parseInt(itemId));
    if (!item) return;

    const slot = $(`.inventory-slot[data-slot="${item.slot}"]`);
    const amount = item.amount || item.quantity || 1;

    if (amount <= 1) {
        slot.addClass("empty");
        slot.find(".inventory-slot-content").empty();
        items = items.filter(i => i.id !== item.id);
    } else {
        item.amount = amount - 1;
        renderItems();
    }

    mp.trigger("CLIENT::USE:ITEM", item.id);
    updateMeta();
}

function dropItem(itemId) {
    const item = items.find(i => i.id === parseInt(itemId));
    if (!item) return;

    const amount = item.amount || item.quantity || 1;
    let dropAmount = 1;

    if (amount > 1) {
        const input = prompt(`Menge droppen (1 - ${amount}):`, `${amount}`);
        if (!input) return;
        const parsed = parseInt(input);
        if (isNaN(parsed) || parsed < 1 || parsed > amount) return;
        dropAmount = parsed;
    }

    const slot = $(`.inventory-slot[data-slot="${item.slot}"]`);

    if (dropAmount === amount) {
        slot.addClass("empty");
        slot.find(".inventory-slot-content").empty();
        items = items.filter(i => i.id !== item.id);
    } else {
        item.amount = amount - dropAmount;
        renderItems();
    }

    mp.trigger("CLIENT::DROP:ITEM", item.id, dropAmount);
    updateMeta();
}

async function giveItem(itemId) {
    const item = items.find(i => i.id === parseInt(itemId));
    if (!item) return;

    const amount = item.amount || item.quantity || 1;
    let giveAmount = 1;

    if (amount > 1) {
        const input = prompt(`Menge geben (1 - ${amount}):`, "1");
        if (!input) return;
        const parsed = parseInt(input);
        if (isNaN(parsed) || parsed < 1 || parsed > amount) return;
        giveAmount = parsed;
    }

    let nearby = [];
    try {
        let raw = await mp.events.callProc("CLIENT::FETCH:NEARBY_PLAYERS");
        if (raw) nearby = JSON.parse(raw);
    } catch (e) {
        nearby = [];
    }

    if (!nearby || nearby.length === 0) {
        alert("Kein Spieler in der Nähe.");
        return;
    }

    const lines = nearby.map((p, idx) => {
        const dist = typeof p.distance === "number" ? p.distance.toFixed(1) : p.distance;
        return `${idx + 1}) ${p.name} (${dist} m)`;
    });

    const choice = prompt("Spieler auswählen:\n" + lines.join("\\n"), "1");
    if (!choice) return;
    const idx = parseInt(choice) - 1;
    if (isNaN(idx) || idx < 0 || idx >= nearby.length) return;

    const target = nearby[idx];

    const slot = $(`.inventory-slot[data-slot="${item.slot}"]`);

    if (giveAmount === amount) {
        slot.addClass("empty");
        slot.find(".inventory-slot-content").empty();
        items = items.filter(i => i.id !== item.id);
    } else {
        item.amount = amount - giveAmount;
        renderItems();
    }

    mp.trigger("CLIENT::GIVE:ITEM", item.id, parseInt(target.id), giveAmount);
    updateMeta();
}

function closeInventory() {
    mp.trigger("CLIENT::INVENTORY:CLOSE");
}

window.refreshInventory = async function () {
    await loadItems();
    await loadGroundItems();
    renderItems();
    updateMeta();
};
