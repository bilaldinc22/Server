/* global mp */
(() => {
  const $ = (id) => document.getElementById(id);

  const cashBal = $('cashBal');
  const bankBal = $('bankBal');
  const accountSelect = $('accountSelect');
  const ownIban = $('ownIban');
  const ownAcc = $('ownAcc');
  const contextLine = $('contextLine');
  const tabsEl = $('tabs');
  const toast = $('toast');
  const accountBtn = $('accountBtn');
  const accountMenu = $('accountMenu');
  const accountLabel = $('accountLabel');

  const roleBtn = $('roleBtn');
  const roleMenu = $('roleMenu');
  const roleLabel = $('roleLabel');

  const PANELS = [
    { key: 'overview', label: 'Overview' },
    { key: 'transfer', label: 'Transfer' },
    { key: 'invoices', label: 'Invoices' },
    { key: 'standing', label: 'Standing Orders' },
    { key: 'company', label: 'Company' },
    { key: 'history', label: 'History' },
    { key: 'security', label: 'Security' },
  ];

  let state = {
    context: { where: 'BANK', restrictions: {} },
    cash: 0,
    personal: { iban: '—', account: '—' },
    accounts: [],
    activeIban: '',
    invoicesIn: [],
    invoicesOut: [],
    standingOrders: [],
    companyMembers: {}, // iban -> members
    history: [],
    security: { hasPin: false, lockedUntil: 0 },
    ui: { historyFilter: '', historyPage: 1, invInFilter: '', invOutFilter: '', memberFilter: '' }
  };

  function fmt(n){
    const x = Number(n) || 0;
    return x.toLocaleString('de-DE');
  }

  function showToast(message, ok=true){
    toast.textContent = message;
    toast.className = 'toast ' + (ok ? 'ok' : 'bad');
    toast.style.display = 'block';
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toast.style.display = 'none', 2200);
  }

  function setActivePanel(key){
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.key === key));
    document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.dataset.panel === key));
  }

  function renderTabs(){
    tabsEl.innerHTML = '';
    const restrictions = state.context?.restrictions || {};
    PANELS.forEach(p => {
      if (restrictions.hiddenPanels && restrictions.hiddenPanels.includes(p.key)) return;
      const tab = document.createElement('div');
      tab.className = 'tab';
      tab.dataset.key = p.key;
      tab.textContent = p.label;
      tab.addEventListener('click', () => setActivePanel(p.key));
      tabsEl.appendChild(tab);
    });
    // default
    const first = tabsEl.querySelector('.tab');
    if (first) setActivePanel(first.dataset.key);
  }

  function renderAccounts(){
    // Keep hidden native select in sync (for compatibility), but use custom dropdown UI.
    if (accountSelect) accountSelect.innerHTML = '';
    if (accountMenu) accountMenu.innerHTML = '';

    state.accounts.forEach(acc => {
      if (accountSelect) {
        const opt = document.createElement('option');
        opt.value = acc.iban;
        opt.textContent = `${acc.name} (${acc.type}) • ${fmt(acc.balance)}$`;
        if (acc.iban === state.activeIban) opt.selected = true;
        accountSelect.appendChild(opt);
      }

      if (accountMenu) {
        const item = document.createElement('div');
        item.className = 'dd-item';
        item.innerHTML = `<span>${acc.name} <span class="muted">(${acc.type})</span></span><span class="muted">${fmt(acc.balance)}$</span>`;
        item.addEventListener('click', () => {
          setActiveAccount(acc.iban);
          closeAccountMenu();
        });
        accountMenu.appendChild(item);
      }
    });

    // Update label
    const current = state.accounts.find(a => a.iban === state.activeIban) || state.accounts[0];
    if (current && accountLabel) {
      accountLabel.textContent = `${current.name} (${current.type}) • ${fmt(current.balance)}$`;
    }
  }

  function renderInvoices(){
    const inEl = $('invIncoming');
    const outEl = $('invOutgoing');

    const makeHeader = (cols) => {
      const h = document.createElement('div');
      h.className = 'trow header';
      cols.forEach(c => {
        const d = document.createElement('div');
        d.textContent = c;
        h.appendChild(d);
      });
      return h;
    };

    const rowIncoming = (inv) => {
      const r = document.createElement('div');
      r.className = 'trow';
      r.innerHTML = `
        <div>${inv.id}</div>
        <div>${inv.from}</div>
        <div class="right">${fmt(inv.amount)}$</div>
        <div class="actions">
          <button class="btn" data-pay="${inv.id}">Pay</button>
          <input style="max-width:120px" placeholder="PIN" inputmode="numeric" data-pin="${inv.id}"/>
        </div>
      `;
      r.querySelector(`[data-pay="${inv.id}"]`).addEventListener('click', () => {
        const pin = r.querySelector(`[data-pin="${inv.id}"]`).value || '';
        mp?.trigger('BANK:INVOICE:PAY', inv.id, pin);
      });
      return r;
    };

    const rowOutgoing = (inv) => {
      const r = document.createElement('div');
      r.className = 'trow';
      r.innerHTML = `
        <div>${inv.id}</div>
        <div>${inv.to}</div>
        <div class="right">${fmt(inv.amount)}$</div>
        <div class="actions">
          <span class="badge">${inv.status}</span>
          <button class="btn bad" data-cancel="${inv.id}">Cancel</button>
        </div>
      `;
      r.querySelector(`[data-cancel="${inv.id}"]`).addEventListener('click', () => mp?.trigger('BANK:INVOICE:CANCEL', inv.id));
      return r;
    };

    inEl.innerHTML = '';
    inEl.appendChild(makeHeader(['ID','From','Amount','Actions']));
    (state.invoicesIn || []).forEach(inv => inEl.appendChild(rowIncoming(inv)));

    outEl.innerHTML = '';
    outEl.appendChild(makeHeader(['ID','To','Amount','Actions']));
    (state.invoicesOut || []).forEach(inv => outEl.appendChild(rowOutgoing(inv)));
  }

  function renderStandingOrders(){
    const el = $('soList');

    const header = document.createElement('div');
    header.className = 'trow header';
    header.innerHTML = `<div>ID</div><div>Target</div><div class="right">Amount</div><div>Actions</div>`;

    el.innerHTML = '';
    el.appendChild(header);

    (state.standingOrders || []).forEach(so => {
      const r = document.createElement('div');
      r.className = 'trow';
      r.innerHTML = `
        <div>${so.id}</div>
        <div>${so.target} • every ${so.intervalHours}h</div>
        <div class="right">${fmt(so.amount)}$</div>
        <div class="actions">
          <button class="btn" data-toggle="${so.id}">${so.enabled ? 'Disable' : 'Enable'}</button>
          <button class="btn bad" data-del="${so.id}">Delete</button>
        </div>
      `;
      r.querySelector(`[data-toggle="${so.id}"]`).addEventListener('click', () => mp?.trigger('BANK:SO:TOGGLE', so.id, !so.enabled));
      r.querySelector(`[data-del="${so.id}"]`).addEventListener('click', () => mp?.trigger('BANK:SO:DELETE', so.id));
      el.appendChild(r);
    });
  }

  function renderCompanyMembers(){
    const el = $('coMembers');
    const iban = state.activeIban;
    const allMembers = (state.companyMembers && state.companyMembers[iban]) ? state.companyMembers[iban] : [];
    const mf = (state.ui?.memberFilter || '').toLowerCase();
    const members = allMembers.filter(m => {
      if (!mf) return true;
      return `${m.character_id} ${m.character_name}`.toLowerCase().includes(mf);
    });

    const header = document.createElement('div');
    header.className = 'trow header';
    header.innerHTML = `<div>ID</div><div>Name</div><div class="right">Role</div><div>Actions</div>`;
    el.innerHTML = '';
    el.appendChild(header);

    members.forEach(m => {
      const r = document.createElement('div');
      r.className = 'trow';
      r.innerHTML = `
        <div>${m.character_id}</div>
        <div>${m.character_name}</div>
        <div class="right">${m.role}</div>
        <div class="actions">
          <select data-role="${m.character_id}" style="max-width:140px">
            <option value="member">member</option>
            <option value="treasurer">treasurer</option>
            <option value="owner">owner</option>
          </select>
          <button class="btn" data-save="${m.character_id}">Save</button>
          <button class="btn bad" data-rm="${m.character_id}">Remove</button>
        </div>
      `;
      const sel = r.querySelector(`[data-role="${m.character_id}"]`);
      sel.value = m.role;
      r.querySelector(`[data-save="${m.character_id}"]`).addEventListener('click', () => {
        mp?.trigger('BANK:COMPANY:MEMBER_ROLE', iban, m.character_id, sel.value);
      });
      r.querySelector(`[data-rm="${m.character_id}"]`).addEventListener('click', () => {
        mp?.trigger('BANK:COMPANY:MEMBER_REMOVE', iban, m.character_id);
      });
      el.appendChild(r);
    });
  }

  function renderHistory(){
    const el = $('historyList');
    const f = (state.ui?.historyFilter || '').toLowerCase();
    const per = 20;
    const page = Math.max(1, parseInt(state.ui?.historyPage || 1, 10));
    const filtered = (state.history || []).filter(h => {
      if (!f) return true;
      return `${h.type||''} ${h.info||''}`.toLowerCase().includes(f);
    });
    const pages = Math.max(1, Math.ceil(filtered.length / per));
    state.ui.historyPage = Math.min(page, pages);
    const start = (state.ui.historyPage - 1) * per;
    const items = filtered.slice(start, start + per);
    const pageEl = $('histPage');
    if (pageEl) pageEl.textContent = `${state.ui.historyPage}/${pages}`;
    const header = document.createElement('div');
    header.className = 'trow header';
    header.innerHTML = `<div>Date</div><div>Type</div><div class="right">Amount</div><div>Info</div>`;
    el.innerHTML = '';
    el.appendChild(header);

        items.forEach(h => {
      const r = document.createElement('div');
      r.className = 'trow';
      r.innerHTML = `
        <div>${h.date}</div>
        <div>${h.type}</div>
        <div class="right">${fmt(h.amount)}$</div>
        <div>${h.info}</div>
      `;
      el.appendChild(r);
    });
  }

  function renderSecurity(){
    const el = $('pinStatus');
    const lockedUntil = Number(state.security?.lockedUntil || 0);
    const locked = lockedUntil > Date.now();
    const hasPin = !!state.security?.hasPin;

    el.textContent = locked
      ? `Account locked until ${new Date(lockedUntil).toLocaleString('de-DE')}`
      : (hasPin ? 'PIN active' : 'No PIN set');
  }

  function applyState(){
    cashBal.textContent = fmt(state.cash) + '$';
    bankBal.textContent = fmt(state.accounts.find(a => a.iban === state.activeIban)?.balance ?? 0) + '$';
    ownIban.textContent = state.personal.iban || '—';
    ownAcc.textContent = state.personal.account || '—';
    const where = state.context?.where || 'BANK';
    const r = state.context?.restrictions || {};
    const fee = (where === 'ATM' && r.atmFeePercent != null) ? ` • ATM fee ${r.atmFeePercent}%` : '';
    contextLine.textContent = `Context: ${where}${fee}`;

    // Apply ATM restrictions
    const depCard = $('depositCard');
    const depBtn = $('btnDeposit');
    const depInp = $('depositAmount');
    if (r.disableDeposit){
      if (depCard) depCard.style.display = 'none';
      if (depBtn) depBtn.disabled = true;
      if (depInp) depInp.disabled = true;
    } else {
      if (depCard) depCard.style.display = '';
      if (depBtn) depBtn.disabled = false;
      if (depInp) depInp.disabled = false;
    }

    const wHint = $('withdrawHint');
    if (wHint){
      wHint.textContent = (where === 'ATM' && r.atmFeePercent != null)
        ? `Moves active account → cash. ATM fee: ${r.atmFeePercent}% (debited from account).`
        : 'Moves active account → cash.';
    }

    renderTabs();
    renderAccounts();
    renderInvoices();
    renderStandingOrders();
    renderCompanyMembers();
    renderHistory();
    renderSecurity();
  }

  // Public API called by client_packages/bank.js
  window.bankSetData = (payload) => {
    try {
      state = Object.assign(state, payload || {});
      if (!state.activeIban && state.accounts && state.accounts[0]) state.activeIban = state.accounts[0].iban;
      applyState();
    } catch (e) {
      // ignore
    }
  };

  window.bankNotify = (message, ok) => showToast(message, !!ok);


  function openAccountMenu(){
    if (!accountMenu) return;
    accountMenu.style.display = 'block';
  }
  function closeAccountMenu(){
    if (!accountMenu) return;
    accountMenu.style.display = 'none';
  }
  function toggleAccountMenu(){
    if (!accountMenu) return;
    const d = accountMenu.style.display;
    if (!d || d === 'none') openAccountMenu(); else closeAccountMenu();
  }
  function setActiveAccount(iban){
    if (!iban) return;
    state.activeIban = iban;
    if (accountSelect) accountSelect.value = iban;
    // Update label
    const current = state.accounts.find(a => a.iban === iban);
    if (current && accountLabel) accountLabel.textContent = `${current.name} (${current.type}) • ${fmt(current.balance)}$`;
    try { mp?.trigger('BANK:SET_ACTIVE', iban); } catch(e) {}
  }

  function initRoleDropdown(){
    if (!roleMenu || !roleBtn) return;
    const roles = [
      { value: 'member', label: 'member' },
      { value: 'treasurer', label: 'treasurer' },
      { value: 'owner', label: 'owner' },
    ];

    roleMenu.innerHTML = '';
    roles.forEach(r => {
      const item = document.createElement('div');
      item.className = 'dd-item';
      item.innerHTML = `<span>${r.label}</span>`;
      item.addEventListener('click', () => {
        const sel = $('coMemberRole');
        if (sel) sel.value = r.value;
        if (roleLabel) roleLabel.textContent = r.label;
        roleMenu.style.display = 'none';
      });
      roleMenu.appendChild(item);
    });

    roleBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      roleMenu.style.display = (roleMenu.style.display === 'block') ? 'none' : 'block';
    });
  }

  // UI actions
  $('btnClose').addEventListener('click', () => mp?.trigger('BANK:UI:CLOSE'));

  // Custom account dropdown (CEF safe)
  if (accountBtn) {
    accountBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleAccountMenu();
    });
  }

  // Fallback: if hidden select changes (programmatic), keep state in sync
  if (accountSelect) {
    accountSelect.addEventListener('change', () => setActiveAccount(accountSelect.value));
  }

  // Close dropdown on outside click
  document.addEventListener('click', () => {
    closeAccountMenu();
    if (roleMenu) roleMenu.style.display = 'none';
  });

  $('btnDeposit').addEventListener('click', () => mp?.trigger('BANK:DEPOSIT', $('depositAmount').value));
  $('btnWithdraw').addEventListener('click', () => mp?.trigger('BANK:WITHDRAW', $('withdrawAmount').value, $('withdrawPin').value));
  $('btnTransfer').addEventListener('click', () => mp?.trigger('BANK:TRANSFER', $('transferTarget').value, $('transferAmount').value, $('transferPin').value));

  $('btnInvCreate').addEventListener('click', () => mp?.trigger('BANK:INVOICE:CREATE', $('invTarget').value, $('invAmount').value, $('invReason').value));

  $('btnSoCreate').addEventListener('click', () => mp?.trigger('BANK:SO:CREATE', $('soTarget').value, $('soAmount').value, $('soInterval').value, $('soReason').value, $('soPin').value));

  $('btnCoCreate').addEventListener('click', () => mp?.trigger('BANK:COMPANY:CREATE', $('coName').value));

  $('btnCoAddMember').addEventListener('click', () => {
    const iban = state.activeIban;
    mp?.trigger('BANK:COMPANY:MEMBER_ADD', iban, $('coMemberName').value, $('coMemberRole').value);
  });

  $('btnPinSet').addEventListener('click', () => mp?.trigger('BANK:PIN:SET', $('pinSet').value));
  $('btnPinChange').addEventListener('click', () => mp?.trigger('BANK:PIN:CHANGE', $('pinOld').value, $('pinNew').value));


  // Filters / pagination
  const hf = $('historyFilter');
  if (hf){
    hf.addEventListener('input', () => { state.ui.historyFilter = hf.value || ''; state.ui.historyPage = 1; renderHistory(); });
  }
  const ipIn = $('invInSearch');
  if (ipIn){
    ipIn.addEventListener('input', () => { state.ui.invInFilter = ipIn.value || ''; renderInvoices(); });
  }
  const ipOut = $('invOutSearch');
  if (ipOut){
    ipOut.addEventListener('input', () => { state.ui.invOutFilter = ipOut.value || ''; renderInvoices(); });
  }
  const ms = $('coMemberSearch');
  if (ms){
    ms.addEventListener('input', () => { state.ui.memberFilter = ms.value || ''; renderCompanyMembers(); });
  }
  const prev = $('histPrev');
  const next = $('histNext');
  if (prev) prev.addEventListener('click', () => { state.ui.historyPage = Math.max(1, (state.ui.historyPage||1) - 1); renderHistory(); });
  if (next) next.addEventListener('click', () => { state.ui.historyPage = (state.ui.historyPage||1) + 1; renderHistory(); });

  // Enter key helpers
  document.querySelectorAll('input').forEach(inp => {
    inp.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const id = inp.id;
      if (id === 'depositAmount') $('btnDeposit').click();
      if (id === 'withdrawAmount' || id === 'withdrawPin') $('btnWithdraw').click();
      if (id === 'transferTarget' || id === 'transferAmount' || id === 'transferPin') $('btnTransfer').click();
      if (id === 'invTarget' || id === 'invAmount' || id === 'invReason') $('btnInvCreate').click();
    });
  });

    initRoleDropdown();

  // Notify client that UI is ready
  try { mp?.trigger('BANK:UI:READY'); } catch(e) {}
})();
