const player = mp.players.local;
var characterCam;
var characterBrowser;
let active = false;

mp.events.add("CLIENT::OPEN:CHARACTER:CREATOR", () => {
    mp.events.call('CLIENT::REMOVE:LOGIN:BROWSER');
    characterBrowser = mp.browsers.new(`package://ui/ui-character/index.html`);
});

mp.events.add('CLIENT::OPEN:CHARACTER:CREATOR:WITH:CHARACTERS', async (name) => {
    mp.events.call('CLIENT::REMOVE:LOGIN:BROWSER');
    characterBrowser = mp.browsers.new(`package://ui/ui-character/index.html`);
    
       await name.forEach((character) => {
            characterBrowser.execute(`showCharacters('${character.character_name}')`);
        });
});
//==============================================================================================================================================================

// SYSTEM SLIDERS 

mp.events.add("CLIENT::CHANGE:ZOOM", (value) => {
    characterCam.setCoord(-797.7529907226562, 326.41558837890625 - parseFloat(value), 220.43862915039062);
    mp.game.cam.renderScriptCams(true, false, 0, true, false);
});

mp.events.add("CLIENT::CHANGE:CAMERA:HEIGHT", (value) => {
    characterCam.pointAtCoord(-797.7529907226562, 326.41558837890625, 220.43862915039062 + parseFloat(value));
    mp.game.cam.renderScriptCams(true, false, 0, true, false);
});

mp.events.add("CLIENT::CHANGE:ROTATION", (value) => {
    mp.events.callRemote("SERVER::CHANGE:ROTATION", value);
});


mp.events.addProc('CLIENT::CHECK:CHARACTER:SLOTS', async () => {
   const response = await mp.events.callRemoteProc('SERVER::CHECK:CHARACTER:SLOTS');
    if(!response) return;
   if(response > 0) {
        mp.game.streaming.requestIpl('apa_v_mp_h_01_a'); 
        player.position = new mp.Vector3(-797.7529907226562, 326.41558837890625, 220.43862915039062); 
        player.heading = 90;
        characterCam = mp.cameras.new('default', new mp.Vector3(-797.6807861328125, 330.9203186035156, 220.43862915039062), new mp.Vector3(0, 0, 0), 40);
        characterCam.pointAtCoord(-797.7529907226562, 326.41558837890625, 220.43862915039062);
        mp.game.graphics.transitionFromBlurred(1); 
        mp.game.cam.renderScriptCams(true, false, 0, true, false);
   }

   return JSON.stringify(response);
});

mp.events.add('CLIENT::SPAWN:PLAYER', (x, y, z) => { // remove login cam and the blur screen
    mp.gui.cursor.show(false, false);
    characterBrowser.destroy();

    setTimeout(() => {  
     mp.game.graphics.transitionFromBlurred(1); 
      mp.game.ui.displayRadar(true);
      mp.game.cam.renderScriptCams(false, false, 0, false, false);
      player.position = new mp.Vector3(x, y, z); 
      player.freezePosition(false);
      mp.gui.chat.activate(true); 
      mp.gui.chat.show(true); 
    }, 1500);

});

mp.events.add('CLIENT::CREATE:CHARACTER', (name, age, accent, features) => {
    
    const characterData = `{

        "gender": "${value_gender}",
        "name": "${name}",
        "age": "${age}",
        "accent": "${accent}",
        "features": "${features}",
        "mom": "${value_mom}",
        "dad": "${value_dad}",
        "shapeMix": "${value_shapeMix}",
        "skin1": "${value_skin1}",
        "skin2": "${value_skin2}",
        "skinMix": "${value_skinMix}",
        "noseWidth": "${value_noseWidth}",
        "noseHeight": "${value_noseHeight}",
        "noseTip": "${value_noseTip}",

        "jawWidth": "${value_jawWidth}",
        "jawHeight": "${value_jawHeight}",
        "chinWidth": "${value_chinWidth}",
        "chinLength": "${value_chinLength}",
        "neckWidth": "${value_neckWidth}",
        "eyes": "${value_eyes}",
        "eyesColor": "${value_eyesColor}",
        "eyebrows": "${value_eyebrows}",
        "lips": "${value_lips}",

        "hairStyle": "${value_hairStyle}",
        "hairColor": "${value_hairColor}",
        "beard": "${value_beard}",
        "beardColor": "${value_beardColor}",

        "tops": "${value_tops}",
        "topsColor": "${value_topsColor}",

        "legs": "${value_legs}",
        "legsColor": "${value_legsColor}",

        "undershirt": "${value_undershirt}",
        "undershirtColor": "${value_undershirtColor}",
        "torso": "${value_torso}",
        "shoes": "${value_shoes}",
        "shoesColor": "${value_shoesColor}"
        
    }`;
    mp.events.callRemote("SERVER::CREATE:CHARACTER", characterData);
});


mp.events.add('CLIENT::PLAY:CHARACTER', (characterName) => {
    mp.events.callRemote("SERVER::PLAY:CHARACTER", characterName);
});

// Freeze Character in creator
mp.events.add("render", () => {
    const freeze = player.getVariable("freeze");
    if(freeze == true) {
        player.clearTasksImmediately();
    }
});


// Defines
let value_gender = true;

let value_mom = 0;
let value_dad = 0;
let value_shapeMix = 0;
let value_skin1 = 0;
let value_skin2 = 0;
let value_skinMix = 0;
let value_noseWidth = 0;
let value_noseHeight = 0;
let value_noseTip = 0;

let value_jawWidth = 0;
let value_jawHeight = 0;
let value_chinWidth = 0;
let value_chinLength = 0;
let value_neckWidth = 0;
let value_eyes = 0;
let value_eyesColor = 0;
let value_eyebrows = 0;
let value_lips = 0;


let value_hairStyle = 0;
let value_hairColor = 0;
let value_beard = 0;
let value_beardColor = 0;

// Clothes Defines
let value_tops = 0;
let value_topsColor = 0;

let value_legs = 0;
let value_legsColor = 0;

let value_undershirt = 15;
let value_undershirtColor = 0;
let value_torso = 0;

let value_shoes = 0;
let value_shoesColor = 0;


// Events
mp.events.add('CLIENT::CHANGE:GENDER', (value) => {


    switch(value) {

        case 0: 
        {
            player.model = mp.game.joaat("mp_m_freemode_01"); 
            value_gender = true;
            break;
        }

        case 1: 
        {
            player.model = mp.game.joaat("mp_f_freemode_01"); 
            value_gender = false;
            break;
        }
    }

});


mp.events.add("CLIENT::CHANGE:MOM", (value) => {
    value_mom = parseInt(value);
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:DAD", (value) => {
    value_dad = parseInt(value);
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:SHAPE:MIX", (value) => {
    value_shapeMix = value;
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:SKIN:1", (value) => {
    value_skin1 = parseInt(value);
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:SKIN:2", (value) => {
    value_skin2 = parseInt(value);
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:SKIN:MIX", (value) => {
    value_skinMix = value;
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:NOSE:WIDTH", (value) => {
    value_noseWidth = value;
    player.setFaceFeature(0, value_noseWidth);
});

mp.events.add("CLIENT::CHANGE:NOSE:HEIGHT", (value) => {
    value_noseHeight = value;
    player.setFaceFeature(1, value_noseHeight);
});

mp.events.add("CLIENT::CHANGE:NOSE:TIP", (value) => {
    value_noseTip = value;
    player.setFaceFeature(4, value_noseTip);
});

mp.events.add("CLIENT::CHANGE:JAW:WIDTH", (value) => {
    value_jawWidth = value;
    player.setFaceFeature(13, value_jawWidth);
});

mp.events.add("CLIENT::CHANGE:JAW:HEIGHT", (value) => {
    value_jawHeight = value;
    player.setFaceFeature(14, value_jawHeight);
});

mp.events.add("CLIENT::CHANGE:CHIN:WIDTH", (value) => {
    value_chinWidth = value;
    player.setFaceFeature(17, value_chinWidth);
});

mp.events.add("CLIENT::CHANGE:CHIN:LENGTH", (value) => {
    value_chinLength = value;
    player.setFaceFeature(15, value_chinLength);
});


mp.events.add("CLIENT::CHANGE:NECK:WIDTH", (value) => {
    value_neckWidth = value;
    player.setFaceFeature(19, value_neckWidth);
});

mp.events.add("CLIENT::CHANGE:EYES", (value) => {
    value_eyes = value;
    player.setFaceFeature(11, value_eyes);
});

mp.events.add("CLIENT::CHANGE:EYES:COLOR", (value) => {
    value_eyesColor = value;
    player.setEyeColor(value_eyesColor);
});

mp.events.add("CLIENT::CHANGE:EYEBROWS", (value) => {
    value_eyebrows = parseInt(value);
    player.setHeadOverlay(2, value_eyebrows, 100, 0, 0);
});

mp.events.add("CLIENT::CHANGE:LIPS", (value) => {
    value_lips = value;
    player.setFaceFeature(12, value_lips);
});



// next page
mp.events.add("CLIENT::CHANGE:HAIR", (value) => {
    value_hairStyle = parseInt(value);
    player.setComponentVariation(2, value_hairStyle, 0, 0);
});

mp.events.add("CLIENT::CHANGE:HAIR:COLOR", (value) => {
    value_hairColor = parseInt(value);
    player.setHairColor(value_hairColor, 0);
});

mp.events.add("CLIENT::CHANGE:BEARD", (value) => {
    if(value_gender == true) {
        value_beard = parseInt(value);
        player.setHeadOverlay(1, value_beard, 255, value_beardColor, value_beardColor);
    }
});

mp.events.add("CLIENT::CHANGE:BEARD:COLOR", (value) => {

    if(value_gender == true) {
        value_beardColor = parseInt(value);
        //player.setHeadOverlayColor(1, 255, value_beard, value_beard);
        //player.setHeadOverlay(1, value_beard, 100, value_beardColor, 255);
        //player.setHeadOverlayColor(1, 255, value_beardColor, value_beardColor);
        player.setHeadOverlay(1, value_beard, 255, value_beardColor, value_beardColor);
    }
});

// Clothing events
  

mp.events.add("CLIENT::CHANGE:TOPS", (value) => {
    value_tops = parseInt(value);
    value_topsColor = 0;
    player.setComponentVariation(11, value_tops, value_topsColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});

mp.events.add("CLIENT::CHANGE:TOPS:COLOR", (value) => {
    value_topsColor = parseInt(value);
    player.setComponentVariation(11, value_tops, value_topsColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});

mp.events.add("CLIENT::CHANGE:LEGS", (value) => {
    value_legs = parseInt(value);
    player.setComponentVariation(4, value_legs, value_legsColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});

mp.events.add("CLIENT::CHANGE:LEGS:COLOR", (value) => {
    value_legsColor = parseInt(value);
    player.setComponentVariation(4, value_legs, value_legsColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});

mp.events.add("CLIENT::CHANGE:UNDERSHIRT", (value) => {
    if(parseInt(value) == 0) {
        value_undershirt = 15;
    } else {
        value_undershirt = parseInt(value);
    }
    player.setComponentVariation(8, value_undershirt, value_undershirtColor, 0);
});

mp.events.add("CLIENT::CHANGE:UNDERSHIRT:COLOR", (value) => {
    value_undershirtColor = parseInt(value);
    player.setComponentVariation(8, value_undershirt, value_undershirtColor, 0);
});

mp.events.add("CLIENT::CHANGE:TORSO", (value) => {
    value_torso = parseInt(value);
    player.setComponentVariation(3, value_torso, 0, 0);
});

mp.events.add("CLIENT::CHANGE:SHOES", (value) => {
    value_shoes = parseInt(value);
    player.setComponentVariation(6, value_shoes, value_shoesColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});

mp.events.add("CLIENT::CHANGE:SHOES:COLOR", (value) => {
    value_shoesColor = parseInt(value);
    player.setComponentVariation(6, value_shoes, value_shoesColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});