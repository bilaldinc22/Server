let hud = null;

function ensureHud() {
  if (!hud) hud = mp.browsers.new("package://ui/ui-moneyhud/index.html");
}

function setCash(cash) {
  ensureHud();
  cash = Number(cash) || 0;
  hud.execute(`window.MoneyHUD && MoneyHUD.setCash(${cash});`);
}

mp.events.add("playerReady", () => {
  ensureHud();

  // initial (nach Relog wichtig)
  const v = mp.players.local.getVariable("pocket_money");
  if (v !== undefined && v !== null) setCash(v);
});

// sync auf JEDE Änderung der shared variable
mp.events.addDataHandler("pocket_money", (entity, value) => {
  if (entity !== mp.players.local) return;
  setCash(value);
});
