let injured = false;
const player = mp.players.local;


mp.events.add('CLIENT::INJURED', () => {
    mp.game.gameplay.setFadeOutAfterDeath(false);
    player.freezePosition(true);
    injured = true;
});


mp.events.add('CLIENT::NOT:INJURED', () => {
    player.clearTasksImmediately();
    player.freezePosition(false);
    injured = false;
});

mp.events.add("render", () => {

        if (injured) {
            mp.game.graphics.drawText("INJURED", [0.5, 0.5], {
                font: 2,
                color: [255, 0, 0, 185],
                scale: [1.0, 1.0],
                outline: true
            });
        } 
});