mp.gui.chat.show(false); //Disables default RageMP Chat
const chat = mp.browsers.new('package://ui/ui-chat/index.html');
chat.markAsChat();

//A
require("./authorization");
require("./admin/freeze");
require("./admin/god");
require("./admin/invis");
require("./admin/panel");
require("./admin/spectate");
require("./admin/tpwp");
require("./admin/cefBridge");
//B
require("./ban");
require("./bank");
require("./bank_blips");

//C
require("./character");

//D
require("./playerdeath");
//require("./discord");


//F 
require("./factions");


//H
//require("./locationNames");
require("./house");

// I
require("./inventory");
require("./inventory");
require("./inventory.weaponwheel_remove_patch");

// N
require("./nameTags");
require("./noclip");
require("./notification");
require("./nativeui");

//S
require("./stamina");
require("./keybinds");
require("./syncedComponents");
//V
require("./voiceChat");


require("./AirportRental/rental");
require("./garage");