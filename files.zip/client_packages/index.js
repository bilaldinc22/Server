mp.gui.chat.show(false); //Disables default RageMP Chat
const chat = mp.browsers.new('package://ui/ui-chat/index.html');
chat.markAsChat();

//A
require("./admin/index");
require("./authorization");

//B
require("./ban");
require("./bank");
require("./bank_blips");
require("./bank_clickfix_inject");

//C
require("./character");

//D
require("./playerdeath");
require("./discord");


//F 
require("./factions");


//H
//require("./locationNames");
require("./house");

// I
require("./inventory");
require("./inventory.weaponwheel_remove_patch");

// N
require("./nameTags");
require("./noclip");
require("./notification");
require("./nativeui/index");

//M
require("./moneyhud");


//S
require("./stamina");
require("./keybinds");

//W
require("./weaponshop/index");

//V
require("./voiceChat");


require("./AirportRental/rental");
require("./weaponcomponents/index")