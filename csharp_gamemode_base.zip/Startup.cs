
using GTANetworkAPI;

public class Startup : Script
{
    public Startup()
    {
        NAPI.Util.ConsoleOutput("C# Gamemode gestartet.");
    }
}
