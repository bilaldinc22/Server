
using GTANetworkAPI;

public class ChatCommands : Script
{
    [Command("hilfe")]
    public void HilfeCommand(Player player)
    {
        player.SendChatMessage("Verfügbare Befehle: /hilfe, /tp");
    }

    [Command("tp")]
    public void TeleportCommand(Player player, float x, float y, float z)
    {
        player.Position = new Vector3(x, y, z);
    }
}
