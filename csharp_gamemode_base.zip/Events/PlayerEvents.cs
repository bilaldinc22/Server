
using GTANetworkAPI;

public class PlayerEvents : Script
{
    [ServerEvent(Event.PlayerConnected)]
    public void OnPlayerConnected(Player player)
    {
        player.SendChatMessage("Willkommen auf dem Server!");
    }

    [ServerEvent(Event.PlayerDisconnected)]
    public void OnPlayerDisconnected(Player player, DisconnectionType type, string reason)
    {
        NAPI.Util.ConsoleOutput($"Spieler {player.Name} hat den Server verlassen. Grund: {reason}");
    }
}
