
public class PlayerData
{
    public string SocialClub { get; set; }
    public int AdminLevel { get; set; }
    public int BankGuthaben { get; set; }
}
