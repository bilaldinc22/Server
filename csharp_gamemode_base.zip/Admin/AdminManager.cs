
public class AdminManager
{
    // Hier später Adminrechte prüfen und verwalten
}
