
using MySql.Data.MySqlClient;
using System;

public class Database
{
    private static MySqlConnection connection;

    public static void Connect()
    {
        string connStr = "Server=mysql-mariadb-1-25.zap-srv.com;Database=zap851638-1;Uid=zap851638-1;Pwd=3IDvRbF29SqgMwR8;";
        connection = new MySqlConnection(connStr);
        try
        {
            connection.Open();
            NAPI.Util.ConsoleOutput("[MySQL] Verbindung erfolgreich hergestellt.");
        }
        catch (Exception ex)
        {
            NAPI.Util.ConsoleOutput("[MySQL] Verbindungsfehler: " + ex.Message);
        }
    }

    public static MySqlConnection GetConnection()
    {
        return connection;
    }
}
