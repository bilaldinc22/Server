// client_packages/inventory.js - add force-remove weapon from wheel (client-side)
// NOTE: keep your existing inventory.js, only merge the event below if you already customized other parts.

// Force-remove weapon locally (fixes weapon wheel not updating immediately)
mp.events.add('CLIENT::INVENTORY:FORCE_REMOVE_WEAPON', (weaponHash) => {
    try {
        const hash = parseInt(weaponHash);
        if (!hash) return;

        // remove from ped
        mp.game.weapon.removeWeaponFromPed(mp.players.local.handle, hash);

        // if currently equipped, switch to unarmed
        try {
            if (mp.players.local.weapon === hash) {
                mp.players.local.weapon = mp.game.joaat('WEAPON_UNARMED');
            }
        } catch (e) {}

        // also clear ammo
        try {
            mp.game.weapon.setPedAmmo(mp.players.local.handle, hash, 0);
        } catch (e) {}
    } catch (e) {}
});
