// client_packages/inventory.js - inventory open guard + hotbar + store-weapon-to-inventory
// Must be required from client_packages/index.js: require('./inventory.js');

let inventoryBrowser = null;
let inventoryOpen = false;

const hotbar = { 1: null, 2: null, 3: null, 4: null, 5: null };

function debug(msg) { try { mp.gui.chat.push(`[INV] ${msg}`); } catch (e) {} }

function canOpenInventory() {
    // Block opening while another UI is open (login CEF usually has cursor visible)
    try { if (mp.gui.cursor.visible && !inventoryOpen) return false; } catch (e) {}
    try {
        const v1 = mp.players.local.getVariable('isInLogin');
        const v2 = mp.players.local.getVariable('inLogin');
        const v3 = mp.players.local.getVariable('loginOpen');
        if (v1 === true || v2 === true || v3 === true) return false;
        const loggedIn = mp.players.local.getVariable('loggedIn');
        if (loggedIn === false) return false;
    } catch (e) {}
    return true;
}

function openInventory() {
    if (inventoryOpen) return;
    if (!canOpenInventory()) { debug('Blocked (login/menu active).'); return; }

    inventoryBrowser = mp.browsers.new('package://ui/ui-inventory/index.html');
    inventoryOpen = true;

    mp.gui.cursor.visible = true;
    mp.game.ui.displayRadar(false);

    mp.events.callRemote('SERVER::INVENTORY:REQUEST');
}

function closeInventory() {
    if (!inventoryOpen) return;

    if (inventoryBrowser) {
        inventoryBrowser.destroy();
        inventoryBrowser = null;
    }

    inventoryOpen = false;
    mp.gui.cursor.visible = false;
    mp.game.ui.displayRadar(true);
}

mp.keys.bind(0x49, true, () => { // I
    if (!inventoryOpen) openInventory();
    else closeInventory();
});

// -------- Hotbar --------
function useHotbar(slot) {
    if (inventoryOpen) return;
    if (!canOpenInventory()) return;
    const itemId = hotbar[slot];
    if (!itemId) return;
    mp.events.callRemote('SERVER::INVENTORY:USE', parseInt(itemId));
}
mp.keys.bind(0x31, true, () => useHotbar(1));
mp.keys.bind(0x32, true, () => useHotbar(2));
mp.keys.bind(0x33, true, () => useHotbar(3));
mp.keys.bind(0x34, true, () => useHotbar(4));
mp.keys.bind(0x35, true, () => useHotbar(5));

// -------- Store weapon from weapon wheel into inventory (K) --------
// Map weapon hashes to your ItemTemplate.name in DB
// Add more entries if you have more weapon templates.
const WEAPON_HASH_TO_TEMPLATE = {
    [mp.game.joaat('WEAPON_PISTOL')]: 'weapon_pistol',
    [mp.game.joaat('WEAPON_COMBATPISTOL')]: 'weapon_combatpistol',
    [mp.game.joaat('WEAPON_PISTOL50')]: 'weapon_pistol50',
    [mp.game.joaat('WEAPON_SNSPISTOL')]: 'weapon_snspistol',
    [mp.game.joaat('WEAPON_APPISTOL')]: 'weapon_appistol',

    [mp.game.joaat('WEAPON_SMG')]: 'weapon_smg',
    [mp.game.joaat('WEAPON_MICROSMG')]: 'weapon_microsmg',
    [mp.game.joaat('WEAPON_ASSAULTSMG')]: 'weapon_assaultsmg',

    [mp.game.joaat('WEAPON_CARBINERIFLE')]: 'weapon_carbinerifle',
    [mp.game.joaat('WEAPON_ASSAULTRIFLE')]: 'weapon_assaultrifle',
    [mp.game.joaat('WEAPON_SPECIALCARBINE')]: 'weapon_specialcarbine',

    [mp.game.joaat('WEAPON_PUMPSHOTGUN')]: 'weapon_pumpshotgun',
};

function getCurrentWeaponAmmo(hash) {
    try { return mp.players.local.getAmmoInClip(hash); } catch (e) {}
    try { return mp.game.weapon.getAmmoInPedWeapon(mp.players.local.handle, hash); } catch (e) {}
    return 0;
}

function storeCurrentWeaponToInventory() {
    if (!canOpenInventory()) return;
    const hash = mp.players.local.weapon;
    if (!hash || hash === 0) { debug('Keine Waffe in der Hand.'); return; }

    const tpl = WEAPON_HASH_TO_TEMPLATE[hash];
    if (!tpl) { debug('Diese Waffe ist nicht als Template gemappt.'); return; }

    const ammo = getCurrentWeaponAmmo(hash);
    mp.events.callRemote('SERVER::INVENTORY:STORE_WEAPON', tpl, parseInt(hash), parseInt(ammo));
}

mp.keys.bind(0x4B, true, () => { // K
    // allow even if inventory open (weapon wheel usually closed)
    storeCurrentWeaponToInventory();
});

// -------- UI -> server --------
mp.events.add('CLIENT::INVENTORY:USE', (itemId) => mp.events.callRemote('SERVER::INVENTORY:USE', parseInt(itemId)));
mp.events.add('CLIENT::INVENTORY:UNEQUIP_TO_SLOT', (itemId, newSlot) => mp.events.callRemote('SERVER::INVENTORY:UNEQUIP_TO_SLOT', parseInt(itemId), parseInt(newSlot)));
mp.events.add('CLIENT::INVENTORY:MOVE', (itemId, newSlot) => mp.events.callRemote('SERVER::INVENTORY:MOVE', parseInt(itemId), parseInt(newSlot)));
mp.events.add('CLIENT::INVENTORY:DROP', (itemId, amount) => mp.events.callRemote('SERVER::INVENTORY:DROP', parseInt(itemId), parseInt(amount)));
mp.events.add('CLIENT::INVENTORY:SPLIT', (itemId, amount) => mp.events.callRemote('SERVER::INVENTORY:SPLIT', parseInt(itemId), parseInt(amount)));
mp.events.add('CLIENT::INVENTORY:GIVE', (targetStr, itemId, amount) => mp.events.callRemote('SERVER::INVENTORY:GIVE', targetStr || '', parseInt(itemId), parseInt(amount)));
mp.events.add('CLIENT::INVENTORY:GIVE_CASH', (amount) => {
  amount = Math.floor(Number(amount) || 0);
  if (amount <= 0) return;
  mp.events.callRemote('SERVER::INVENTORY:GIVE_CASH', amount);
});

mp.events.add('CLIENT::INVENTORY:REFRESH_DROPS', () => mp.events.callRemote('SERVER::INVENTORY:NEAR_DROPS'));
mp.events.add('CLIENT::INVENTORY:PICKUP', (worldItemId) => mp.events.callRemote('SERVER::INVENTORY:PICKUP', parseInt(worldItemId)));

mp.events.add('CLIENT::INVENTORY:HOTBAR_SET', (slot, itemId) => {
    const s = parseInt(slot);
    if (s < 1 || s > 5) return;
    const id = parseInt(itemId);
    hotbar[s] = (id && !Number.isNaN(id)) ? id : null;
    try { mp.storage.data.inventoryHotbar = hotbar; mp.storage.flush(); } catch (e) {}
});

try {
    const saved = mp.storage.data.inventoryHotbar;
    if (saved) for (let i = 1; i <= 5; i++) hotbar[i] = saved[i] || null;
} catch (e) {}

mp.events.add('CLIENT::INVENTORY:SET_DATA', (json, maxSlots) => {
    if (!inventoryBrowser) return;
    inventoryBrowser.execute(`window.setInventoryData(${JSON.stringify(json)}, ${parseInt(maxSlots)});`);
});

mp.events.add('CLIENT::INVENTORY:CLOSE', () => closeInventory());
