


mp.events.add('DISCORD::SHOW:PLAYER', (playername) => {
    if(playername) {
        mp.discord.update('Playing Social RP', `${playername.replace("_", " ")}`)
    }
});

