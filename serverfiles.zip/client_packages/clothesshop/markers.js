
const shops = {

    civilian: new mp.Vector3(72.3, -1399.1, 29.4)
};

for (let k in shops) {
    const pos = shops[k];
    const col = mp.colshapes.newSphere(pos.x, pos.y, pos.z, 1.5);
    col.shop = k;
}

mp.events.add('playerEnterColshape', (shape) => {
    if (shape.shop) {
        openShop(shape.shop);
    }
});
