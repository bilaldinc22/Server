const NativeUI = require("nativeui");
const { Menu, UIMenuItem, Point } = NativeUI;

/**
 * Clothes shop v10 - client (NativeUI, maximum compatibility)
 * Goal: "Color selection like screenshot" BUT without UIMenuListItem (often missing/broken).
 *
 * Texture menu layout:
 * 0) ← Zurück
 * 1) Farbe: <n>   (use LEFT/RIGHT to change; live preview)
 * 2) Kaufen
 *
 * Navigation:
 * - Main & List menus handled manually via Enter (accept) using current selection index (avoids ItemSelect bugs)
 * - List menu enter on drawable opens texture menu
 * - Buy works on Enter when "Kaufen" highlighted OR hotkey K
 *
 * Robustness:
 * - resolveVisibleMenu() prevents activeMenu null crashes
 */

const SHOP_POS = new mp.Vector3(72.0, -1399.0, 29.4);
const OPEN_KEY = 0x45; // E
const BUY_KEY  = 0x4B; // K
const OPEN_RANGE = 2.0;

mp.blips.new(73, SHOP_POS, { name: "Klamottenladen", color: 2, scale: 0.85, shortRange: true });
mp.markers.new(1, SHOP_POS, 1.0, { color: [0, 150, 255, 150], visible: true });

function getMenuPointRight() {
  try {
    const res = mp.game.graphics.getScreenActiveResolution(0, 0);
    const w = Array.isArray(res) ? res[0] : (res && res.x ? res.x : 0);
    if (!w) return new Point(1100, 50);
    return new Point(Math.max(50, Math.floor(w - 420)), 50);
  } catch (_) { return new Point(1100, 50); }
}
const P = getMenuPointRight();

const categories = [
  { key: "pants", label: "Hosen", kind: "component", id: 4 },
  { key: "shoes", label: "Schuhe", kind: "component", id: 6 },
  { key: "top", label: "Oberteil", kind: "component", id: 11 },
  { key: "undershirt", label: "Unterhemd", kind: "component", id: 8 },
  { key: "torso", label: "Torso", kind: "component", id: 3 },
  { key: "accessory", label: "Schmuck/Accessoires", kind: "component", id: 7 },
  { key: "mask", label: "Masken", kind: "component", id: 1 },

  { key: "glasses", label: "Brillen", kind: "prop", id: 1 },
  { key: "hat", label: "Hüte", kind: "prop", id: 0 },
  { key: "ears", label: "Ohrringe", kind: "prop", id: 2 },
  { key: "watch", label: "Uhren", kind: "prop", id: 6 },
  { key: "bracelet", label: "Armbänder", kind: "prop", id: 7 }
];

const mainMenu = new Menu("Klamottenladen", "Kategorien", P);
const listMenu = new Menu("Auswahl", "Drawables (Preview beim Scrollen)", P);
const texMenu  = new Menu("Farbe", "Links/Rechts ändern", P);

mainMenu.Visible = listMenu.Visible = texMenu.Visible = false;

let activeMenu = null;
let lastToggleTick = 0;

// paging
const PAGE_SIZE = 20;
let currentCategory = null;
let currentDrawable = 0;
let currentTexture = 0;
let currentPage = 0;
let textureCount = 1;

// texture menu items
let texBackItem = null;
let texColorItem = null;
let texBuyItem = null;

let lastBuyTick = 0;
function canBuyNow(){
  const t = Date.now();
  if (t - lastBuyTick < 500) return false;
  lastBuyTick = t;
  return true;
}

function now(){ return Date.now(); }
function inRange(){
  const p=mp.players.local.position;
  const dx=p.x-SHOP_POS.x, dy=p.y-SHOP_POS.y, dz=p.z-SHOP_POS.z;
  return (dx*dx+dy*dy+dz*dz) <= (OPEN_RANGE*OPEN_RANGE);
}

function resolveVisibleMenu() {
  if (activeMenu && activeMenu.Visible) return activeMenu;
  if (texMenu.Visible) return texMenu;
  if (listMenu.Visible) return listMenu;
  if (mainMenu.Visible) return mainMenu;
  return null;
}
function anyVisible(){ return !!resolveVisibleMenu(); }

function openMenu(m){
  mainMenu.Visible = false;
  listMenu.Visible = false;
  texMenu.Visible  = false;
  activeMenu = m;
  if (m) m.Visible = true;

  mp.gui.cursor.visible = false;
  if (m && typeof m.RefreshIndex === "function") m.RefreshIndex();
  if (m && typeof m.ResetIndex === "function") m.ResetIndex();
}

function closeAll(){
  mainMenu.Visible = false;
  listMenu.Visible = false;
  texMenu.Visible  = false;
  activeMenu = null;
  mp.gui.cursor.visible = false;
}

function accept(){ return mp.game.controls.isControlJustPressed(0,176) || mp.game.controls.isControlJustPressed(0,201); }
function back(){ return mp.game.controls.isControlJustPressed(0,177) || mp.game.controls.isControlJustPressed(0,202); }
function left(){ return mp.game.controls.isControlJustPressed(0,174); }
function right(){ return mp.game.controls.isControlJustPressed(0,175); }

function getMenuIndex(menu){
  if (!menu) return 0;
  const keys=["CurrentSelection","currentSelection","SelectedIndex","selectedIndex","_Index","_index","Index","index"];
  for (let i=0;i<keys.length;i++){ const k=keys[i]; if (typeof menu[k]==="number") return menu[k]; }
  return 0;
}

function disableGameplayControls(){
  const toDisable=[24,25,68,69,70,91,92,140,141,142,14,15,16,17,37,44,45];
  for (let i=0;i<toDisable.length;i++) mp.game.controls.disableControlAction(0,toDisable[i],true);
  const allow=[172,173,174,175,176,177,188,187,189,190,201,202,199,200];
  for (let i=0;i<allow.length;i++) mp.game.controls.enableControlAction(0,allow[i],true);
}

function clearMenu(m){
  if (m && typeof m.Clear === "function") { m.Clear(); return; }
  if (m && typeof m.RemoveItemAt === "function" && m.MenuItems) {
    for (let i = m.MenuItems.length - 1; i >= 0; i--) m.RemoveItemAt(i);
    return;
  }
  if (m && m.MenuItems) m.MenuItems.length = 0;
}

function setItemText(item, text){
  if (!item) return;
  try {
    if ("Text" in item) item.Text = text;
    else if ("text" in item) item.text = text;
  } catch (_) {}
}

function buildMainMenu(){
  clearMenu(mainMenu);
  for (const c of categories) mainMenu.AddItem(new UIMenuItem(c.label, "Öffnen"));
}

function getDrawableCount(cat){
  const ped = mp.players.local.handle;
  if (cat.kind === "component") return mp.game.invoke("0x27561561732A7842", ped, cat.id) | 0;
  return mp.game.invoke("0x5FAF9754E789FB47", ped, cat.id) | 0;
}

function getTextureCount(cat, drawable){
  const ped = mp.players.local.handle;
  if (cat.kind === "component") return mp.game.invoke("0x8F7156A3142A6BAD", ped, cat.id, drawable) | 0;
  return mp.game.invoke("0xA6E7F1CEB523E171", ped, cat.id, drawable) | 0;
}

function preview(cat, drawable, texture){
  const ped = mp.players.local;
  try {
    if (cat.kind === "component") ped.setComponentVariation(cat.id, drawable, texture, 0);
    else {
      if (drawable < 0) ped.clearProp(cat.id);
      else ped.setPropIndex(cat.id, drawable, texture, true);
    }
  } catch (_) {}
}

function buildDrawableList(cat, page){
  currentCategory = cat;
  currentPage = page;
  currentTexture = 0;

  clearMenu(listMenu);
  listMenu.AddItem(new UIMenuItem("← Zurück", "Kategorien"));

  const total = getDrawableCount(cat);
  const start = page * PAGE_SIZE;
  const end = Math.min(total, start + PAGE_SIZE);

  if (page > 0) listMenu.AddItem(new UIMenuItem("◀ Vorherige Seite", ""));
  if (end < total) listMenu.AddItem(new UIMenuItem("Nächste Seite ▶", ""));

  for (let d = start; d < end; d++) listMenu.AddItem(new UIMenuItem("#"+d, "Enter = Farbe wählen"));

  currentDrawable = start;
  preview(cat, currentDrawable, 0);
}

function buildTextureMenu(cat, drawable){
  currentDrawable = drawable;
  currentTexture = 0;

  textureCount = Math.max(1, Math.min(getTextureCount(cat, drawable), 200));

  clearMenu(texMenu);
  texMenu.Subtitle = "Farbe/Textur auswählen";

  texBackItem = new UIMenuItem("← Zurück", "Drawables");
  texColorItem = new UIMenuItem("Farbe: "+currentTexture+"  < >", "Links/Rechts ändern");
  texBuyItem = new UIMenuItem("Kaufen", "Kauft die aktuell ausgewählte Farbe");

  texMenu.AddItem(texBackItem);
  texMenu.AddItem(texColorItem);
  texMenu.AddItem(texBuyItem);

  preview(cat, drawable, 0);
}

function updateColorItem(){
  setItemText(texColorItem, "Farbe: "+currentTexture+"  < >");
}

function buyCurrentSelection(){
  if (!currentCategory) return;
  if (!canBuyNow()) return;
  mp.events.callRemote("clothesshop:buyPiece", String(currentCategory.key), Number(currentDrawable), Number(currentTexture));
}

// Live preview vars
let lastMainSel=-1, lastListSel=-1, lastTexSel=-1;

mp.events.add("render", ()=>{
  const m = resolveVisibleMenu();
  if (!m) return;
  activeMenu = m;

  disableGameplayControls();

  if (back()) {
    if (m === texMenu) openMenu(listMenu);
    else if (m === listMenu) openMenu(mainMenu);
    else closeAll();
    return;
  }

  // MAIN: manual enter choose category
  if (m === mainMenu) {
    const sel = getMenuIndex(mainMenu);
    if (sel !== lastMainSel) lastMainSel = sel;

    if (accept()) {
      const cat = categories[sel];
      if (cat) {
        buildDrawableList(cat, 0);
        openMenu(listMenu);
        return;
      }
    }
  }

  // LIST: preview on scroll + enter to open texture menu
  if (m === listMenu && currentCategory) {
    const sel = getMenuIndex(listMenu);
    if (sel !== lastListSel) {
      lastListSel = sel;
      if (sel > 0) {
        const hasPrev = currentPage > 0;
        const total = getDrawableCount(currentCategory);
        const start = currentPage * PAGE_SIZE;
        const end = Math.min(total, start + PAGE_SIZE);
        let cursor = 1;
        if (hasPrev) cursor++;
        if (end < total) cursor++;
        const drawableIndex = start + (sel - cursor);
        if (drawableIndex >= start && drawableIndex < end) {
          currentDrawable = drawableIndex;
          currentTexture = 0;
          preview(currentCategory, currentDrawable, 0);
        }
      }
    }

    if (accept()) {
      if (sel === 0) { openMenu(mainMenu); return; }

      const hasPrev = currentPage > 0;
      const total = getDrawableCount(currentCategory);
      const start = currentPage * PAGE_SIZE;
      const end = Math.min(total, start + PAGE_SIZE);
      let cursor = 1;
      if (hasPrev) {
        if (sel === cursor) { buildDrawableList(currentCategory, currentPage-1); openMenu(listMenu); return; }
        cursor++;
      }
      if (end < total) {
        if (sel === cursor) { buildDrawableList(currentCategory, currentPage+1); openMenu(listMenu); return; }
        cursor++;
      }

      const drawableIndex = start + (sel - cursor);
      if (drawableIndex >= start && drawableIndex < end) {
        buildTextureMenu(currentCategory, drawableIndex);
        openMenu(texMenu);
        return;
      }
    }
  }

  // TEX: left/right changes color on the "Farbe" row, enter buys on "Kaufen"
  if (m === texMenu && currentCategory) {
    const sel = getMenuIndex(texMenu);
    if (sel !== lastTexSel) lastTexSel = sel;

    if (sel === 0 && accept()) { openMenu(listMenu); return; }

    if (sel === 1) {
      if (left()) {
        currentTexture = (currentTexture - 1 + textureCount) % textureCount;
        updateColorItem();
        preview(currentCategory, currentDrawable, currentTexture);
      } else if (right()) {
        currentTexture = (currentTexture + 1) % textureCount;
        updateColorItem();
        preview(currentCategory, currentDrawable, currentTexture);
      }
    }

    if (sel === 2 && accept()) {
      buyCurrentSelection();
      return;
    }
  }

  if (m && typeof m.ProcessControl === "function") m.ProcessControl();
  if (m && typeof m.Draw === "function") m.Draw();
});

// Backup hotkey K to buy (only in texture menu)
mp.keys.bind(BUY_KEY, true, ()=>{
  const m = resolveVisibleMenu();
  if (m !== texMenu) return;
  buyCurrentSelection();
});

mp.keys.bind(OPEN_KEY, true, ()=>{
  const t=now(); if (t-lastToggleTick<250) return; lastToggleTick=t;
  if (!inRange()) return;
  if (!anyVisible()) { buildMainMenu(); openMenu(mainMenu); }
  else closeAll();
});
