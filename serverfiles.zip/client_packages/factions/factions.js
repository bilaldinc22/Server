

let active = false;
let factionMenu;

let editing = false;
let factionSelected = null;

mp.keys.bind(0x75, true, async function() {   // F5 for faction Menu
    if(active == false) {

        let fetchdata = await mp.events.callRemoteProc("SERVER::FETCH:FACTION:DATA");
        if(!fetchdata.length) return mp.gui.chat.push(`There are no factions currently`);
        factionMenu = mp.browsers.new("package://ui/ui-factions/index.html");

        factionMenu.execute(`loadFactionUI()`);

        fetchdata.forEach((faction) => {
            factionMenu.execute(`loadFactions('${JSON.stringify(faction)}')`);
        });

        active = true;

    }
});


mp.events.add("CLIENT::CLOSE:FACTION:MENU", () => {
    if(active == true) {
        factionMenu.destroy();
        active = false;
        editing = false;
    }
});


mp.events.add("CLIENT::EDIT:FACTION", (factionData) => {
    if(active == false && editing == false) {
        factionMenu = mp.browsers.new("package://ui/ui-factions/index.html");
        factionMenu.execute(`editFaction('${JSON.stringify(factionData)}')`);
        factionSelected = factionData.id;
        active = true;
        editing = true;
    }
});


mp.events.add("CLIENT::SAVE:FACTION:DATA", (data) => {
    if(active == true && editing == true) {
        mp.events.callRemote("SERVER::SAVE:FACTION:DATA", data, factionSelected);
        mp.events.call("CLIENT::CLOSE:FACTION:MENU");
        active = false;
        editing = false;
        factionSelected = null;
    }

});