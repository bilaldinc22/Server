/**
 * Client: apply saved barber data from server variable / persistence
 * Events:
 * - barbershop:applySelf(barberObj)
 *
 * barberObj schema (backwards compatible):
 * { hairType?: "gta"|"custom", hair?: number, hairColor?: number, hairHighlight?: number, custom?: {model,collection} }
 */
let appliedObj = null;

function destroyAppliedObj(){
  if (appliedObj){
    try { appliedObj.destroy(); } catch (_) {}
    appliedObj = null;
  }
}

function applyBarber(barber){
  const p = mp.players.local;
  if (!barber || typeof barber !== "object") return;

  const hairType = String(barber.hairType || "gta");
  const hair = Number(barber.hair ?? 0);
  const hairColor = Number(barber.hairColor ?? 0);
  const hairHighlight = Number(barber.hairHighlight ?? hairColor);

  // always set color (works for GTA component hair)
  try { p.setHairColor(hairColor, hairHighlight); } catch (_) {}

  if (hairType === "custom" && barber.custom && barber.custom.model){
    destroyAppliedObj();
    const model = String(barber.custom.model);
    const m = mp.game.joaat(model);
    mp.game.streaming.requestModel(m);
    appliedObj = mp.objects.new(m, p.position, { dimension: p.dimension });
    appliedObj.attachTo(p.handle, 31086, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 0, true);

    // keep current component hair as-is (optional)
    return;
  }

  // default: gta component hair
  destroyAppliedObj();
  try { p.setComponentVariation(2, hair, 0, 2); } catch (_) {}
}

mp.events.add("barbershop:applySelf", (barber) => {
  try { applyBarber(barber); } catch (_) {}
});

// Optional: apply when barber var changes
mp.events.addDataHandler("barber", (entity, value) => {
  if (entity && entity.handle === mp.players.local.handle){
    try { applyBarber(value); } catch (_) {}
  }
});


// --- Reapply hooks --------------------------------------------------------------
// Some resources (e.g. character creator / presets) overwrite hair AFTER barber was applied.
// The "barber" synced variable doesn't change then, so add explicit re-apply on key lifecycle events.

function reapplyBarberFromSynced(delayMs) {
  try {
    const v = mp.players.local.getVariable("barber");
    if (!v) return;
    setTimeout(() => { try { applyBarber(v); } catch (_) {} }, delayMs || 0);
  } catch (_) {}
}

// Your gamemode uses this event after leaving login and spawning
mp.events.add("CLIENT::SPAWN:PLAYER", () => {
  // apply a couple times to win against late preset/clothes apply
  reapplyBarberFromSynced(0);
  reapplyBarberFromSynced(500);
  reapplyBarberFromSynced(2000);
});

// Character preset apply event used by character creator
mp.events.add("CLIENT::APPLY:CHARACTER:PRESET", () => {
  reapplyBarberFromSynced(0);
  reapplyBarberFromSynced(500);
});

// Generic RageMP spawn event (some servers emit it clientside)
mp.events.add("playerSpawn", () => {
  reapplyBarberFromSynced(0);
  reapplyBarberFromSynced(500);
});
