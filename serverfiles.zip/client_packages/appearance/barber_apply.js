/**
 * Client: apply saved barber data from server variable / persistence
 * Events:
 * - barbershop:applySelf(barberObj)
 *
 * barberObj schema (backwards compatible):
 * { hairType?: "gta"|"custom", type?: "gta"|"custom", hair?: number, hairColor?: number, hairHighlight?: number, custom?: {model,collection} }
 */

let appliedObj = null;

function destroyAppliedObj() {
  if (appliedObj) {
    try { appliedObj.destroy(); } catch (_) {}
    appliedObj = null;
  }
}

function applyBarberToEntity(entity, barber) {
  if (!entity || !entity.handle) return;
  if (!barber || typeof barber !== "object") return;

  const hairType = String(barber.hairType || barber.type || "gta");
  const hair = Number(barber.hair ?? 0);
  const hairColor = Number(barber.hairColor ?? 0);
  const hairHighlight = Number(barber.hairHighlight ?? hairColor);

  // always set color (works for GTA component hair)
  try { entity.setHairColor(hairColor, hairHighlight); } catch (_) {}

  // Custom hair objects are only supported for local player in this resource
  if (hairType === "custom" && entity.handle === mp.players.local.handle) {
    if (barber.custom && barber.custom.model) {
      destroyAppliedObj();

      const model = String(barber.custom.model);
      const m = mp.game.joaat(model);

      try { mp.game.streaming.requestModel(m); } catch (_) {}
      appliedObj = mp.objects.new(m, entity.position, { dimension: entity.dimension });

      try {
        appliedObj.attachTo(entity.handle, 31086, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 0, true);
      } catch (_) {}

      return;
    }
  }

  // default: gta component hair
  if (entity.handle === mp.players.local.handle) destroyAppliedObj();
  try { entity.setComponentVariation(2, hair, 0, 2); } catch (_) {}
}

mp.events.add("barbershop:applySelf", (barber) => {
  try { applyBarberToEntity(mp.players.local, barber); } catch (_) {}
});

// Apply when barber var changes (local + others)
mp.events.addDataHandler("barber", (entity, value) => {
  if (!entity || entity.type !== "player") return;
  try { applyBarberToEntity(entity, value); } catch (_) {}
});

// Apply for newly streamed-in players
mp.events.add("entityStreamIn", (entity) => {
  if (!entity || entity.type !== "player") return;
  try {
    const value = entity.getVariable("barber");
    if (value) applyBarberToEntity(entity, value);
  } catch (_) {}
});
