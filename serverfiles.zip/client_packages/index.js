mp.gui.chat.show(false); //Disables default RageMP Chat
const chat = mp.browsers.new('package://ui/ui-chat/index.html');
chat.markAsChat();
require("./nativeui/index");


//A
require("./admin/index");
require("./character/authorization");
require("./AirportRental/rental");
require("./appearance/barber_apply");

//B
require("./ban/ban");
require("./bank/bank");
require("./bank/bank_blips");
require("./bank/bank_clickfix_inject");

//C
require("./character/character");
require("./clothesshop/index");

//D
require("./discord/discord");


//F 
require("./factions/factions");


//H
//require("./locationNames");
require("./house/house");
require('./hairshop/camera.js');
require('./hairshop/preview.js');
require('./hairshop/hairstyles.js');
require('./hairshop/index.js');
require("./hairshop/controls_fix.js");
require("./hud/hud");

// I
require("./inventory/inventory");
require("./inventory/inventory.weaponwheel_remove_patch");

//K
require("./keybinds/keybinds");

// N
require("./nametags/nameTags");
require("./noclip/noclip");
require("./notification/notification");


//M
require("./hud/moneyhud");


//P
require("./playerdeath/playerdeath");


//S
require("./stamina/stamina");

//W
require("./weaponshop/index");



//V
require("./voicechat/voiceChat");



