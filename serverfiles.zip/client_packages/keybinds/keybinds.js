// =================== Cursor Script (NativeUI-safe)

let cursorVisible = false;

mp.keys.bind(0x71, true, () => { // F2
    cursorVisible = !cursorVisible;
    mp.gui.cursor.visible = cursorVisible;
});

// WICHTIG: KEINE Frontend-Controls blockieren!
mp.events.add("render", () => {
    if (cursorVisible) {
        // Nur Maus- & Kamera-Controls blockieren
        mp.game.controls.disableControlAction(0, 1, true);   // LookLeftRight
        mp.game.controls.disableControlAction(0, 2, true);   // LookUpDown
        mp.game.controls.disableControlAction(0, 24, true);  // Attack
        mp.game.controls.disableControlAction(0, 25, true);  // Aim
    }
});

// =================== HUD Toggle (F7 bleibt gleich)

let hidden = false;

mp.keys.bind(0x76, true, () => { // F7
    hidden = !hidden;
    mp.gui.chat.show(!hidden);
    mp.gui.chat.activate(!hidden);
    mp.game.ui.displayRadar(!hidden);
});