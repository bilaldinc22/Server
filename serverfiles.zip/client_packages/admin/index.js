// Admin client module (single-file)
// Features:
// - Action registry for panel actions (client-side routing)
// - Centralized state for toggles (invis/spectate/panel)
// - Input lock while panel open
// - Defensive cleanup on resource stop / disconnect / stream-out

const PANEL_URL = "package://admin/cef/index.html";

// ---- State ----
const state = {
  panel: null,
  panelOpen: false,

  invis: false,
  spectating: false,
  spectateTargetRemoteId: null,
  lastPos: null,
};

function bool(v) { return !!v; }

// ---- Panel helpers ----
function panelExec(fnName, arg) {
  if (!state.panel) return;
  try {
    if (typeof arg === "undefined") state.panel.execute(`window.${fnName}();`);
    else state.panel.execute(`window.${fnName}(${JSON.stringify(arg)});`);
  } catch (e) {}
}

function openPanel(payload) {
  if (state.panel) {
    try { state.panel.destroy(); } catch (e) {}
    state.panel = null;
  }
  state.panel = mp.browsers.new(PANEL_URL);
  state.panelOpen = true;

  panelExec("adminPanelInitData", payload);

  mp.gui.cursor.show(true, true);
}

function closePanel() {
  if (!state.panelOpen) return;
  state.panelOpen = false;

  if (state.panel) {
    try { state.panel.destroy(); } catch (e) {}
    state.panel = null;
  }

  mp.gui.cursor.show(false, false);
  mp.events.callRemote("admin:panel:closed");
}

// ---- Control lock while UI open ----
mp.events.add("render", () => {
  if (!state.panelOpen) return;
  // Block game controls while using the admin UI
  mp.game.controls.disableAllControlActions(0);
  mp.game.controls.disableAllControlActions(1);
  mp.game.controls.disableAllControlActions(2);
});

// ---- Action registry (CEF -> Client routing) ----
const actions = Object.create(null);

function registerAction(name, handler) {
  actions[name] = handler;
}

// Default: forward to server
function forwardToServer(action, jsonStr) {
  mp.events.callRemote("admin:panel:action", action, jsonStr);
}

// ---- Client-handled actions ----
registerAction("close", () => closePanel());

registerAction("tpwp", () => {
  // Client determines waypoint coords, then sends to server
  const blip = mp.game.ui.getFirstBlipInfoId(8); // 8 = Waypoint
  if (!mp.game.ui.doesBlipExist(blip)) return;

  const c = mp.game.ui.getBlipInfoIdCoord(blip);

  // Find ground Z (best-effort)
  let z = 0.0;
  for (let i = 0; i < 400; i++) {
    const testZ = i * 5.0;
    const ok = mp.game.gameplay.getGroundZFor3dCoord(c.x, c.y, testZ, 0, false);
    if (ok) { z = testZ; break; }
  }

  mp.events.callRemote("admin:tpwp:coords", c.x, c.y, z);
});

// ---- Panel lifecycle ----
mp.events.add("admin:panel:open", (payload) => {
  openPanel(payload);
  mp.events.callRemote("admin:panel:opened");
});

mp.events.add("admin:panel:data", (payload) => panelExec("adminPanelInitData", payload));
mp.events.add("admin:panel:players", (playersJson) => panelExec("adminPanelPlayersUpdate", playersJson));

// Bridge from CEF
mp.events.add("admin:panel:action", (action, jsonStr) => {
  try {
    const fn = actions[action];
    if (fn) fn(jsonStr);
    else forwardToServer(action, jsonStr);
  } catch (e) {
    // If a handler fails, still forward so the server can decide
    forwardToServer(action, jsonStr);
  }
});

// Keybinds
mp.keys.bind(0x74, true, () => { // F5
  if (state.panelOpen) closePanel();
  else mp.events.callRemote("admin:panel:open");
});

mp.keys.bind(0x1B, true, () => { // ESC
  if (state.panelOpen) closePanel();
});

// ---- Server -> Client admin effects ----
mp.events.add("admin:freeze", (v) => {
  mp.players.local.freezePosition(bool(v));
});

mp.events.add("admin:god", (v) => {
  mp.players.local.setInvincible(bool(v));
});

mp.events.add("admin:invis", () => {
  state.invis = !state.invis;
  mp.players.local.setVisible(!state.invis, false);
});

mp.events.add("admin:spectate:start", (remoteId) => {
  const t = mp.players.atRemoteId(remoteId);
  if (!t) return;

  if (!state.spectating) state.lastPos = mp.players.local.position;

  state.spectating = true;
  state.spectateTargetRemoteId = remoteId;

  mp.players.local.attachTo(
    t.handle,
    0,
    0,
    0,
    5,
    0,
    0,
    0,
    false,
    false,
    false,
    false,
    2,
    true
  );
});

function stopSpectateLocal() {
  if (!state.spectating) return;

  state.spectating = false;
  state.spectateTargetRemoteId = null;

  try { mp.players.local.detach(true, true); } catch (e) {}

  if (state.lastPos) mp.players.local.position = state.lastPos;
  state.lastPos = null;
}

mp.events.add("admin:spectate:stop", () => stopSpectateLocal());

// Legacy support: server can request waypoint TP via this event
mp.events.add("admin:tpwp:req", () => actions.tpwp());

// ---- Defensive cleanup ----
function resetClientToggles() {
  // These should be safe even if the server also manages them.
  try { mp.players.local.freezePosition(false); } catch (e) {}
  try { mp.players.local.setInvincible(false); } catch (e) {}
  try { mp.players.local.setVisible(true, false); } catch (e) {}
  state.invis = false;

  stopSpectateLocal();
}

mp.events.add("entityStreamOut", (entity) => {
  if (!state.spectating || !entity || entity.type !== "player") return;
  // If the spectate target streams out, stop locally and notify server
  if (typeof entity.remoteId !== "undefined" && entity.remoteId === state.spectateTargetRemoteId) {
    stopSpectateLocal();
    mp.events.callRemote("admin:spectate:stopped", state.spectateTargetRemoteId);
  }
});

mp.events.add("playerQuit", () => {
  if (state.panelOpen) closePanel();
  resetClientToggles();
});

// Fires when this resource stops (e.g., reload). Ensure no stuck UI/cursor/toggles.
mp.events.add("resourceStop", (resName) => {
  try {
    if (resName && mp.resources && mp.resources.getCurrentName && resName !== mp.resources.getCurrentName()) return;
  } catch (e) {}
  if (state.panelOpen) closePanel();
  resetClientToggles();
});
