(function(){
  const STORAGE_KEY = "ui_lang";
  const DEFAULT_LANG = "de";
  function getLang(){
    const v = (localStorage.getItem(STORAGE_KEY)||"").toLowerCase();
    return (v === "en" || v === "de") ? v : DEFAULT_LANG;
  }
  async function loadLocale(lang){
    const res = await fetch(`locales/${lang}.json`, { cache: "no-store" });
    if(!res.ok) throw new Error("locale load failed");
    return await res.json();
  }
  function apply(dict){
    document.querySelectorAll("[data-i18n]").forEach(el=>{
      const k=el.getAttribute("data-i18n");
      if(dict[k]!=null) el.textContent = dict[k];
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach(el=>{
      const k=el.getAttribute("data-i18n-placeholder");
      if(dict[k]!=null) el.setAttribute("placeholder", dict[k]);
    });
    document.querySelectorAll("[data-i18n-title]").forEach(el=>{
      const k=el.getAttribute("data-i18n-title");
      if(dict[k]!=null) el.setAttribute("title", dict[k]);
    });
    document.querySelectorAll("[data-i18n-value]").forEach(el=>{
      const k=el.getAttribute("data-i18n-value");
      if(dict[k]!=null) el.setAttribute("value", dict[k]);
    });
    document.documentElement.setAttribute("lang", (localStorage.getItem(STORAGE_KEY)||DEFAULT_LANG));
  }
  async function setLang(lang){
    localStorage.setItem(STORAGE_KEY, lang);
    const dict = await loadLocale(lang);
    apply(dict);
    // update toggle state if present
    const btn = document.getElementById("uiLangBtn");
    if(btn) btn.textContent = (lang === "de") ? "DE" : "EN";
  }
  function ensureToggle(){
    if(document.getElementById("uiLangToggle")) return;
    const wrap = document.createElement("div");
    wrap.id = "uiLangToggle";
    wrap.style.cssText = "position:fixed;top:12px;right:12px;z-index:99999;display:flex;gap:8px;align-items:center;font-family:Arial, sans-serif;";
    const btn = document.createElement("button");
    btn.id = "uiLangBtn";
    btn.type = "button";
    btn.style.cssText = "cursor:pointer;border:0;border-radius:10px;padding:8px 10px;font-weight:700;box-shadow:0 6px 18px rgba(0,0,0,.2);background:rgba(255,255,255,.92);";
    btn.textContent = (getLang() === "de") ? "DE" : "EN";
    btn.addEventListener("click", async ()=>{
      const next = (getLang()==="de") ? "en" : "de";
      try{ await setLang(next); }catch(e){ console.error(e); }
    });
    wrap.appendChild(btn);
    document.body.appendChild(wrap);
  }
  document.addEventListener("DOMContentLoaded", async ()=>{
    ensureToggle();
    try{
      const dict = await loadLocale(getLang());
      apply(dict);
    }catch(e){
      console.error(e);
    }
  });
})();