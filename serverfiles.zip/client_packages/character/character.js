const player = mp.players.local;
var characterCam;
var characterBrowser;
let active = false;

// --- CC Safety helpers (patched) ---
let __ccOpToken = 0;

function __ccGetLocalPlayer() {
    try {
        const p = mp.players.local;
        if (!p || !mp.players.exists(p)) return null;
        return p;
    } catch (e) { return null; }
}

function __ccInvoke(hash, ...args) {
    try { return mp.game.invoke(hash, ...args); } catch (e) { return null; }
}

function __ccSetDefaultComponentVariationSafe(pedHandle) {
    // Prefer high level API if present, otherwise native fallback
    try {
        if (mp.game.ped && typeof mp.game.ped.setDefaultComponentVariation === "function") {
            mp.game.ped.setDefaultComponentVariation(pedHandle);
            return;
        }
    } catch (e) {}
    // Native: SET_PED_DEFAULT_COMPONENT_VARIATION (0x45EEE61580806D63)
    __ccInvoke("0x45EEE61580806D63", pedHandle);
}

async function __ccRequestModel(hash, timeoutMs = 5000) {
    mp.game.streaming.requestModel(hash);
    const start = Date.now();
    while (!mp.game.streaming.hasModelLoaded(hash)) {
        await mp.game.waitAsync(0);
        if (Date.now() - start > timeoutMs) return false;
    }
    return true;
}

function __ccClamp(v, min, max, defVal) {
    const n = Number(v);
    if (!Number.isFinite(n)) return defVal;
    return Math.min(max, Math.max(min, n));
}

function __ccApplyFaceFromState(p) {
    // uses existing global state variables in this file if present
    try {
        p.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0,
            __ccClamp(value_shapeMix, 0, 1, 0.5),
            __ccClamp(value_skinMix, 0, 1, 0.5),
            0, false);
    } catch (e) {}

    // Face features (0..19), values usually -1..1
    const ff = [
        ["value_noseWidth", 0],
        ["value_noseHeight", 1],
        ["value_noseLength", 2],
        ["value_noseBridge", 3],
        ["value_noseTip", 4],
        ["value_noseShift", 5],
        ["value_browHeight", 6],
        ["value_browWidth", 7],
        ["value_cheekBone", 8],
        ["value_cheekSide", 9],
        ["value_cheekWidth", 10],
        ["value_eyeOpen", 11],
        ["value_lipsThickness", 12],
        ["value_jawWidth", 13],
        ["value_jawHeight", 14],
        ["value_chinLength", 15],
        ["value_chinPos", 16],
        ["value_chinWidth", 17],
        ["value_chinShape", 18],
        ["value_neckWidth", 19]
    ];
    for (const [k, idx] of ff) {
        try {
            if (typeof globalThis[k] === "undefined") continue;
            p.setFaceFeature(idx, __ccClamp(globalThis[k], -1, 1, 0));
        } catch (e) {}
    }
}

async function __ccSetGenderSafe(value) {
    const p = __ccGetLocalPlayer();
    if (!p) return;

    const token = ++__ccOpToken;
    const isMale = Number(value) === 0;
    const modelHash = mp.game.joaat(isMale ? "mp_m_freemode_01" : "mp_f_freemode_01");

    const ok = await __ccRequestModel(modelHash);
    if (!ok) return;
    if (token !== __ccOpToken) return; // canceled

    // Apply model safely
    try { p.model = modelHash; } catch (e) { return; }

    await mp.game.waitAsync(0);
    if (token !== __ccOpToken) return;

    // Reset variations & props to avoid invalid components after swap
    try { __ccSetDefaultComponentVariationSafe(p.handle); } catch (e) {}
    try {
        if (mp.game.ped && typeof mp.game.ped.clearAllPedProps === "function") {
            mp.game.ped.clearAllPedProps(p.handle);
        }
    } catch (e) {}

    // Re-apply face twice (stability)
    try { __ccApplyFaceFromState(p); } catch (e) {}
    setTimeout(() => { try { if (__ccGetLocalPlayer()) __ccApplyFaceFromState(__ccGetLocalPlayer()); } catch (e) {} }, 50);
}



mp.events.add("CLIENT::OPEN:CHARACTER:CREATOR", () => {
    mp.events.call('CLIENT::REMOVE:LOGIN:BROWSER');
    characterBrowser = mp.browsers.new(`package://ui/ui-character/index.html`);
});

mp.events.add('CLIENT::OPEN:CHARACTER:CREATOR:WITH:CHARACTERS', async (name) => {
    mp.events.call('CLIENT::REMOVE:LOGIN:BROWSER');
    characterBrowser = mp.browsers.new(`package://ui/ui-character/index.html`);
    
       await name.forEach((character) => {
            characterBrowser.execute(`showCharacters('${character.character_name}')`);
        });
});
//==============================================================================================================================================================

// SYSTEM SLIDERS 

mp.events.add("CLIENT::CHANGE:ZOOM", (value) => {
    characterCam.setCoord(-797.7529907226562, 326.41558837890625 - parseFloat(value), 220.43862915039062);
    mp.game.cam.renderScriptCams(true, false, 0, true, false);
});

mp.events.add("CLIENT::CHANGE:CAMERA:HEIGHT", (value) => {
    characterCam.pointAtCoord(-797.7529907226562, 326.41558837890625, 220.43862915039062 + parseFloat(value));
    mp.game.cam.renderScriptCams(true, false, 0, true, false);
});

mp.events.add("CLIENT::CHANGE:ROTATION", (value) => {
    mp.events.callRemote("SERVER::CHANGE:ROTATION", value);
});


mp.events.addProc('CLIENT::CHECK:CHARACTER:SLOTS', async () => {
   const response = await mp.events.callRemoteProc('SERVER::CHECK:CHARACTER:SLOTS');
    if(!response) return;
   if(response > 0) {
        mp.game.streaming.requestIpl('apa_v_mp_h_01_a'); 
        player.position = new mp.Vector3(-797.7529907226562, 326.41558837890625, 220.43862915039062); 
        player.heading = 90;
        characterCam = mp.cameras.new('default', new mp.Vector3(-797.6807861328125, 330.9203186035156, 220.43862915039062), new mp.Vector3(0, 0, 0), 40);
        characterCam.pointAtCoord(-797.7529907226562, 326.41558837890625, 220.43862915039062);
        mp.game.graphics.transitionFromBlurred(1); 
        mp.game.cam.renderScriptCams(true, false, 0, true, false);
   }

   return JSON.stringify(response);
});

mp.events.add('CLIENT::SPAWN:PLAYER', (x, y, z) => { // remove login cam and the blur screen
    mp.gui.cursor.show(false, false);
    characterBrowser.destroy();

    setTimeout(() => {  
     mp.game.graphics.transitionFromBlurred(1); 
      mp.game.ui.displayRadar(true);
      mp.game.cam.renderScriptCams(false, false, 0, false, false);
      player.position = new mp.Vector3(x, y, z); 
      player.freezePosition(false);
      mp.gui.chat.activate(true); 
      mp.gui.chat.show(true); 
    }, 1500);

});

mp.events.add('CLIENT::CREATE:CHARACTER', (name, age, accent, features) => {
    
    const characterData = `{

        "gender": "${value_gender}",
        "name": "${name}",
        "age": "${age}",
        "accent": "${accent}",
        "features": "${features}",
        "mom": "${value_mom}",
        "dad": "${value_dad}",
        "shapeMix": "${value_shapeMix}",
        "skin1": "${value_skin1}",
        "skin2": "${value_skin2}",
        "skinMix": "${value_skinMix}",
        "noseWidth": "${value_noseWidth}",
        "noseHeight": "${value_noseHeight}",
        "noseTip": "${value_noseTip}",

        "jawWidth": "${value_jawWidth}",
        "jawHeight": "${value_jawHeight}",
        "chinWidth": "${value_chinWidth}",
        "chinLength": "${value_chinLength}",
        "neckWidth": "${value_neckWidth}",
        "eyes": "${value_eyes}",
        "eyesColor": "${value_eyesColor}",
        "eyebrows": "${value_eyebrows}",
        "lips": "${value_lips}",

        "hairStyle": "${value_hairStyle}",
        "hairColor": "${value_hairColor}",
        "beard": "${value_beard}",
        "beardColor": "${value_beardColor}",

        "tops": "${value_tops}",
        "topsColor": "${value_topsColor}",

        "legs": "${value_legs}",
        "legsColor": "${value_legsColor}",

        "undershirt": "${value_undershirt}",
        "undershirtColor": "${value_undershirtColor}",
        "torso": "${value_torso}",
        "shoes": "${value_shoes}",
        "shoesColor": "${value_shoesColor}"
        
    }`;
    mp.events.callRemote("SERVER::CREATE:CHARACTER", characterData);
});


mp.events.add('CLIENT::PLAY:CHARACTER', (characterName) => {
    mp.events.callRemote("SERVER::PLAY:CHARACTER", characterName);
});

// Freeze Character in creator
mp.events.add("render", () => {
    const freeze = player.getVariable("freeze");
    if(freeze == true) {
        player.clearTasksImmediately();
    }
});


// Defines
let value_gender = true;

let value_mom = 0;
let value_dad = 0;
let value_shapeMix = 0;
let value_skin1 = 0;
let value_skin2 = 0;
let value_skinMix = 0;
let value_noseWidth = 0;
let value_noseHeight = 0;
let value_noseTip = 0;

let value_jawWidth = 0;
let value_jawHeight = 0;
let value_chinWidth = 0;
let value_chinLength = 0;
let value_neckWidth = 0;
let value_eyes = 0;
let value_eyesColor = 0;
let value_eyebrows = 0;
let value_lips = 0;


let value_hairStyle = 0;
let value_hairColor = 0;
let value_beard = 0;
let value_beardColor = 0;

// Clothes Defines
let value_tops = 0;
let value_topsColor = 0;

let value_legs = 0;
let value_legsColor = 0;

let value_undershirt = 15;
let value_undershirtColor = 0;
let value_torso = 0;

let value_shoes = 0;
let value_shoesColor = 0;


// Events
mp.events.add('CLIENT::CHANGE:GENDER', async (value) => {
    // 0 = male, 1 = female
    if (Number(value) === 0) value_gender = true;
    if (Number(value) === 1) value_gender = false;
    await __ccSetGenderSafe(value);
});


mp.events.add('CLIENT::APPLY:CHARACTER:PRESET', async (jsonStr) => {
    const p = __ccGetLocalPlayer();
    if (!p) return;

    let preset = null;
    try { preset = JSON.parse(jsonStr); } catch (e) { return; }
    if (!preset || typeof preset !== "object") return;

    // apply gender first (safe)
    if (typeof preset.gender !== "undefined") {
        if (Number(preset.gender) === 0) value_gender = true;
        if (Number(preset.gender) === 1) value_gender = false;
        await __ccSetGenderSafe(preset.gender);
    }

    const p2 = __ccGetLocalPlayer();
    if (!p2) return;

    // Parents / blend
    if (typeof preset.mom !== "undefined") value_mom = parseInt(preset.mom);
    if (typeof preset.dad !== "undefined") value_dad = parseInt(preset.dad);
    if (typeof preset.skin1 !== "undefined") value_skin1 = parseInt(preset.skin1);
    if (typeof preset.skin2 !== "undefined") value_skin2 = parseInt(preset.skin2);
    if (typeof preset.shapeMix !== "undefined") value_shapeMix = __ccClamp(preset.shapeMix, 0, 1, value_shapeMix);
    if (typeof preset.skinMix !== "undefined") value_skinMix = __ccClamp(preset.skinMix, 0, 1, value_skinMix);

    // Face features map
    const map = {
        noseWidth: "value_noseWidth",
        noseHeight: "value_noseHeight",
        noseLength: "value_noseLength",
        noseBridge: "value_noseBridge",
        noseTip: "value_noseTip",
        noseShift: "value_noseShift",
        browHeight: "value_browHeight",
        browWidth: "value_browWidth",
        cheekBone: "value_cheekBone",
        cheekSide: "value_cheekSide",
        cheekWidth: "value_cheekWidth",
        eyeOpen: "value_eyeOpen",
        lipsThickness: "value_lipsThickness",
        jawWidth: "value_jawWidth",
        jawHeight: "value_jawHeight",
        chinLength: "value_chinLength",
        chinPos: "value_chinPos",
        chinWidth: "value_chinWidth",
        chinShape: "value_chinShape",
        neckWidth: "value_neckWidth"
    };
    if (preset.face && typeof preset.face === "object") {
        for (const k of Object.keys(map)) {
            if (typeof preset.face[k] === "undefined") continue;
            globalThis[map[k]] = __ccClamp(preset.face[k], -1, 1, globalThis[map[k]] ?? 0);
        }
    }

    // Cosmetics
    if (preset.cosmetics && typeof preset.cosmetics === "object") {
        if (typeof preset.cosmetics.hairStyle !== "undefined") value_hairStyle = parseInt(preset.cosmetics.hairStyle);
        if (typeof preset.cosmetics.hairColor !== "undefined") value_hairColor = parseInt(preset.cosmetics.hairColor);
        if (typeof preset.cosmetics.eyesColor !== "undefined") value_eyesColor = parseInt(preset.cosmetics.eyesColor);
        if (typeof preset.cosmetics.eyebrows !== "undefined") value_eyebrows = parseInt(preset.cosmetics.eyebrows);
        if (typeof preset.cosmetics.lips !== "undefined") value_lips = parseInt(preset.cosmetics.lips);
        if (typeof preset.cosmetics.beard !== "undefined") value_beard = parseInt(preset.cosmetics.beard);
        if (typeof preset.cosmetics.beardColor !== "undefined") value_beardColor = parseInt(preset.cosmetics.beardColor);
    }

    // Clothes (keep conservative to avoid crashes)
    if (preset.clothes && typeof preset.clothes === "object") {
        if (typeof preset.clothes.tops !== "undefined") value_tops = parseInt(preset.clothes.tops);
        if (typeof preset.clothes.topsColor !== "undefined") value_topsColor = parseInt(preset.clothes.topsColor);
        if (typeof preset.clothes.torso !== "undefined") value_torso = parseInt(preset.clothes.torso);
        if (typeof preset.clothes.undershirt !== "undefined") value_undershirt = parseInt(preset.clothes.undershirt);
        if (typeof preset.clothes.undershirtColor !== "undefined") value_undershirtColor = parseInt(preset.clothes.undershirtColor);
        if (typeof preset.clothes.legs !== "undefined") value_legs = parseInt(preset.clothes.legs);
        if (typeof preset.clothes.legsColor !== "undefined") value_legsColor = parseInt(preset.clothes.legsColor);
        if (typeof preset.clothes.shoes !== "undefined") value_shoes = parseInt(preset.clothes.shoes);
        if (typeof preset.clothes.shoesColor !== "undefined") value_shoesColor = parseInt(preset.clothes.shoesColor);
    }

    // Apply everything
    __ccApplyFaceFromState(p2);

    // Cosmetics apply (wrapped)
    try {
        if (typeof value_hairStyle !== "undefined") p2.setComponentVariation(2, Math.max(0, value_hairStyle|0), 0, 0);
        if (typeof value_hairColor !== "undefined") p2.setHairColor(Math.max(0, value_hairColor|0), 0);
        if (typeof value_eyesColor !== "undefined") p2.setEyeColor(Math.max(0, value_eyesColor|0));
    } catch (e) {}

    try {
        if (typeof value_eyebrows !== "undefined") {
            p2.setHeadOverlay(2, Math.max(0, value_eyebrows|0), 1.0);
        }
        if (typeof value_lips !== "undefined") {
            p2.setHeadOverlay(8, Math.max(0, value_lips|0), 1.0);
        }
        // Disable beard for female
        if (value_gender === false) {
            value_beard = 0;
        }
        if (typeof value_beard !== "undefined") {
            p2.setHeadOverlay(1, Math.max(0, value_beard|0), 1.0);
        }
    } catch (e) {}

    try {
        // Clothes
        if (typeof value_torso !== "undefined") p2.setComponentVariation(3, Math.max(0, value_torso|0), 0, 0);
        if (typeof value_tops !== "undefined") p2.setComponentVariation(11, Math.max(0, value_tops|0), Math.max(0, value_topsColor|0), 0);
        if (typeof value_undershirt !== "undefined") p2.setComponentVariation(8, Math.max(0, value_undershirt|0), Math.max(0, value_undershirtColor|0), 0);
        if (typeof value_legs !== "undefined") p2.setComponentVariation(4, Math.max(0, value_legs|0), Math.max(0, value_legsColor|0), 0);
        if (typeof value_shoes !== "undefined") p2.setComponentVariation(6, Math.max(0, value_shoes|0), Math.max(0, value_shoesColor|0), 0);
    } catch (e) {}

    // re-apply once more shortly after
    setTimeout(() => {
        try {
            const p3 = __ccGetLocalPlayer();
            if (!p3) return;
            __ccApplyFaceFromState(p3);
        } catch (e) {}
    }, 50);
});




mp.events.add("CLIENT::CHANGE:MOM", (value) => {
    value_mom = parseInt(value);
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:DAD", (value) => {
    value_dad = parseInt(value);
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:SHAPE:MIX", (value) => {
    value_shapeMix = value;
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:SKIN:1", (value) => {
    value_skin1 = parseInt(value);
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:SKIN:2", (value) => {
    value_skin2 = parseInt(value);
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:SKIN:MIX", (value) => {
    value_skinMix = value;
    player.setHeadBlendData(value_mom, value_dad, 0, value_skin1, value_skin2, 0, value_shapeMix, value_skinMix, 0, false);
});

mp.events.add("CLIENT::CHANGE:NOSE:WIDTH", (value) => {
    value_noseWidth = value;
    player.setFaceFeature(0, value_noseWidth);
});

mp.events.add("CLIENT::CHANGE:NOSE:HEIGHT", (value) => {
    value_noseHeight = value;
    player.setFaceFeature(1, value_noseHeight);
});

mp.events.add("CLIENT::CHANGE:NOSE:TIP", (value) => {
    value_noseTip = value;
    player.setFaceFeature(4, value_noseTip);
});

mp.events.add("CLIENT::CHANGE:JAW:WIDTH", (value) => {
    value_jawWidth = value;
    player.setFaceFeature(13, value_jawWidth);
});

mp.events.add("CLIENT::CHANGE:JAW:HEIGHT", (value) => {
    value_jawHeight = value;
    player.setFaceFeature(14, value_jawHeight);
});

mp.events.add("CLIENT::CHANGE:CHIN:WIDTH", (value) => {
    value_chinWidth = value;
    player.setFaceFeature(17, value_chinWidth);
});

mp.events.add("CLIENT::CHANGE:CHIN:LENGTH", (value) => {
    value_chinLength = value;
    player.setFaceFeature(15, value_chinLength);
});


mp.events.add("CLIENT::CHANGE:NECK:WIDTH", (value) => {
    value_neckWidth = value;
    player.setFaceFeature(19, value_neckWidth);
});

mp.events.add("CLIENT::CHANGE:EYES", (value) => {
    value_eyes = value;
    player.setFaceFeature(11, value_eyes);
});

mp.events.add("CLIENT::CHANGE:EYES:COLOR", (value) => {
    value_eyesColor = value;
    player.setEyeColor(value_eyesColor);
});

mp.events.add("CLIENT::CHANGE:EYEBROWS", (value) => {
    value_eyebrows = parseInt(value);
    player.setHeadOverlay(2, value_eyebrows, 100, 0, 0);
});

mp.events.add("CLIENT::CHANGE:LIPS", (value) => {
    value_lips = value;
    player.setFaceFeature(12, value_lips);
});



// next page
mp.events.add("CLIENT::CHANGE:HAIR", (value) => {
    value_hairStyle = parseInt(value);
    player.setComponentVariation(2, value_hairStyle, 0, 0);
});

mp.events.add("CLIENT::CHANGE:HAIR:COLOR", (value) => {
    value_hairColor = parseInt(value);
    player.setHairColor(value_hairColor, 0);
});

mp.events.add("CLIENT::CHANGE:BEARD", (value) => {
    if(value_gender == true) {
        value_beard = parseInt(value);
        player.setHeadOverlay(1, value_beard, 255, value_beardColor, value_beardColor);
    }
});

mp.events.add("CLIENT::CHANGE:BEARD:COLOR", (value) => {

    if(value_gender == true) {
        value_beardColor = parseInt(value);
        //player.setHeadOverlayColor(1, 255, value_beard, value_beard);
        //player.setHeadOverlay(1, value_beard, 100, value_beardColor, 255);
        //player.setHeadOverlayColor(1, 255, value_beardColor, value_beardColor);
        player.setHeadOverlay(1, value_beard, 255, value_beardColor, value_beardColor);
    }
});

// Clothing events
  

mp.events.add("CLIENT::CHANGE:TOPS", (value) => {
    value_tops = parseInt(value);
    value_topsColor = 0;
    player.setComponentVariation(11, value_tops, value_topsColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});

mp.events.add("CLIENT::CHANGE:TOPS:COLOR", (value) => {
    value_topsColor = parseInt(value);
    player.setComponentVariation(11, value_tops, value_topsColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});

mp.events.add("CLIENT::CHANGE:LEGS", (value) => {
    value_legs = parseInt(value);
    player.setComponentVariation(4, value_legs, value_legsColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});

mp.events.add("CLIENT::CHANGE:LEGS:COLOR", (value) => {
    value_legsColor = parseInt(value);
    player.setComponentVariation(4, value_legs, value_legsColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});

mp.events.add("CLIENT::CHANGE:UNDERSHIRT", (value) => {
    if(parseInt(value) == 0) {
        value_undershirt = 15;
    } else {
        value_undershirt = parseInt(value);
    }
    player.setComponentVariation(8, value_undershirt, value_undershirtColor, 0);
});

mp.events.add("CLIENT::CHANGE:UNDERSHIRT:COLOR", (value) => {
    value_undershirtColor = parseInt(value);
    player.setComponentVariation(8, value_undershirt, value_undershirtColor, 0);
});

mp.events.add("CLIENT::CHANGE:TORSO", (value) => {
    value_torso = parseInt(value);
    player.setComponentVariation(3, value_torso, 0, 0);
});

mp.events.add("CLIENT::CHANGE:SHOES", (value) => {
    value_shoes = parseInt(value);
    player.setComponentVariation(6, value_shoes, value_shoesColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});

mp.events.add("CLIENT::CHANGE:SHOES:COLOR", (value) => {
    value_shoesColor = parseInt(value);
    player.setComponentVariation(6, value_shoes, value_shoesColor, 0);

    if(value_undershirt == 15) {
        player.setComponentVariation(8, 15, 0, 0);
    }
});