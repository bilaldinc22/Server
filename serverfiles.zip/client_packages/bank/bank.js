// Bank/ATM UI bridge (client-side)
// Server is authoritative. CEF only triggers requests.

const bankbrowser = mp.browsers.new('package://ui/ui-bank/index.html');
bankbrowser.active = false;

let uiOpen = false;
let uiContext = 'BANK'; // BANK | ATM
let lastOpenAt = 0;

function openUI(context) {
    if (uiOpen) return;
    uiContext = context || 'BANK';
    lastOpenAt = Date.now();

    mp.game.graphics.transitionToBlurred(200);
    mp.gui.cursor.show(true, true);

    bankbrowser.active = true;
    uiOpen = true;

    // Request fresh data from server
    mp.events.callRemote('SERVER::BANK:UI_OPEN', uiContext);
}

function closeUI() {
    if (!uiOpen) return;

    mp.game.graphics.transitionFromBlurred(200);
    mp.gui.cursor.show(false, false);

    bankbrowser.active = false;
    uiOpen = false;
    mp.events.callRemote('SERVER::BANK:UI_CLOSE');
}

mp.events.add('CLIENT::OPEN:BANK', (context = 'BANK') => openUI(context));
mp.events.add('CLIENT::CLOSE:BANK', () => closeUI());

// Server -> client payload relay to CEF
mp.events.add('CLIENT::BANK:UI_DATA', (json) => {
    if (!uiOpen) return;
    // json is a string
    bankbrowser.execute(`window.bankSetData(${json});`);
});

mp.events.add('CLIENT::BANK:NOTIFY', (ok, message) => {
    if (!uiOpen) return;
    bankbrowser.execute(`window.bankNotify(${JSON.stringify(message)}, ${ok ? 'true' : 'false'});`);
});

// CEF -> client events (mp.trigger)
mp.events.add('BANK:UI:READY', () => {
    if (!uiOpen) return;
    // Re-request to ensure UI always populated
    mp.events.callRemote('SERVER::BANK:UI_OPEN', uiContext);
});

mp.events.add('BANK:UI:CLOSE', () => closeUI());

mp.events.add('BANK:DEPOSIT', (amount) => {
    mp.events.callRemote('SERVER::DEPOSIT:MONEY', amount);
});

mp.events.add('BANK:WITHDRAW', (amount, pin) => {
    mp.events.callRemote('SERVER::WITHDRAW:MONEY', amount, pin || '');
});

mp.events.add('BANK:TRANSFER', (target, amount, pin) => {
    mp.events.callRemote('SERVER::TRANSFER:MONEY', target || '', amount, pin || '');
});

mp.events.add('BANK:SET_ACTIVE', (iban) => {
    mp.events.callRemote('SERVER::BANK:SET_ACTIVE', iban || '');
});

// Invoices
mp.events.add('BANK:INVOICE:CREATE', (targetIban, amount, reason) => {
    mp.events.callRemote('SERVER::BANK:INVOICE_CREATE', targetIban || '', amount, reason || '');
});
mp.events.add('BANK:INVOICE:PAY', (invoiceId, pin) => {
    mp.events.callRemote('SERVER::BANK:INVOICE_PAY', invoiceId, pin || '');
});
mp.events.add('BANK:INVOICE:CANCEL', (invoiceId) => {
    mp.events.callRemote('SERVER::BANK:INVOICE_CANCEL', invoiceId);
});

// Standing orders
mp.events.add('BANK:SO:CREATE', (targetIban, amount, intervalHours, reason, pin) => {
    mp.events.callRemote('SERVER::BANK:SO_CREATE', targetIban || '', amount, intervalHours, reason || '', pin || '');
});
mp.events.add('BANK:SO:TOGGLE', (soId, enabled) => {
    mp.events.callRemote('SERVER::BANK:SO_TOGGLE', soId, !!enabled);
});
mp.events.add('BANK:SO:DELETE', (soId) => {
    mp.events.callRemote('SERVER::BANK:SO_DELETE', soId);
});

// Company accounts
mp.events.add('BANK:COMPANY:CREATE', (name) => {
    mp.events.callRemote('SERVER::BANK:COMPANY_CREATE', name || '');
});
mp.events.add('BANK:COMPANY:MEMBER_ADD', (accountIban, characterName, role) => {
    mp.events.callRemote('SERVER::BANK:COMPANY_MEMBER_ADD', accountIban || '', characterName || '', role || 'member');
});
mp.events.add('BANK:COMPANY:MEMBER_ROLE', (accountIban, characterId, role) => {
    mp.events.callRemote('SERVER::BANK:COMPANY_MEMBER_ROLE', accountIban || '', characterId, role || 'member');
});
mp.events.add('BANK:COMPANY:MEMBER_REMOVE', (accountIban, characterId) => {
    mp.events.callRemote('SERVER::BANK:COMPANY_MEMBER_REMOVE', accountIban || '', characterId);
});

// Security (PIN)
mp.events.add('BANK:PIN:SET', (newPin) => {
    mp.events.callRemote('SERVER::BANK:PIN_SET', newPin || '');
});
mp.events.add('BANK:PIN:CHANGE', (oldPin, newPin) => {
    mp.events.callRemote('SERVER::BANK:PIN_CHANGE', oldPin || '', newPin || '');
});
