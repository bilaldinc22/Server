// SAFE CLICK FIX for RAGE:MP CEF (does not modify your HTML/CSS layout)
function applyBankClickFix(browser) {
  try {
    if (!browser || typeof browser.execute !== 'function') return;

    const css = `
      /* ===== SAFE CEF CLICK FIX (injected) ===== */
      select, option, input, textarea, button, label, a,
      .no-drag, .no-drag * {
        -webkit-app-region: no-drag !important;
        pointer-events: auto !important;
      }
      /* Decorative overlays must not capture clicks */
      .overlay, .bg, .background, .decor, .glow, .gradient, .shadow,
      .fx, .effects, .particles {
        pointer-events: none !important;
      }
    `;

    const js = `
      (function(){
        try {
          var style = document.getElementById('___cef_clickfix_style');
          if(!style){
            style = document.createElement('style');
            style.id = '___cef_clickfix_style';
            style.type = 'text/css';
            style.appendChild(document.createTextNode(${json.dumps(css)}));
            document.head.appendChild(style);
          }
          var nodes = document.querySelectorAll('select,input,textarea,button,label,a');
          for (var i=0;i<nodes.length;i++){
            nodes[i].classList.add('no-drag');
          }
        } catch(e){}
      })();
    `;

    browser.execute(js);
  } catch (e) {
    // silent
  }
}

// RAGE:MP client scripts do not provide Node's `module` object.
// Export in the most compatible way.
try { exports.applyBankClickFix = applyBankClickFix; } catch (e) {}
try { globalThis.applyBankClickFix = applyBankClickFix; } catch (e) {}
