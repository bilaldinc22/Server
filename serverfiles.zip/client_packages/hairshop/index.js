
"use strict";

/**
 * client_packages/hairshop/index.js
 * NativeUI Hairshop with submenu per hairstyle:
 * - Main menu: list of hairstyles
 * - Click hairstyle -> opens submenu:
 *     Farbe (Left/Right)
 *     Highlight (Left/Right)
 *     Kaufen/Speichern
 *     Zurück
 *
 * Compatibility:
 * - Uses MenuItems if present (fallback to Items)
 * - Uses mp.game.invoke native GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS
 * - Uses raw keybinds for E/ESC/BACKSPACE/LEFT/RIGHT/ENTER to survive control blockers
 * - Also handles ItemSelect so clicking works even if Enter is blocked
 */

const NativeUI = require("nativeui");
const { Menu, UIMenuItem, Point } = NativeUI;

// ---- Embedded config ------------------------------------------------------------

const cfg = {
  openDist: 4.5,
  blipSprite: 71,
  blipColor: 0,
  blipScale: 0.8,
  blipName: "Friseur",

  shopsExterior: [
    new mp.Vector3(-823.0681, -183.9033, 36.5531),
    new mp.Vector3(134.6110, -1707.9956, 28.2799),
    new mp.Vector3(1211.4066, -470.7033, 66.1978),
    new mp.Vector3(-1284.0791, -1115.4725, 6.9875),
    new mp.Vector3(1930.8264, 3728.2153, 30.8352),
    new mp.Vector3(-277.9121, 6230.4790, 30.6893),
    new mp.Vector3(-30.7516, -151.6879, 56.0652)
  ],

  shopsInterior: [
    new mp.Vector3(-815.20, -184.15, 37.57),
    new mp.Vector3(136.80, -1708.45, 29.29),
    new mp.Vector3(1212.80, -472.90, 67.20),
    new mp.Vector3(-1282.90, -1117.10, 7.00),
    new mp.Vector3(1933.05, 3729.75, 32.84),
    new mp.Vector3(-280.05, 6231.70, 32.70),
    new mp.Vector3(-34.20, -154.40, 57.08)
  ]
};

// ---- helpers -------------------------------------------------------------------

function notify(msg){ try { mp.game.graphics.notify(String(msg)); } catch(_){} }

function getMenuItems(m){
  return (m && m.MenuItems) ? m.MenuItems : (m && m.Items) ? m.Items : [];
}

function isFreemode() {
  const m = mp.players.local.model;
  return (m === mp.game.joaat("mp_m_freemode_01") || m === mp.game.joaat("mp_f_freemode_01"));
}

function dist(a,b){ const dx=a.x-b.x,dy=a.y-b.y,dz=a.z-b.z; return Math.sqrt(dx*dx+dy*dy+dz*dz); }

function isNearShop(){
  const pos=mp.players.local.position;
  const d=Number(cfg.openDist||4.5);
  for(const s of cfg.shopsInterior) if(dist(pos,s)<=d) return true;
  for(const s of cfg.shopsExterior) if(dist(pos,s)<=d) return true;
  return false;
}

// Native: GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS
function getDrawableVariationsCount(pedHandle, componentId) {
  try { return Number(mp.game.invoke("0x27561561732A7842", pedHandle, componentId)) || 0; }
  catch (_) { return 0; }
}
function waitForHair(cb, tries=0){
  const p=mp.players.local;
  const count=getDrawableVariationsCount(p.handle,2);
  if(count > 2 || tries >= 30) return cb(count);
  mp.setTimeout(()=>waitForHair(cb,tries+1),50);
}

// ---- preview / reset ------------------------------------------------------------

let original = null;

function captureOriginal(){
  const p=mp.players.local;
  const barber=p.getVariable("barber")||{};
  original={
    hair:p.getDrawableVariation(2),
    hairColor:Number(barber.hairColor||0),
    hairHighlight:Number(barber.hairHighlight||barber.hairColor||0)
  };
}

function applyPreview(h,c,hl){
  const p=mp.players.local;
  try{ p.setComponentVariation(2,h,0,2);}catch(_){}
  try{ p.setHairColor(c,hl);}catch(_){}
}

function resetPreview(){
  if(!original) return;
  applyPreview(original.hair, original.hairColor, original.hairHighlight);
  original=null;
}

function sendSave(h, c, hl){
  const payload = { type:"gta", hair: h, hairColor: c, hairHighlight: hl };
  // notify so you see the click fired
  notify("~g~Speichern gesendet…");
  try { mp.events.callRemote("hairshop:buy", JSON.stringify(payload)); } catch (_) {}
  try { mp.events.callRemote("hairshop:save", JSON.stringify(payload)); } catch (_) {}
  try { mp.events.callRemote("barber:save", JSON.stringify(payload)); } catch (_) {}
  try { mp.events.callRemote("appearance:barberSave", JSON.stringify(payload)); } catch (_) {}
}

// ---- menus ---------------------------------------------------------------------

let mainMenu = null;
let subMenu = null;

let isOpen = false;
let inSub = false;

let hairCount = 0;
let selectedHair = 0;
let hairColor = 0;
let hairHighlight = 0;

let idxColor = -1;
let idxHighlight = -1;
let idxBuy = -1;
let idxBack = -1;

function clearMenu(m){
  if(!m) return;
  const items=getMenuItems(m);
  if(typeof m.RemoveItemAt==="function" && items && items.length){
    for(let i=items.length-1;i>=0;i--){ try{ m.RemoveItemAt(i);}catch(_){ } }
  } else if(items) {
    items.length=0;
  }
}

function buildMenus(){
  if(!mainMenu){
    mainMenu = new Menu(cfg.blipName || "Friseur", "Frisur auswählen", new Point(50, 50));
    mainMenu.Visible = false;

    // close whole shop => cancel
    mainMenu.MenuClose.on(() => {
      if(!isOpen) return;
      closeAll(false);
    });

    // click a hairstyle => open submenu
    if(mainMenu.ItemSelect && typeof mainMenu.ItemSelect.on==="function"){
      mainMenu.ItemSelect.on((item, index) => {
        if(!isOpen || inSub) return;
        if(index >= 0 && index < hairCount){
          selectedHair = index;
          // start preview immediately
          applyPreview(selectedHair, hairColor, hairHighlight);
          openSubmenu();
        }
      });
    }
  }

  if(!subMenu){
    subMenu = new Menu("Frisur", "Optionen", new Point(70, 70));
    subMenu.Visible = false;

    subMenu.MenuClose.on(() => {
      if(!isOpen || !inSub) return;
      // closing submenu returns to main menu
      backToMain();
    });

    if(subMenu.ItemSelect && typeof subMenu.ItemSelect.on==="function"){
      subMenu.ItemSelect.on((item, index) => {
        if(!isOpen || !inSub) return;
        if(index === idxBuy){
          closeAll(true);
        } else if(index === idxBack){
          backToMain();
        }
      });
    }
  }
}

function rebuildMainMenu(){
  clearMenu(mainMenu);
  for(let i=0;i<hairCount;i++){
    mainMenu.AddItem(new UIMenuItem(`Frisur #${i}`, "Anklicken für Optionen"));
  }
  try { mainMenu.RefreshIndex(); } catch(_){}
}

function rebuildSubmenu(){
  clearMenu(subMenu);

  subMenu.AddItem(new UIMenuItem("Farbe", "Links/Rechts ändern"));
  idxColor = getMenuItems(subMenu).length - 1;

  subMenu.AddItem(new UIMenuItem("Highlight", "Links/Rechts ändern"));
  idxHighlight = getMenuItems(subMenu).length - 1;

  subMenu.AddItem(new UIMenuItem("Kaufen / Speichern", ""));
  idxBuy = getMenuItems(subMenu).length - 1;

  subMenu.AddItem(new UIMenuItem("Zurück", "Zurück zur Frisuren-Liste"));
  idxBack = getMenuItems(subMenu).length - 1;

  updateSubLabels();
  try { subMenu.RefreshIndex(); } catch(_){}
}

function updateSubLabels(){
  const items=getMenuItems(subMenu);
  if(idxColor>=0 && items[idxColor]) items[idxColor].RightLabel = String(hairColor);
  if(idxHighlight>=0 && items[idxHighlight]) items[idxHighlight].RightLabel = String(hairHighlight);
  // show which hairstyle is selected in subtitle
  try { subMenu.Subtitle = `Frisur #${selectedHair}`; } catch(_){}
}

function openShop(){
  if(isOpen) return;
  if(!isNearShop()) return;

  if(!isFreemode()){
    notify("~r~Friseur: Nur Freemode-Charaktere.");
    return;
  }

  buildMenus();

  isOpen = true;
  inSub = false;

  mp.players.local.freezePosition(true);
  mp.gui.cursor.visible = false;

  captureOriginal();

  // start values
  const p=mp.players.local;
  selectedHair = p.getDrawableVariation(2);

  hairColor = original?.hairColor ?? 0;
  hairHighlight = original?.hairHighlight ?? hairColor;

  waitForHair((count)=>{
    hairCount = Math.max(count, 1);
    if(selectedHair >= hairCount) selectedHair = 0;

    rebuildMainMenu();

    // focus current hair
    try { mainMenu.CurrentSelection = Math.min(Math.max(selectedHair, 0), hairCount - 1); } catch(_){}

    mainMenu.Visible = true;
    subMenu.Visible = false;
  });
}

function openSubmenu(){
  if(!isOpen) return;
  inSub = true;

  rebuildSubmenu();

  mainMenu.Visible = false;
  subMenu.Visible = true;

  // focus first item (Farbe)
  try { subMenu.CurrentSelection = 0; } catch(_){}
  updateSubLabels();
}

function backToMain(){
  if(!isOpen) return;
  inSub = false;

  subMenu.Visible = false;
  mainMenu.Visible = true;

  // keep selection highlighted
  try { mainMenu.CurrentSelection = Math.min(Math.max(selectedHair, 0), hairCount - 1); } catch(_){}
}

function closeAll(save){
  if(!isOpen) return;

  if(save){
    sendSave(selectedHair, hairColor, hairHighlight);
    original = null; // keep new look
  } else {
    resetPreview();
  }

  isOpen = false;
  inSub = false;

  try { mp.players.local.freezePosition(false); } catch(_){}
  try { mp.gui.cursor.visible = false; } catch(_){}

  if(mainMenu) mainMenu.Visible = false;
  if(subMenu) subMenu.Visible = false;
}

// ---- keybinds (raw) ------------------------------------------------------------

// E open
mp.keys.bind(0x45, true, () => { if(!isOpen) openShop(); });

// ESC / BACKSPACE cancel (whole shop or submenu)
mp.keys.bind(0x1B, true, () => { if(isOpen){ if(inSub) backToMain(); else closeAll(false); } });
mp.keys.bind(0x08, true, () => { if(isOpen){ if(inSub) backToMain(); else closeAll(false); } });

// ENTER: in main -> open submenu for current selection; in sub -> buy/back based on current row
mp.keys.bind(0x0D, true, () => {
  if(!isOpen) return;

  if(!inSub){
    // open submenu on current selection
    const sel = mainMenu ? mainMenu.CurrentSelection : -1;
    if(sel >= 0 && sel < hairCount){
      selectedHair = sel;
      applyPreview(selectedHair, hairColor, hairHighlight);
      openSubmenu();
    }
    return;
  }

  // in submenu
  const sel = subMenu ? subMenu.CurrentSelection : -1;
  if(sel === idxBuy) return closeAll(true);
  if(sel === idxBack) return backToMain();
});

// LEFT / RIGHT: only in submenu for Farbe/Highlight
mp.keys.bind(0x25, true, () => { // left
  if(!isOpen || !inSub || !subMenu || !subMenu.Visible) return;
  const sel = subMenu.CurrentSelection;
  if(sel === idxColor){
    hairColor = Math.max(0, hairColor - 1);
    updateSubLabels();
    applyPreview(selectedHair, hairColor, hairHighlight);
  } else if(sel === idxHighlight){
    hairHighlight = Math.max(0, hairHighlight - 1);
    updateSubLabels();
    applyPreview(selectedHair, hairColor, hairHighlight);
  }
});
mp.keys.bind(0x27, true, () => { // right
  if(!isOpen || !inSub || !subMenu || !subMenu.Visible) return;
  const sel = subMenu.CurrentSelection;
  if(sel === idxColor){
    hairColor = Math.min(63, hairColor + 1);
    updateSubLabels();
    applyPreview(selectedHair, hairColor, hairHighlight);
  } else if(sel === idxHighlight){
    hairHighlight = Math.min(63, hairHighlight + 1);
    updateSubLabels();
    applyPreview(selectedHair, hairColor, hairHighlight);
  }
});

// Render: keep NativeUI responsive and preview when scrolling main list
mp.events.add("render", () => {
  if(!isOpen) return;

  if(!inSub && mainMenu && mainMenu.Visible){
    try { mainMenu.ProcessControls(); } catch(_){}
    try { mainMenu.ProcessMouse(); } catch(_){}

    // live preview while browsing list
    const sel = mainMenu.CurrentSelection;
    if(sel >= 0 && sel < hairCount){
      applyPreview(sel, hairColor, hairHighlight);
    }
  }

  if(inSub && subMenu && subMenu.Visible){
    try { subMenu.ProcessControls(); } catch(_){}
    try { subMenu.ProcessMouse(); } catch(_){}
  }
});

// server notify
mp.events.add("hairshop:notify", (msg) => notify(msg));

// debug /hair
mp.events.add("playerCommand", (cmd)=>{
  const c=String(cmd||"").trim().toLowerCase();
  if(c==="hair"){
    if(!isOpen) openShop();
    else closeAll(false);
  }
});

// blips
for(const p of cfg.shopsExterior){
  try{
    const blip=mp.game.ui.addBlipForCoord(p.x,p.y,p.z);
    mp.game.ui.setBlipSprite(blip, cfg.blipSprite);
    mp.game.ui.setBlipColour(blip, cfg.blipColor);
    mp.game.ui.setBlipScale(blip, cfg.blipScale);
    mp.game.ui.setBlipAsShortRange(blip,true);
    mp.game.ui.beginTextCommandSetBlipName("STRING");
    mp.game.ui.addTextComponentSubstringPlayerName(cfg.blipName);
    mp.game.ui.endTextCommandSetBlipName(blip);
  }catch(_){}
}
