
"use strict";

/**
 * client_packages/hairshop/index.js
 * Fixes:
 * - Removes the text UI in the top-left corner (no drawText overlay).
 * - Live preview works even when other resources disable GTA controls:
 *   uses mp.keys.bind (raw key binds) instead of mp.game.controls.
 * Notes:
 * - If your player model is NOT freemode (mp_m_freemode_01 / mp_f_freemode_01),
 *   GTA Online hair drawables will be very limited (often 1-2).
 */

// --- Internal config (no external require) ---------------------------------------
const cfg = {
  openDist: 2.0,

  markerType: 1,
  markerScale: 1.0,
  markerColor: [255, 0, 0, 150],

  blipSprite: 71,  // scissors
  blipColor: 0,
  blipScale: 0.8,
  blipName: "Friseur",

  shops: [
    new mp.Vector3(-823.068115, -183.903290, 36.553101),  // Rockford Hills
    new mp.Vector3(134.610992, -1707.995605, 28.279907),  // Davis / Strawberry
    new mp.Vector3(1211.406616, -470.703308, 66.197754),  // Mirror Park
    new mp.Vector3(-1284.079102, -1115.472534, 6.987549), // Vespucci
    new mp.Vector3(1930.826416, 3728.215332, 30.835205),  // Sandy Shores
    new mp.Vector3(-277.912079, 6230.479004, 30.689331),  // Paleto Bay
    new mp.Vector3(-30.751646, -151.687912, 56.065186)    // Hawick
  ]
};

// --- Keycodes (raw) --------------------------------------------------------------
const KEY_E = 0x45;
const KEY_UP = 0x26;
const KEY_DOWN = 0x28;
const KEY_LEFT = 0x25;
const KEY_RIGHT = 0x27;
const KEY_ENTER = 0x0D;
const KEY_BACK = 0x08;      // Backspace
const KEY_ESC = 0x1B;       // Escape

// internal state
let isOpen = false;
let selection = 0;
let hairCount = 0;
let hairColor = 0;
let hairHighlight = 0;
let original = null;
let activeShopIndex = -1;

// --- Blips / Markers / Colshapes -------------------------------------------------
function createShopBlipsAndMarkers() {
  const shops = Array.isArray(cfg.shops) ? cfg.shops : [];
  if (!shops.length) return;

  for (let i = 0; i < shops.length; i++) {
    const pos = shops[i];

    // Blip
    try {
      const blip = mp.game.ui.addBlipForCoord(pos.x, pos.y, pos.z);
      mp.game.ui.setBlipSprite(blip, cfg.blipSprite ?? 71);
      mp.game.ui.setBlipColour(blip, cfg.blipColor ?? 0);
      mp.game.ui.setBlipScale(blip, cfg.blipScale ?? 0.8);
      mp.game.ui.setBlipAsShortRange(blip, true);

      mp.game.ui.beginTextCommandSetBlipName("STRING");
      mp.game.ui.addTextComponentSubstringPlayerName(String(cfg.blipName || "Friseur"));
      mp.game.ui.endTextCommandSetBlipName(blip);
    } catch (_) {}

    // Marker
    try {
      mp.markers.new(
        cfg.markerType ?? 1,
        new mp.Vector3(pos.x, pos.y, pos.z - 1.0),
        cfg.markerScale ?? 1.0,
        { color: cfg.markerColor ?? [255, 0, 0, 150], visible: true, dimension: 0 }
      );
    } catch (_) {}

    // Colshape
    try {
      const dist = Math.max(Number(cfg.openDist || 2.0), 1.5);
      const cs = mp.colshapes.newSphere(pos.x, pos.y, pos.z, dist);
      cs.__hairshopIndex = i;
    } catch (_) {}
  }
}
createShopBlipsAndMarkers();

mp.events.add("playerEnterColshape", (shape) => {
  if (shape && shape.__hairshopIndex !== undefined) activeShopIndex = shape.__hairshopIndex;
});
mp.events.add("playerExitColshape", (shape) => {
  if (shape && shape.__hairshopIndex !== undefined) {
    if (activeShopIndex === shape.__hairshopIndex) activeShopIndex = -1;
  }
});

// --- Helpers ---------------------------------------------------------------------
function clamp(v, min, max) {
  v = Number(v) || 0;
  return Math.min(Math.max(v, min), max);
}

function getSavedBarberFallback() {
  try {
    const v = mp.players.local.getVariable("barber");
    if (v && typeof v === "object") return v;
  } catch (_) {}
  return null;
}

function getHairCount() {
  const p = mp.players.local;
  try { return mp.game.ped.getNumberOfPedDrawableVariations(p.handle, 2); }
  catch (_) { return 0; }
}

function captureOriginal() {
  const p = mp.players.local;
  const saved = getSavedBarberFallback();

  original = {
    hair: (typeof p.getDrawableVariation === "function") ? p.getDrawableVariation(2) : 0,
    hairColor: Number(saved?.hairColor ?? 0),
    hairHighlight: Number(saved?.hairHighlight ?? (saved?.hairColor ?? 0))
  };
}

function applyPreview() {
  const p = mp.players.local;
  const h = clamp(selection, 0, Math.max(0, hairCount - 1));

  try { p.setComponentVariation(2, h, 0, 2); } catch (_) {}
  try { p.setHairColor(clamp(hairColor, 0, 63), clamp(hairHighlight, 0, 63)); } catch (_) {}
}

function restoreOriginal() {
  const p = mp.players.local;
  if (!original) return;

  try { p.setComponentVariation(2, original.hair, 0, 2); } catch (_) {}
  try { p.setHairColor(original.hairColor, original.hairHighlight); } catch (_) {}
  original = null;
}

function tryRemoteSave() {
  const payload = {
    type: "gta",
    hair: clamp(selection, 0, Math.max(0, hairCount - 1)),
    hairColor: clamp(hairColor, 0, 63),
    hairHighlight: clamp(hairHighlight, 0, 63)
  };

  // Multiple common server event names (server can ignore unknown)
  try { mp.events.callRemote("hairshop:buy", payload.hair, payload.hairColor, payload.hairHighlight); } catch (_) {}
  try { mp.events.callRemote("hairshop:save", JSON.stringify(payload)); } catch (_) {}
  try { mp.events.callRemote("barber:save", JSON.stringify(payload)); } catch (_) {}
  try { mp.events.callRemote("appearance:barberSave", JSON.stringify(payload)); } catch (_) {}
}

function notify(msg) {
  try { mp.game.graphics.notify(String(msg)); } catch (_) {}
}

function openShop() {
  if (isOpen) return;

  // Don't open while cursor visible (menu/cef)
  try { if (mp.gui.cursor.visible) return; } catch (_) {}

  isOpen = true;

  hairCount = getHairCount();
  captureOriginal();

  const p = mp.players.local;
  selection = clamp((typeof p.getDrawableVariation === "function") ? p.getDrawableVariation(2) : 0, 0, Math.max(0, hairCount - 1));

  hairColor = clamp(original?.hairColor ?? 0, 0, 63);
  hairHighlight = clamp(original?.hairHighlight ?? hairColor, 0, 63);

  // If you see 1/1 or 1/2 here, your ped model is not freemode.
  if (hairCount <= 2) {
    notify("~r~Friseur: Dein Ped-Model hat kaum Frisuren. Nutze mp_m_freemode_01 / mp_f_freemode_01 für GTA Online Haircuts.");
  }

  // apply once so user instantly sees we're in preview mode
  applyPreview();
}

function closeShop(restore) {
  if (!isOpen) return;
  isOpen = false;

  if (restore) restoreOriginal();
  else original = null;
}

// --- Key binds (works even when GTA controls are disabled) -----------------------
function bindKey(key, downHandler) {
  try { mp.keys.bind(key, true, downHandler); } catch (_) {}
}

bindKey(KEY_E, () => {
  if (isOpen) return;
  if (activeShopIndex === -1) return;
  openShop();
});

bindKey(KEY_UP, () => {
  if (!isOpen) return;
  selection = clamp(selection - 1, 0, Math.max(0, hairCount - 1));
  applyPreview();
});

bindKey(KEY_DOWN, () => {
  if (!isOpen) return;
  selection = clamp(selection + 1, 0, Math.max(0, hairCount - 1));
  applyPreview();
});

bindKey(KEY_LEFT, () => {
  if (!isOpen) return;
  hairColor = clamp(hairColor - 1, 0, 63);
  applyPreview();
});

bindKey(KEY_RIGHT, () => {
  if (!isOpen) return;
  hairColor = clamp(hairColor + 1, 0, 63);
  applyPreview();
});

bindKey(KEY_ENTER, () => {
  if (!isOpen) return;
  tryRemoteSave();
  closeShop(false);
});

bindKey(KEY_BACK, () => {
  if (!isOpen) return;
  closeShop(true);
});

bindKey(KEY_ESC, () => {
  if (!isOpen) return;
  closeShop(true);
});

// --- While open: block attacks so users don't shoot inside menus -----------------
mp.events.add("render", () => {
  if (!isOpen) return;

  // block a few combat controls (doesn't break other resources like full disableAllControlActions)
  try {
    mp.game.controls.disableControlAction(0, 24, true); // attack
    mp.game.controls.disableControlAction(0, 25, true); // aim
    mp.game.controls.disableControlAction(0, 37, true); // weapon wheel
    mp.game.controls.disableControlAction(0, 257, true); // attack2
    mp.game.controls.disableControlAction(0, 140, true); // melee light
    mp.game.controls.disableControlAction(0, 141, true); // melee heavy
    mp.game.controls.disableControlAction(0, 142, true); // melee alternate
  } catch (_) {}
});
