
"use strict";

const NativeUI = require("nativeui");
const { Menu, UIMenuItem, Point } = NativeUI;

const cfg = {
    openDist: 4.5,
    blipSprite: 71,
    blipColor: 0,
    blipScale: 0.8,
    blipName: "Friseur",
    shopsExterior: [
        new mp.Vector3(-823.0681, -183.9033, 36.5531),
        new mp.Vector3(134.6110, -1707.9956, 28.2799),
        new mp.Vector3(1211.4066, -470.7033, 66.1978),
        new mp.Vector3(-1284.0791, -1115.4725, 6.9875),
        new mp.Vector3(1930.8264, 3728.2153, 30.8352),
        new mp.Vector3(-277.9121, 6230.4790, 30.6893),
        new mp.Vector3(-30.7516, -151.6879, 56.0652)
    ],
    shopsInterior: [
        new mp.Vector3(-815.20, -184.15, 37.57),
        new mp.Vector3(136.80, -1708.45, 29.29),
        new mp.Vector3(1212.80, -472.90, 67.20),
        new mp.Vector3(-1282.90, -1117.10, 7.00),
        new mp.Vector3(1933.05, 3729.75, 32.84),
        new mp.Vector3(-280.05, 6231.70, 32.70),
        new mp.Vector3(-34.20, -154.40, 57.08)
    ]
};

function notify(msg){ try { mp.game.graphics.notify(String(msg)); } catch(_){} }

function isFreemode() {
    const m = mp.players.local.model;
    return (m === mp.game.joaat("mp_m_freemode_01") || m === mp.game.joaat("mp_f_freemode_01"));
}

function dist(a,b){ const dx=a.x-b.x,dy=a.y-b.y,dz=a.z-b.z; return Math.sqrt(dx*dx+dy*dy+dz*dz); }
function isNearShop(){
    const pos=mp.players.local.position;
    const d=Number(cfg.openDist||4.5);
    for(const s of cfg.shopsInterior) if(dist(pos,s)<=d) return true;
    for(const s of cfg.shopsExterior) if(dist(pos,s)<=d) return true;
    return false;
}

// Native: GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS
function getDrawableVariationsCount(pedHandle, componentId) {
    try { return Number(mp.game.invoke("0x27561561732A7842", pedHandle, componentId)) || 0; }
    catch (_) { return 0; }
}
function waitForHair(cb, tries=0){
    const p=mp.players.local;
    const count=getDrawableVariationsCount(p.handle,2);
    if(count>2 || tries>=30) return cb(count);
    mp.setTimeout(()=>waitForHair(cb,tries+1),50);
}

function getMenuItems(m){ return (m && m.MenuItems) ? m.MenuItems : (m && m.Items) ? m.Items : []; }

// ---- preview/reset via local state
let original=null;
function captureOriginal(){
    const p=mp.players.local;
    const barber=p.getVariable("barber")||{};
    original={ hair:p.getDrawableVariation(2), hairColor:Number(barber.hairColor||0), hairHighlight:Number(barber.hairHighlight||barber.hairColor||0) };
}
function applyPreview(h,c,hl){
    const p=mp.players.local;
    try{ p.setComponentVariation(2,h,0,2);}catch(_){}
    try{ p.setHairColor(c,hl);}catch(_){}
}
function resetPreview(){
    if(!original) return;
    applyPreview(original.hair, original.hairColor, original.hairHighlight);
    original=null;
}

// ---- menu
let menu=null;
let isOpen=false;

let hairCount=0;
let hair=0;
let hairColor=0;
let hairHighlight=0;

let hairItemsCount=0;
let idxColor=-1, idxHighlight=-1, idxBuy=-1, idxCancel=-1;
let lastSel=-1;

function buildMenu(){
    if(menu) return;
    menu=new Menu(cfg.blipName||"Friseur","", new Point(50,50));
    menu.Visible=false;

    menu.MenuClose.on(()=>{ if(!isOpen) return; internalClose(false); });
}

function clearItems(){
    if(!menu) return;
    const items=getMenuItems(menu);
    if(typeof menu.RemoveItemAt==="function" && items && items.length){
        for(let i=items.length-1;i>=0;i--){ try{ menu.RemoveItemAt(i);}catch(_){ } }
    } else if(items) {
        items.length=0;
    }
    hairItemsCount=0;
    idxColor=idxHighlight=idxBuy=idxCancel=-1;
    lastSel=-1;
}

function addHairItems(count){
    for(let i=0;i<count;i++) menu.AddItem(new UIMenuItem(`Frisur #${i}`,""));
    hairItemsCount=count;
}

function addActionItems(){
    menu.AddItem(new UIMenuItem("Farbe","Links/Rechts ändern"));
    idxColor=getMenuItems(menu).length-1;

    menu.AddItem(new UIMenuItem("Highlight","Links/Rechts ändern"));
    idxHighlight=getMenuItems(menu).length-1;

    menu.AddItem(new UIMenuItem("Kaufen / Speichern",""));
    idxBuy=getMenuItems(menu).length-1;

    menu.AddItem(new UIMenuItem("Abbrechen",""));
    idxCancel=getMenuItems(menu).length-1;
}

function updateLabels(){
    const items=getMenuItems(menu);
    if(idxColor>=0 && items[idxColor]) items[idxColor].RightLabel=String(hairColor);
    if(idxHighlight>=0 && items[idxHighlight]) items[idxHighlight].RightLabel=String(hairHighlight);
}

function sendSave(){
    const payload = { type:"gta", hair, hairColor, hairHighlight };

    // IMPORTANT: server in your ZIP expects payload as JSON (1 argument)
    try { mp.events.callRemote("hairshop:buy", JSON.stringify(payload)); } catch (_) {}
    // keep fallbacks
    try { mp.events.callRemote("hairshop:save", JSON.stringify(payload)); } catch (_) {}
    try { mp.events.callRemote("barber:save", JSON.stringify(payload)); } catch (_) {}
    try { mp.events.callRemote("appearance:barberSave", JSON.stringify(payload)); } catch (_) {}
}

function internalClose(save){
    if(!isOpen) return;

    if(save){
        sendSave();
        original=null;
    } else {
        resetPreview();
    }

    isOpen=false;
    try{ mp.players.local.freezePosition(false);}catch(_){}
    try{ mp.gui.cursor.visible=false;}catch(_){}
    if(menu) menu.Visible=false;
}

function open(){
    if(isOpen) return;
    if(!isNearShop()) return;

    if(!isFreemode()){
        notify("~r~Friseur: Nur Freemode-Charaktere.");
        return;
    }

    buildMenu();
    clearItems();

    isOpen=true;
    mp.players.local.freezePosition(true);
    mp.gui.cursor.visible=false;

    captureOriginal();

    const p=mp.players.local;
    hair=p.getDrawableVariation(2);
    hairColor=original?.hairColor ?? 0;
    hairHighlight=original?.hairHighlight ?? hairColor;

    waitForHair((count)=>{
        hairCount=Math.max(count,1);
        if(hair>=hairCount) hair=0;

        addHairItems(hairCount);
        addActionItems();
        updateLabels();

        try{ menu.CurrentSelection=Math.min(Math.max(hair,0), hairItemsCount-1);}catch(_){}

        applyPreview(hair,hairColor,hairHighlight);

        menu.Visible=true;
        try{ menu.RefreshIndex();}catch(_){}
    });
}

// open with E (raw keybind)
mp.keys.bind(0x45,true,()=>{ if(!isOpen) open(); });

function accept(){ return mp.game.controls.isControlJustPressed(0,176) || mp.game.controls.isControlJustPressed(0,201); }
function back(){ return mp.game.controls.isControlJustPressed(0,177) || mp.game.controls.isControlJustPressed(0,202); }
function left(){ return mp.game.controls.isControlJustPressed(0,174); }
function right(){ return mp.game.controls.isControlJustPressed(0,175); }

mp.events.add("render", ()=>{
    if(!isOpen || !menu || !menu.Visible) return;

    try{ menu.ProcessControls(); }catch(_){}
    try{ menu.ProcessMouse(); }catch(_){}

    const sel=menu.CurrentSelection;

    if(sel!==lastSel){
        lastSel=sel;
        if(sel>=0 && sel<hairItemsCount){
            hair=sel;
            applyPreview(hair,hairColor,hairHighlight);
        }
    }

    if(sel===idxColor){
        if(left()){ hairColor=Math.max(0,hairColor-1); updateLabels(); applyPreview(hair,hairColor,hairHighlight); }
        if(right()){ hairColor=Math.min(63,hairColor+1); updateLabels(); applyPreview(hair,hairColor,hairHighlight); }
    } else if(sel===idxHighlight){
        if(left()){ hairHighlight=Math.max(0,hairHighlight-1); updateLabels(); applyPreview(hair,hairColor,hairHighlight); }
        if(right()){ hairHighlight=Math.min(63,hairHighlight+1); updateLabels(); applyPreview(hair,hairColor,hairHighlight); }
    }

    if(accept()){
        if(sel===idxBuy) return internalClose(true);
        if(sel===idxCancel) return internalClose(false);
    }
    if(back()) return internalClose(false);
});

// receive server notify
mp.events.add("hairshop:notify", (msg) => notify(msg));

// debug /hair
mp.events.add("playerCommand", (cmd)=>{
    const c=String(cmd||"").trim().toLowerCase();
    if(c==="hair"){
        if(!isOpen) open();
        else internalClose(false);
    }
});

// blips
for(const p of cfg.shopsExterior){
    try{
        const blip=mp.game.ui.addBlipForCoord(p.x,p.y,p.z);
        mp.game.ui.setBlipSprite(blip, cfg.blipSprite);
        mp.game.ui.setBlipColour(blip, cfg.blipColor);
        mp.game.ui.setBlipScale(blip, cfg.blipScale);
        mp.game.ui.setBlipAsShortRange(blip,true);
        mp.game.ui.beginTextCommandSetBlipName("STRING");
        mp.game.ui.addTextComponentSubstringPlayerName(cfg.blipName);
        mp.game.ui.endTextCommandSetBlipName(blip);
    }catch(_){}
}
