// client_packages/hairshop/preview.js
let original = null;
let customObj = null;

function getSavedBarberFallback(){
    // server usually syncs variable "barber" (see appearance.service.js)
    try {
        const v = mp.players.local.getVariable("barber");
        if (v && typeof v === "object") return v;
    } catch (_) {}
    return null;
}

function ensureOriginal(){
    if (original) return;

    const p = mp.players.local;
    const saved = getSavedBarberFallback();

    original = {
        drawable: (typeof p.getDrawableVariation === "function") ? p.getDrawableVariation(2) : 0,
        texture: (typeof p.getTextureVariation === "function") ? p.getTextureVariation(2) : 0,
        hairColor: Number(saved?.hairColor ?? 0),
        hairHighlight: Number(saved?.hairHighlight ?? (saved?.hairColor ?? 0)),
        hairType: String(saved?.hairType ?? "gta"),
        custom: saved?.custom ?? null
    };
}

function destroyCustom(){
    if (!customObj) return;
    try { customObj.destroy(); } catch (_) {}
    customObj = null;
}

mp.events.add("hairshop:previewGTA", (hairId, color, highlight) => {
    ensureOriginal();
    const p = mp.players.local;

    const h = Number(hairId) || 0;
    const c = Number(color) || 0;
    const hl = (highlight === undefined || highlight === null) ? c : (Number(highlight) || c);

    try { p.setComponentVariation(2, h, 0, 2); } catch (_) {}
    try { p.setHairColor(c, hl); } catch (_) {}

    // remove any custom object during GTA preview
    destroyCustom();
});

mp.events.add("hairshop:previewCustom", (model, collection, color, highlight) => {
    ensureOriginal();
    const p = mp.players.local;

    destroyCustom();

    const c = Number(color) || 0;
    const hl = (highlight === undefined || highlight === null) ? c : (Number(highlight) || c);
    try { p.setHairColor(c, hl); } catch (_) {}

    // keep current component hair as-is; custom will be attached
    const mName = String(model || "");
    if (!mName.length) return;

    const hash = mp.game.joaat(mName);
    mp.game.streaming.requestModel(hash);

    customObj = mp.objects.new(hash, p.position, { dimension: p.dimension });

    // attach to head bone (31086)
    try {
        customObj.attachTo(p.handle, 31086, 0, 0, 0, 0, 0, 0, false, false, false, false, 2, true);
    } catch (_) {}
});

mp.events.add("hairshop:reset", () => {
    const p = mp.players.local;
    if (!original) {
        destroyCustom();
        return;
    }

    destroyCustom();

    // restore hair component + color from saved barber (or defaults)
    try { p.setComponentVariation(2, original.drawable, original.texture, 2); } catch (_) {}
    try { p.setHairColor(original.hairColor, original.hairHighlight); } catch (_) {}

    // if original was custom hair, re-apply it
    if (original.hairType === "custom" && original.custom && original.custom.model){
        const mName = String(original.custom.model);
        const hash = mp.game.joaat(mName);
        mp.game.streaming.requestModel(hash);

        customObj = mp.objects.new(hash, p.position, { dimension: p.dimension });
        try {
            customObj.attachTo(p.handle, 31086, 0, 0, 0, 0, 0, 0, false, false, false, false, 2, true);
        } catch (_) {}
    }

    original = null;
});
