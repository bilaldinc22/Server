// client_packages/hairshop/camera.js
// Ultra-kompatible Head-Cam ohne mp.game.invoke bone/offset natives.
// Nutzt nur Player-Position + Heading (Mathe) -> stabil in allen Builds.

const HairshopCam = {
    cam: null,
    wasFrozen: false,

    _getHeadingRad(p) {
        let h = 0.0;
        try {
            if (typeof p.getHeading === "function") h = p.getHeading();
        } catch (_) {}
        // Heading in Grad -> Rad
        return (h * Math.PI) / 180.0;
    },

    startHeadCam() {
        const p = mp.players.local;
        this.stopHeadCam();

        try {
            this.wasFrozen = (typeof p.isPositionFrozen === "function") ? p.isPositionFrozen() : false;
        } catch (_) {
            this.wasFrozen = false;
        }
        try { p.freezePosition(true); } catch (_) {}

        // Forward-Vektor aus Heading (GTA: sin/cos)
        const rad = this._getHeadingRad(p);
        const fx = -Math.sin(rad);
        const fy =  Math.cos(rad);

        // Kamera vor dem Gesicht + leicht höher
        const camPos = new mp.Vector3(
            p.position.x + fx * 0.85,
            p.position.y + fy * 0.85,
            p.position.z + 0.65
        );

        // Zielpunkt: Kopf-Höhe (leicht nach oben)
        const target = new mp.Vector3(
            p.position.x,
            p.position.y,
            p.position.z + 0.70
        );

        this.cam = mp.cameras.new("hairshop_head", camPos, new mp.Vector3(0, 0, 0), 45);
        this.cam.pointAtCoord(target.x, target.y, target.z);
        this.cam.setActive(true);

        mp.game.cam.renderScriptCams(true, true, 250, true, false);
    },

    stopHeadCam() {
        const p = mp.players.local;

        if (this.cam) {
            try { this.cam.setActive(false); } catch (_) {}
            try { this.cam.destroy(); } catch (_) {}
            this.cam = null;
            mp.game.cam.renderScriptCams(false, true, 250, true, false);
        }

        try {
            if (!this.wasFrozen) p.freezePosition(false);
        } catch (_) {}
        this.wasFrozen = false;
    }
};

globalThis.HairshopCam = HairshopCam;
