// Client defaults (Server sendet echte Liste via hairshop:showUI)
globalThis.HAIRSHOP_STYLES = globalThis.HAIRSHOP_STYLES || {
  male: { gta: [], custom: [] },
  female: { gta: [], custom: [] }
};
