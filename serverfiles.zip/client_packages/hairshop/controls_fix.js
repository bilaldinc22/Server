// client_packages/hairshop/controls_fix.js
// NativeUI: stellt sicher, dass Links/Rechts/Enter/Back im Menu funktionieren,
// auch wenn ein globaler Control-Blocker aktiv ist.

globalThis.HairshopControlsFix = {
    _bound: false,
    _menu: null,

    bind(menu) {
        this._menu = menu;
        if (this._bound) return;
        this._bound = true;

        mp.events.add("render", () => {
            const m = this._menu;
            if (!m || !m.Visible) return;

            // NativeUI input processing
            try { m.ProcessControls(); } catch (_) {}
            try { m.ProcessMouse(); } catch (_) {}

            // Viele Gamemodes blocken diese Controls global (Inventory/Login etc.)
            // 174 = LEFT, 175 = RIGHT, 176 = ENTER, 177 = BACKSPACE
            try {
                mp.game.controls.enableControlAction(0, 174, true);
                mp.game.controls.enableControlAction(0, 175, true);
                mp.game.controls.enableControlAction(0, 176, true);
                mp.game.controls.enableControlAction(0, 177, true);
            } catch (_) {}
        });
    }
};
