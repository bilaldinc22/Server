"use strict";

/**
 * Hairshop / Barbershop locations (GTA V / Online).
 * These coordinates are widely used in FiveM/RageMP resources and match the default barbershop exteriors.
 */
module.exports = {
  // Marker/interaction
  openKey: 0x45, // E
  openDist: 2.0,

  // Marker style
  markerType: 1,
  markerScale: 1.0,
  markerColor: [255, 0, 0, 150],

  // Map blip
  blipSprite: 71,     // Barber (scissors)
  blipColor: 0,
  blipScale: 0.8,
  blipName: "Friseur",

  // All shops
  shops: [
    new mp.Vector3(-823.068115, -183.903290, 36.553101), // Rockford Hills
    new mp.Vector3(134.610992, -1707.995605, 28.279907), // Davis / Strawberry
    new mp.Vector3(1211.406616, -470.703308, 66.197754), // Mirror Park
    new mp.Vector3(-1284.079102, -1115.472534, 6.987549), // Vespucci
    new mp.Vector3(1930.826416, 3728.215332, 30.835205), // Sandy Shores
    new mp.Vector3(-277.912079, 6230.479004, 30.689331), // Paleto Bay
    new mp.Vector3(-30.751646, -151.687912, 56.065186)   // Hawick
  ]
};
