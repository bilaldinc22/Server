
// client_packages/hairshop/config.js
module.exports = {
    openKey: 0x45,        // E
    openDist: 4.5,

    // Blip settings
    blipSprite: 71,
    blipColor: 0,
    blipScale: 0.8,
    blipName: "Friseur",

    // Exterior blips (default barbershops)
    shopsExterior: [
        new mp.Vector3(-823.0681, -183.9033, 36.5531),
        new mp.Vector3(134.6110, -1707.9956, 28.2799),
        new mp.Vector3(1211.4066, -470.7033, 66.1978),
        new mp.Vector3(-1284.0791, -1115.4725, 6.9875),
        new mp.Vector3(1930.8264, 3728.2153, 30.8352),
        new mp.Vector3(-277.9121, 6230.4790, 30.6893),
        new mp.Vector3(-30.7516, -151.6879, 56.0652)
    ],

    // Interior interaction points (near chairs/mirrors)
    shopsInterior: [
        new mp.Vector3(-815.20, -184.15, 37.57),
        new mp.Vector3(136.80, -1708.45, 29.29),
        new mp.Vector3(1212.80, -472.90, 67.20),
        new mp.Vector3(-1282.90, -1117.10, 7.00),
        new mp.Vector3(1933.05, 3729.75, 32.84),
        new mp.Vector3(-280.05, 6231.70, 32.70),
        new mp.Vector3(-34.20, -154.40, 57.08)
    ]
};
