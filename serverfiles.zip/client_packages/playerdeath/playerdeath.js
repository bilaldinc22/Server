// Client-side injured/knockdown effects
// - Freeze + injured anim
// - Disable controls
// - Simple HUD with bleedout timer
// - Keys:
//     G = call EMS
//     E = respawn (only after timer ends)

const localPlayer = mp.players.local;

let injured = false;
let injuredStartedAt = 0;
let bleedoutMs = 120000;

// Key codes
const KEY_E = 0x45; // E
const KEY_G = 0x47; // G

function msLeft() {
  if (!injured) return 0;
  const elapsed = Date.now() - injuredStartedAt;
  return Math.max(0, bleedoutMs - elapsed);
}

function setInjured(state, newBleedoutMs) {
  injured = !!state;

  if (typeof newBleedoutMs === "number" && isFinite(newBleedoutMs)) {
    bleedoutMs = Math.max(0, Math.floor(newBleedoutMs));
  }

  if (injured) {
    injuredStartedAt = Date.now();
    mp.game.gameplay.setFadeOutAfterDeath(false);

    // Ensure no ragdoll / tasks
    localPlayer.clearTasksImmediately();
    localPlayer.freezePosition(true);

    // Play anim locally (more consistent than server-side playAnimation)
    const dict = "combat@damage@injured_pistol@to_writhe";
    const name = "variation_b";
    mp.game.streaming.requestAnimDict(dict);
    const animInterval = setInterval(() => {
      if (!injured) {
        clearInterval(animInterval);
        return;
      }
      if (mp.game.streaming.hasAnimDictLoaded(dict)) {
        localPlayer.taskPlayAnim(dict, name, 8.0, 8.0, -1, 49, 0, false, false, false);
        clearInterval(animInterval);
      }
    }, 100);
  } else {
    localPlayer.clearTasksImmediately();
    localPlayer.freezePosition(false);
  }
}

mp.events.add("CLIENT::INJURED", (serverBleedoutMs) => {
  setInjured(true, serverBleedoutMs);
});

mp.events.add("CLIENT::NOT:INJURED", () => {
  setInjured(false);
});

// If server thinks we are injured but we spawned due to other scripts, re-apply state lightly.
mp.events.add("CLIENT::INJURED_SYNC", () => {
  if (!injured) return;
  localPlayer.freezePosition(true);
});

// Controls + key handling
mp.events.add("render", () => {
  if (!injured) return;

  // Disable most controls while injured
  mp.game.controls.disableAllControlActions(0);
  mp.game.controls.disableAllControlActions(1);
  mp.game.controls.disableAllControlActions(2);

  // Allow chat (T) and ESC (pause)
  mp.game.controls.enableControlAction(0, 245, true); // chat
  mp.game.controls.enableControlAction(0, 200, true); // pause

  const left = msLeft();
  const seconds = Math.ceil(left / 1000);
  const canRespawn = left <= 0;

  const text = canRespawn
    ? "INJURED\nPress ~g~E~w~ to respawn at hospital\nPress ~b~G~w~ to call EMS"
    : `INJURED\nBleedout: ~r~${seconds}s~w~\nPress ~b~G~w~ to call EMS`;

  mp.game.graphics.drawText(text, [0.5, 0.5], {
    font: 4,
    color: [255, 255, 255, 200],
    scale: [0.6, 0.6],
    outline: true,
    centre: true,
  });
});

mp.keys.bind(KEY_G, false, () => {
  if (!injured) return;
  mp.events.callRemote("SERVER::DEATH:CALL_EMS");
});

mp.keys.bind(KEY_E, false, () => {
  if (!injured) return;
  if (msLeft() > 0) return;
  mp.events.callRemote("SERVER::DEATH:REQUEST_RESPAWN");
});
