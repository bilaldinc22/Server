const NativeUI = require("nativeui");
const { Menu, UIMenuItem, Point } = NativeUI;

const SHOP_POS = new mp.Vector3(22.0, -1107.0, 29.8);
const OPEN_KEY = 0x45; // E
const OPEN_RANGE = 2.0;

// Blip + Marker
mp.blips.new(110, SHOP_POS, { name: "Shop", color: 1, scale: 0.85, shortRange: true });
mp.markers.new(1, SHOP_POS, 1.0, { color: [255, 0, 0, 150], visible: true });

function getMenuPointRight() {
  try {
    const res = mp.game.graphics.getScreenActiveResolution(0, 0);
    const w = Array.isArray(res) ? res[0] : (res && res.x ? res.x : 0);
    if (!w) return new Point(1100, 50);
    return new Point(Math.max(50, Math.floor(w - 420)), 50);
  } catch (e) { return new Point(1100, 50); }
}
const P = getMenuPointRight();

const mainMenu   = new Menu("Shop", "Waffen · Munition · Items", P);
const pistolMenu = new Menu("Pistolen", "Verfügbare Waffen", P);
const ammoMenu   = new Menu("Munition", "Nachladen", P);
const itemMenu   = new Menu("Items", "Medikit · Schutzweste", P);

mainMenu.Visible = pistolMenu.Visible = ammoMenu.Visible = itemMenu.Visible = false;
let activeMenu = null;
let lastToggleTick = 0;

function now(){ return Date.now(); }
function anyVisible(){ return !!activeMenu && activeMenu.Visible; }

function openMenu(m){
  mainMenu.Visible = pistolMenu.Visible = ammoMenu.Visible = itemMenu.Visible = false;
  activeMenu = m; m.Visible = true;
  mp.gui.cursor.visible = false;
  if (typeof m.RefreshIndex === "function") m.RefreshIndex();
  if (typeof m.ResetIndex === "function") m.ResetIndex();
}
function closeAll(){
  mainMenu.Visible = pistolMenu.Visible = ammoMenu.Visible = itemMenu.Visible = false;
  activeMenu = null; mp.gui.cursor.visible = false;
}

mainMenu.AddItem(new UIMenuItem("Pistolen", "Waffen kaufen"));
mainMenu.AddItem(new UIMenuItem("Munition", "Munition kaufen"));
mainMenu.AddItem(new UIMenuItem("Items", "Medikit / Schutzweste kaufen"));

pistolMenu.AddItem(new UIMenuItem("← Zurück", "Hauptmenü"));
ammoMenu.AddItem(new UIMenuItem("← Zurück", "Hauptmenü"));
itemMenu.AddItem(new UIMenuItem("← Zurück", "Hauptmenü"));

const pistols = [
  { label: "Pistol", weaponName: "weapon_pistol", price: 2500 },
  { label: "Combat Pistol", weaponName: "weapon_combatpistol", price: 3500 }
];
const ammoPacks = [
  { label: "Pistolen Munition (50)", amount: 50, price: 500 },
  { label: "Pistolen Munition (100)", amount: 100, price: 900 }
];
const items = [
  { label: "Medikit (+50 HP)", event: "weaponshop:buyMedikit", amount: 1, price: 300 },
  { label: "Schutzweste (+100 Armor)", event: "weaponshop:buyArmor", amount: 1, price: 600 }
];

pistols.forEach(w => pistolMenu.AddItem(new UIMenuItem(w.label, `Preis: ${w.price}$`)));
ammoPacks.forEach(a => ammoMenu.AddItem(new UIMenuItem(a.label, `Preis: ${a.price}$`)));
items.forEach(i => itemMenu.AddItem(new UIMenuItem(i.label, `Preis: ${i.price}$`)));

function getMenuIndex(menu){
  if (!menu) return 0;
  const keys=["CurrentSelection","currentSelection","SelectedIndex","selectedIndex","_Index","_index","Index","index"];
  for (let i=0;i<keys.length;i++){ const k=keys[i]; if (typeof menu[k]==="number") return menu[k]; }
  return 0;
}
function accept(){ return mp.game.controls.isControlJustPressed(0,176) || mp.game.controls.isControlJustPressed(0,201); }
function back(){ return mp.game.controls.isControlJustPressed(0,177) || mp.game.controls.isControlJustPressed(0,202); }

function handleAccept(){
  const idx = getMenuIndex(activeMenu);

  if (activeMenu === mainMenu){
    if (idx===0) return openMenu(pistolMenu);
    if (idx===1) return openMenu(ammoMenu);
    if (idx===2) return openMenu(itemMenu);
    return;
  }

  if (activeMenu === pistolMenu){
    if (idx===0) return openMenu(mainMenu);
    const data = pistols[idx-1]; if (!data) return;
    mp.events.callRemote("weaponshop:buyWeapon", data.weaponName, data.price);
    return;
  }

  if (activeMenu === ammoMenu){
    if (idx===0) return openMenu(mainMenu);
    const data = ammoPacks[idx-1]; if (!data) return;
    mp.events.callRemote("weaponshop:buyAmmo", data.amount, data.price);
    return;
  }

  if (activeMenu === itemMenu){
    if (idx===0) return openMenu(mainMenu);
    const data = items[idx-1]; if (!data) return;
    mp.events.callRemote(data.event, data.amount, data.price);
    return;
  }
}

function handleBack(){
  if (activeMenu === mainMenu) return closeAll();
  return openMenu(mainMenu);
}

function tick(m){
  if (!m || !m.Visible) return;
  if (typeof m.ProcessControl === "function") m.ProcessControl();
  if (typeof m.Draw === "function") m.Draw();
}
function disableGameplayControls(){
  const toDisable=[24,25,68,69,70,91,92,140,141,142,14,15,16,17,37,44,45];
  for (let i=0;i<toDisable.length;i++) mp.game.controls.disableControlAction(0,toDisable[i],true);
  const allow=[172,173,174,175,176,177,188,187,189,190,201,202,199,200];
  for (let i=0;i<allow.length;i++) mp.game.controls.enableControlAction(0,allow[i],true);
}

mp.events.add("render", ()=>{
  if (anyVisible()){
    disableGameplayControls();
    if (accept()) handleAccept();
    else if (back()) handleBack();
  }
  tick(activeMenu);
});

mp.keys.bind(OPEN_KEY, true, ()=>{
  const t=now(); if (t-lastToggleTick<250) return; lastToggleTick=t;
  const p=mp.players.local.position;
  const dx=p.x-SHOP_POS.x, dy=p.y-SHOP_POS.y, dz=p.z-SHOP_POS.z;
  if ((dx*dx+dy*dy+dz*dz)>(OPEN_RANGE*OPEN_RANGE)) return;
  if (!anyVisible()) openMenu(mainMenu); else closeAll();
});
