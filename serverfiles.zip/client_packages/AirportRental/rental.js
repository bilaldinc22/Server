var airport_rental_browser;
var visible = false;


mp.events.add('CLIENT::OPEN:AIRPORT:RENTAL', () => {
    if(visible == false) {
        airport_rental_browser = mp.browsers.new(`package://ui/ui-rental/index.html`);
        mp.gui.cursor.show(true, true);
        visible = true;
    }
});

mp.events.add('CLIENT::CLOSE:AIRPORT:RENTAL', () => {
    if(visible == true) {
        airport_rental_browser.destroy();
        mp.gui.cursor.show(false, false);
        visible = false;
    }
});


mp.events.add('CLIENT::SPAWN:AIRPORT:RENTAL', (vehicleName) => {
    mp.events.callRemote('SERVER::SPAWN:AIRPORT:RENTAL', vehicleName);
    mp.events.call('CLIENT::CLOSE:AIRPORT:RENTAL');
});