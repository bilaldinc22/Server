
var hud;
let active = false;


function dissableDefault() {
    mp.game.ui.hideHudComponentThisFrame(7); // HUD_AREA_NAME
    mp.game.ui.hideHudComponentThisFrame(9); // HUD_STREET_NAME
    mp.game.ui.hideHudComponentThisFrame(6); // HUD_VEHICLE_NAME
    mp.game.ui.hideHudComponentThisFrame(2); // HUD_WEAPON_ICON
    mp.game.ui.hideHudComponentThisFrame(3); // HUD_CASH
    mp.game.ui.hideHudComponentThisFrame(4); // HUD_MP_CASH
    mp.game.ui.hideHudComponentThisFrame(14); // CROSSHAIR
    mp.game.ui.hideHudComponentThisFrame(19); // HUD_WEAPON_WHEEL
    mp.game.ui.hideHudComponentThisFrame(20); // HUD_WEAPON_WHEEL_STATS
 
    mp.game.invoke('0x9E4CFFF989258472');
    mp.game.invoke('0xF4F2C0D4EE209E20');
 
    // mp.game.controls.disableControlAction(1, 263, true);
    mp.game.controls.disableControlAction(1, 140, true);
    // mp.game.controls.disableControlAction(1, 141, true); // Q Heavy Attack mele
 
 
    // disable tab weapon wheel
    mp.game.controls.disableControlAction(32, 37, true); 
}

function getHeading () { 
    let H = Player.getHeading(), Heading;
    switch (true) {
       case (H < 30): Heading = 'N'; break;
       case (H < 90): Heading = 'NW'; break;
       case (H < 135): Heading = 'W'; break;
       case (H < 180): Heading = 'SW'; break;
       case (H < 225): Heading = 'S'; break;
       case (H < 270): Heading = 'SE'; break;
       case (H < 315): Heading = 'E'; break;
       case (H < 360): Heading = 'NE'; break;
       default: Heading = 'N'; break;
    }
    return Heading;
 }
 
 
 function LocationUpdate () { 
    const path = mp.game.pathfind.getStreetNameAtCoord(Player.position.x, Player.position.y, Player.position.z, 0, 0),
       Zone = mp.game.gxt.get(mp.game.zone.getNameOfZone(Player.position.x, Player.position.y, Player.position.z)),
       Street = mp.game.ui.getStreetNameFromHashKey(path.streetName),
       Heading = getHeading();
 
    browser.execute('hud.location.street = \"' + Street + '\";');
    browser.execute('hud.location.zone = \"' + Zone + '\";');
    browser.execute('hud.location.heading = \"' + Heading + '\";');
 }