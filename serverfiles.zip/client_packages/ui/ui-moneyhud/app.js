(() => {
  const badge = document.getElementById("badge");
  const el = document.getElementById("cash");

  function fmt(n) {
    n = Math.max(0, Math.floor(Number(n) || 0));
    // gleiche Optik wie bei dir mit Punkten
    return n.toLocaleString("de-DE") + "$";
  }

  function pulse() {
    badge.classList.remove("pulse");
    void badge.offsetWidth;
    badge.classList.add("pulse");
  }

  window.MoneyHUD = {
    setCash(cash) {
      el.textContent = fmt(cash);
      pulse();
    }
  };
})();
