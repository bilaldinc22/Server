/**
 * RageMP 1.1 weapon persistence fix
 *
 * Problem this fixes:
 * - Weapons are saved to rp_player_weapons (owner_id), but not loaded, because many gamemodes use CHARACTER id
 *   while the old persistence code loads by ACCOUNT id.
 * - Duplicates are created because inserts are used instead of upsert (owner_id + weapon_hash should be unique).
 *
 * What this module does:
 * - Determines the correct owner id (character id preferred, fallback to account id)
 * - Loads weapons for that owner and gives them to the player
 * - Saves current weapons using upsert to avoid duplicates
 *
 * Requirements:
 * - Sequelize models: PlayerWeapon mapped to rp_player_weapons with fields:
 *   owner_id, weapon_hash, ammo, is_equipped
 */

function getOwnerId(player) {
  // Prefer character id (common in RP gamemodes)
  if (player.characterId) return player.characterId;
  if (player.character && player.character.id) return player.character.id;

  // Fallback: account id
  if (player.accountId) return player.accountId;

  return 0;
}

async function loadWeaponsForPlayer(player, PlayerWeaponModel) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return;

  const rows = await PlayerWeaponModel.findAll({ where: { owner_id: ownerId } });

  // give weapons; if your gamemode needs equip logic, keep is_equipped and switch after giveWeapon
  for (const w of rows) {
    const hash = Number(w.weapon_hash) >>> 0;
    const ammo = Math.max(0, Number(w.ammo) || 0);

    try {
      player.giveWeapon(hash, ammo);
    } catch (e) {
      // ignore invalid rows
    }
  }
}

async function saveWeaponsForPlayer(player, PlayerWeaponModel) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return;

  // Collect weapons from your authoritative state if present
  // Prefer your gamemode state:
  const stateWeapons = (player._rpState && player._rpState.weapons) ? player._rpState.weapons : null;

  // Fallback: if state is missing, do nothing (prevents wiping DB)
  if (!stateWeapons) return;

  // Upsert each weapon -> prevents duplicates
  for (const w of stateWeapons) {
    const weaponHash = Number(w.weapon_hash ?? w.weaponHash ?? w.hash) >>> 0;
    const ammo = Math.max(0, Number(w.ammo) || 0);
    const isEquipped = (w.is_equipped ?? w.isEquipped ?? w.equipped) ? 1 : 0;

    if (!weaponHash) continue;

    // Sequelize upsert (works on MySQL/MariaDB with unique index)
    await PlayerWeaponModel.upsert({
      owner_id: ownerId,
      weapon_hash: weaponHash,
      ammo: ammo,
      is_equipped: isEquipped
    });
  }
}

module.exports = {
  getOwnerId,
  loadWeaponsForPlayer,
  saveWeaponsForPlayer
};
