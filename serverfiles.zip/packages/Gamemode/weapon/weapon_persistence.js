'use strict';

const PlayerWeapon = require("./models/PlayerWeapon");

function getOwnerId(player) {
    if (player.characterId) return player.characterId;
    if (player.character && player.character.character_id) return player.character.character_id;
    if (player.character && player.character.id) return player.character.id;
    try {
        const vars = ["characterId","character_id","charId","char_id"];
        for (const v of vars) {
            const val = player.getVariable && player.getVariable(v);
            if (val) return val;
        }
    } catch (_) {}
    return 0;
}

function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

async function waitOwnerId(player, timeout=8000){
    const start=Date.now();
    while(Date.now()-start<timeout){
        const id=getOwnerId(player);
        if(id) return id;
        await sleep(100);
    }
    return 0;
}

async function loadWeapons(player){
    const ownerId = await waitOwnerId(player);
    if(!ownerId) return;

    const rows = await PlayerWeapon.findAll({ where: { owner_id: ownerId }});
    for(const r of rows){
        try { player.giveWeapon(Number(r.weapon_hash), Number(r.ammo)||0); } catch(_) {}
    }
}

async function giveWeapon(player, weaponNameOrHash, ammo){
    const ownerId = await waitOwnerId(player);
    if(!ownerId) throw new Error("ownerId missing");

    let weaponHash = 0;
    if(typeof weaponNameOrHash === "number") weaponHash = weaponNameOrHash >>> 0;
    else weaponHash = mp.joaat(String(weaponNameOrHash).toLowerCase());

    const a = Math.max(0, parseInt(ammo,10)||0);
    const where = { owner_id: ownerId, weapon_hash: String(weaponHash) };
    const row = await PlayerWeapon.findOne({ where });

    if(row) await row.update({ ammo: a, is_equipped: true });
    else await PlayerWeapon.create({ owner_id: ownerId, weapon_hash: String(weaponHash), ammo: a, is_equipped: true });

    player.giveWeapon(weaponHash, a);
}

async function addAmmo(player, addAmount){
    const ownerId = await waitOwnerId(player);
    if(!ownerId) throw new Error("ownerId missing");

    const weaponHash = Number(player.weapon)>>>0;
    if(!weaponHash) throw new Error("no weapon equipped");

    const inc = Math.max(0, parseInt(addAmount,10)||0);
    const where = { owner_id: ownerId, weapon_hash: String(weaponHash) };
    const row = await PlayerWeapon.findOne({ where });
    const next = (row ? Number(row.ammo) : 0) + inc;

    if(row) await row.update({ ammo: next });
    else await PlayerWeapon.create({ owner_id: ownerId, weapon_hash: String(weaponHash), ammo: next, is_equipped: true });

    try { player.removeWeapon(weaponHash); } catch(_) {}
    player.giveWeapon(weaponHash, next);
}

module.exports = { loadWeapons, giveWeapon, addAmmo };
