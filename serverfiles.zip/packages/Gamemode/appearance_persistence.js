const PlayerAppearance = require("./models/player_appearance.model");

function getOwnerId(player) {
  if (player?.character?.id) return player.character.id;
  if (player?.characterId) return player.characterId;
  return 0;
}

function safeParseJson(str, fallback) {
  try {
    const v = JSON.parse(str);
    return v ?? fallback;
  } catch (e) {
    return fallback;
  }
}

function syncCash(player, character) {
  try {
    if (global.hudMoney && typeof global.hudMoney.syncCash === "function") {
      global.hudMoney.syncCash(player, character);
      return;
    }
  } catch (_) {}
  // fallback
  const cash = Math.max(0, Math.floor(Number(character?.pocket_money) || 0));
  player.setVariable("pocket_money", cash);
  try { player.call("CLIENT::HUD:CASH", [cash]); } catch (_) {}
}

async function ensureRow(ownerId) {
  const [row] = await PlayerAppearance.findOrCreate({
    where: { owner_id: ownerId },
    defaults: { owner_id: ownerId, tattoos: "[]", barber: "{}" }
  });
  return row;
}

async function loadAppearance(player) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return { tattoos: [], barber: null };

  const row = await ensureRow(ownerId);
  const tattoos = safeParseJson(row.tattoos, []);
  const barber = safeParseJson(row.barber, null);

  // sync to clients
  player.setVariable("tattoos", Array.isArray(tattoos) ? tattoos : []);
  if (barber && typeof barber === "object") player.setVariable("barber", barber);

  // also apply to self immediately (client handlers do the visuals)
  try { player.call("tattooshop:applySelf", [player.getVariable("tattoos")]); } catch (_) {}
  try { player.call("barbershop:applySelf", [player.getVariable("barber")]); } catch (_) {}

  return { tattoos: player.getVariable("tattoos"), barber: player.getVariable("barber") };
}

async function saveAppearance(player, patch) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return;

  const row = await ensureRow(ownerId);

  if (patch && Object.prototype.hasOwnProperty.call(patch, "tattoos")) {
    const tattoos = Array.isArray(patch.tattoos) ? patch.tattoos : [];
    row.tattoos = JSON.stringify(tattoos);
    player.setVariable("tattoos", tattoos);
  }
  if (patch && Object.prototype.hasOwnProperty.call(patch, "barber")) {
    const barber = (patch.barber && typeof patch.barber === "object") ? patch.barber : {};
    row.barber = JSON.stringify(barber);
    player.setVariable("barber", barber);
  }

  await row.save();

  // re-apply to self
  if (patch?.tattoos !== undefined) { try { player.call("tattooshop:applySelf", [player.getVariable("tattoos")]); } catch (_) {} }
  if (patch?.barber !== undefined) { try { player.call("barbershop:applySelf", [player.getVariable("barber")]); } catch (_) {} }
}

// Auto-load once character exists (no need to edit your core login flow)
async function tryAutoLoad(player, attemptsLeft = 60) {
  if (!player || !player.handle) return;
  if (getOwnerId(player)) {
    try { await loadAppearance(player); } catch(e) {}
    return;
  }
  if (attemptsLeft <= 0) return;
  setTimeout(() => tryAutoLoad(player, attemptsLeft - 1), 250);
}

mp.events.add("playerJoin", (player) => {
  // ensure vars exist for sync early
  player.setVariable("tattoos", []);
  player.setVariable("barber", null);
  tryAutoLoad(player);
});

// In case your gamemode emits playerReady after character load
mp.events.add("playerReady", (player) => {
  tryAutoLoad(player);
});

// Exports
module.exports = {
  getOwnerId,
  loadAppearance,
  saveAppearance,
  syncCash
};
