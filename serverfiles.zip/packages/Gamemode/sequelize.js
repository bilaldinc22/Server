const seq = require('sequelize');

const sequelize = new seq('zap851638-1', 'zap851638-1', '31GGkDsZMo3kL5Xw', {
    host: 'mysql-mariadb-22-104.zap-srv.com',
    dialect: 'mysql',
    logging: false
});

sequelize
    .authenticate()
    .then(() => {
        console.log(`Connection to Database Successfull`);
    }).catch(err => {
        console.log(`Connection to Database Failed ${err}`);
    });

global.sequelize = sequelize;
global.seq = seq;
