
module.exports = {
  WEAPON_PISTOL: { label: "Pistole", icon: "pistol.png" },
  WEAPON_HEAVYPISTOL: { label: "Heavy Pistole", icon: "heavy_pistol.png" },
  WEAPON_SMG: { label: "SMG", icon: "smg.png" },
  WEAPON_ASSAULTRIFLE: { label: "AK-47", icon: "ak47.png" },
  WEAPON_PUMPSHOTGUN: { label: "Pump Shotgun", icon: "shotgun.png" }
}
