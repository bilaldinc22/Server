const service = require("./appearance.service");

mp.events.add("playerReady", async (player) => {
  try {
    if (!player?.character?.id) return;
    await service.load(player);
  } catch (e) {
    console.log("[APPEAR] load error:", e?.message || e);
  }
});

module.exports = service;