const Appearance = require("./appearance.model");

function getOwnerId(player) {
  // bei dir ist es character.id
  const id = Number(player?.character?.id) || 0;
  if (!id) throw new Error("ownerId missing");
  return id;
}

function safeParse(str, fallback) {
  try { const v = JSON.parse(str); return v ?? fallback; } catch { return fallback; }
}

async function getRow(owner_id) {
  let row = await Appearance.findOne({ where: { owner_id } });
  if (!row) row = await Appearance.create({ owner_id, tattoos: "[]", barber: "{}" });
  return row;
}

async function loadToPlayer(player) {
  const owner_id = getOwnerId(player);
  const row = await getRow(owner_id);

  const tattoos = safeParse(row.tattoos, []);
  const barber = safeParse(row.barber, { hair: 0, hairColor: 0, hairHighlight: 0 });

  player.setVariable("tattoos", tattoos);
  player.setVariable("barber", barber);

  // setzt beim Join für den Spieler selbst (dein client apply muss existieren)
  player.call("appearance:applySelf", [tattoos, barber]);
}

async function saveTattoos(player, tattoos) {
  const owner_id = getOwnerId(player);
  const row = await getRow(owner_id);

  const val = Array.isArray(tattoos) ? tattoos : [];
  row.tattoos = JSON.stringify(val);
  await row.save();

  player.setVariable("tattoos", val);
  player.call("appearance:applySelf", [val, player.getVariable("barber") || {}]);
}

async function saveBarber(player, barber) {
  const owner_id = getOwnerId(player);
  const row = await getRow(owner_id);

  const val = (barber && typeof barber === "object") ? barber : { hair: 0, hairColor: 0, hairHighlight: 0 };
  row.barber = JSON.stringify(val);
  await row.save();

  player.setVariable("barber", val);
  player.call("appearance:applySelf", [player.getVariable("tattoos") || [], val]);
}

module.exports = { loadToPlayer, saveTattoos, saveBarber };