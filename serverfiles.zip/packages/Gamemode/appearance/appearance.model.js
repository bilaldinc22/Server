const sequelize = global.sequelize;
const seq = global.seq;

if (!sequelize || !seq) throw new Error("Sequelize globals missing (global.sequelize / global.seq)");

module.exports = sequelize.define("rp_player_appearance", {
  id: { type: seq.INTEGER, autoIncrement: true, primaryKey: true },
  owner_id: { type: seq.INTEGER, allowNull: false, unique: true },
  tattoos: { type: seq.TEXT("long"), allowNull: false, defaultValue: "[]" },
  barber: { type: seq.TEXT("long"), allowNull: false, defaultValue: "{}" }
}, {
  tableName: "rp_player_appearance",
  timestamps: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
  indexes: [{ unique: true, fields: ["owner_id"] }]
});