const Appearance = require("./appearance.model");
const service = require("./appearance.service");

// Tabelle automatisch erstellen (wie bei dir schon "Sequelize models synced")
Appearance.sync();

mp.events.add("playerReady", async (player) => {
  try {
    if (!player?.character?.id) return;
    await service.loadToPlayer(player);
  } catch (e) {
    console.log("[APPEAR] load error:", e?.message || e);
  }
});

module.exports = service;