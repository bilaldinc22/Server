// color defines
const darkred = "!{#B30000}";
const lightred = "!{#FF0000}";
const green = "!{#00B30E}";
const blue = "!{#0054B3}";
const orange = "!{#EA7F00}";
const yellow = "!{#FFF009}";
const pink = "!{#FF009B}";
const white = "!{#FFFFFF}";
const purple = "!{#A200FF}";
const skyblue = "!{#00FFFF}";
const gray = "!{#808080}";
const black = "!{#000000}";


global.darkred = darkred;
global.lightred = lightred;
global.green = green;
global.blue = blue;
global.orange = orange;
global.yellow = yellow;
global.pink = pink;
global.white = white;
global.purple = purple;
global.skyblue = skyblue;
global.gray = gray;
global.black = black;

