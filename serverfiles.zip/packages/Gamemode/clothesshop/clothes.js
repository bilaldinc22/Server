module.exports = [
    { shop: 'civilian', component: 11, drawable: 5, texture: 0 }
];
