'use strict';

/**
 * Clothes shop v2 (components/props) - server
 * - Charges character money: pocket_money -> bank_money
 * - Stores purchased pieces as inventory items (ItemTemplates per category)
 * - Does NOT trust client price; server uses PRICE_TABLE
 *
 * Requires inventory.service.js:
 * - addItemByTemplateName(player, templateName, amount, metaObj)
 */

const invService = require("../Inventory/inventory.service");

// Civilian filter: blocks high drawable IDs that are typically reserved for faction/uniform add-on packs.
// Must match clientside limits (edit both if you change).
const CIV_LIMITS = {
  default: 199,
  pants: 199,
  shoes: 199,
  top: 199,
  undershirt: 199,
  torso: 199,
  accessory: 199,
  mask: 199,
  glasses: 99,
  hat: 99,
  ears: 49,
  watch: 49,
  bracelet: 49,
  whitelist: {
    // top: [250, 251]
  }
};

function isCivilDrawable(catKey, drawable) {
  const lim = (CIV_LIMITS[catKey] ?? CIV_LIMITS.default);
  if (drawable <= lim) return true;
  const wl = (CIV_LIMITS.whitelist && CIV_LIMITS.whitelist[catKey]) ? CIV_LIMITS.whitelist[catKey] : null;
  return Array.isArray(wl) && wl.includes(drawable);
}


function getChar(player) {
  return player && player.character ? player.character : null;
}

async function chargeCharacter(player, amount) {
  const c = getChar(player);
  if (!c) return false;

  amount = Number(amount) || 0;
  if (amount <= 0) return true;

  let cash = Number(c.pocket_money || 0) || 0;
  let bank = Number(c.bank_money || 0) || 0;

  if (cash >= amount) {
    c.pocket_money = cash - amount;
    await c.save();
    return true;
  }

  const rest = amount - cash;
  if (bank >= rest) {
    c.pocket_money = 0;
    c.bank_money = bank - rest;
    await c.save();
    return true;
  }

  return false;
}

// Prices per category (edit to your economy)
const PRICE_TABLE = {
  // components
  pants: 350,
  shoes: 300,
  top: 450,
  undershirt: 250,
  torso: 250,
  accessory: 200,
  mask: 400,

  // props
  hat: 300,
  glasses: 250,
  ears: 150,
  watch: 200,
  bracelet: 200
};

// Inventory templates you must add in rp_item_templates
const TEMPLATE_TABLE = {
  pants: "clothes_pants",
  shoes: "clothes_shoes",
  top: "clothes_top",
  undershirt: "clothes_undershirt",
  torso: "clothes_torso",
  accessory: "clothes_accessory",
  mask: "clothes_mask",

  hat: "prop_hat",
  glasses: "prop_glasses",
  ears: "prop_ears",
  watch: "prop_watch",
  bracelet: "prop_bracelet"
};

// category -> componentId/propId mapping (client also uses this)
const CATEGORY_MAP = {
  pants: { kind: "component", c: 4 },
  shoes: { kind: "component", c: 6 },
  top: { kind: "component", c: 11 },
  undershirt: { kind: "component", c: 8 },
  torso: { kind: "component", c: 3 },
  accessory: { kind: "component", c: 7 },
  mask: { kind: "component", c: 1 },

  hat: { kind: "prop", p: 0 },
  glasses: { kind: "prop", p: 1 },
  ears: { kind: "prop", p: 2 },
  watch: { kind: "prop", p: 6 },
  bracelet: { kind: "prop", p: 7 }
};

function sanitizeCategory(cat) {
  cat = String(cat || "").toLowerCase().trim();
  return CATEGORY_MAP[cat] ? cat : null;
}

mp.events.add("clothesshop:buyPiece", async (player, category, drawable, texture) => {
  try {
    const cat = sanitizeCategory(category);
    if (!cat) return;

    const map = CATEGORY_MAP[cat];
    const price = PRICE_TABLE[cat] || 0;
    const tplName = TEMPLATE_TABLE[cat];
    if (!tplName || price <= 0) return;

    const d = parseInt(drawable, 10);
    const t = parseInt(texture, 10);
    if (!Number.isFinite(d) || !Number.isFinite(t) || d < 0 || t < 0) return;
    if (!isCivilDrawable(cat, d)) return;

    const ok = await chargeCharacter(player, price);
    if (!ok) return;

    // meta describes what to apply when "use" item
    const meta = (map.kind === "component")
      ? { kind: "component", category: cat, c: map.c, d, t, equipped: false }
      : { kind: "prop", category: cat, p: map.p, d, t, equipped: false };

    await invService.addItemByTemplateName(player, tplName, 1, meta);
  } catch (e) {
    console.log("clothesshop:buyPiece error", e);
  }
});
