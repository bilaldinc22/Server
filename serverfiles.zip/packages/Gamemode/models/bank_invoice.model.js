const logger = require('../Logger/discord');

const BankInvoice = sequelize.define('bank_invoices', {
  invoice_id: { type: seq.BIGINT, autoIncrement: true, primaryKey: true },
  from_iban: { type: seq.STRING, allowNull: false },
  to_iban: { type: seq.STRING, allowNull: false },
  amount: { type: seq.BIGINT, allowNull: false },
  reason: { type: seq.STRING, allowNull: false, defaultValue: 'Invoice' },
  status: { type: seq.STRING, allowNull: false, defaultValue: 'OPEN' }, // OPEN | PAID | CANCELLED
}, {
  timestamps: true,
  underscored: true,
});

(async () => {
  try {
    await BankInvoice.sync();
    console.log('[Bank] bank_invoices synced');
  } catch (err) {
    try { logger.sendlog('server_logs', `[Bank] bank_invoices sync failed: ${err}`); } catch(e) {}
    console.log('[Bank] bank_invoices sync failed', err);
  }
})();

module.exports = BankInvoice;
