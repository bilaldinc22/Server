const factions = sequelize.define('factions', {
 
    name: { type: seq.STRING }, 
    catagory: { type: seq.STRING },
    description: { type: seq.STRING },
    code: { type: seq.INTEGER },

    leader: { type: seq.STRING },
    blip: { type: seq.INTEGER },
    blipcolor: {type: seq.INTEGER },
    uicolor: {type: seq.STRING, defaultValue: 'light' },
    turf: { type: seq.STRING },
    origin: { type: seq.STRING },
    treasury: { type: seq.INTEGER, defaultValue: 0 },
    members: { type: seq.INTEGER, defaultValue: 0 },

    treasurylogs: { 
        type: seq.TEXT, defaultValue: '[]',
        get: function () { return JSON.parse(this.getDataValue('treasurylogs')); },
        set: function (value) { this.setDataValue('treasurylogs', JSON.stringify(value)); }
    },

    headquarters: { 
        type: seq.TEXT, defaultValue: '[]',
        get: function () { return JSON.parse(this.getDataValue('headquarters')); },
        set: function (value) { this.setDataValue('headquarters', JSON.stringify(value)); }
    },

     data: { 
        type: seq.TEXT, defaultValue: '[]',
        get: function () { return JSON.parse(this.getDataValue('data')); },
        set: function (value) { this.setDataValue('data', JSON.stringify(value)); }
     },

     ranks: { 
        type: seq.TEXT, defaultValue: '[]',
        get: function () { return JSON.parse(this.getDataValue('ranks')); },
        set: function (value) { this.setDataValue('ranks', JSON.stringify(value)); }
     },


} , {
        timestamps: true,
        underscrored: true,
        createdAt: "regester_date",
        updatedAt: "updated_date"
 });

//characters.removeAttribute('id'); // remove default sequelize id 
// password compare 
factions.prototype.login = function () { 
    // later nigga
};


 // Sync
(async () => {
    await factions.sync();
    console.log(`factions Synced!`);
 })();
 

 module.exports = factions;