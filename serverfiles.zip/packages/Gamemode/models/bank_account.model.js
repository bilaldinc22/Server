const logger = require('../Logger/discord');

const BankAccount = sequelize.define('bank_accounts', {
  account_id: { type: seq.BIGINT, autoIncrement: true, primaryKey: true },
  iban: { type: seq.STRING, unique: true, allowNull: false },
  account_number: { type: seq.STRING, unique: true, allowNull: false },
  name: { type: seq.STRING, allowNull: false },
  type: { type: seq.STRING, allowNull: false, defaultValue: 'company' }, // company | faction
  balance: { type: seq.BIGINT, allowNull: false, defaultValue: 0 },
  created_by_character_id: { type: seq.INTEGER, allowNull: false },
  is_closed: { type: seq.BOOLEAN, allowNull: false, defaultValue: false },
}, {
  timestamps: true,
  underscored: true,
});

(async () => {
  try {
    await BankAccount.sync();
    console.log('[Bank] bank_accounts synced');
  } catch (err) {
    try { logger.sendlog('server_logs', `[Bank] bank_accounts sync failed: ${err}`); } catch(e) {}
    console.log('[Bank] bank_accounts sync failed', err);
  }
})();

module.exports = BankAccount;
