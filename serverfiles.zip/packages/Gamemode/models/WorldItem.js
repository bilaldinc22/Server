'use strict';

require('../sequelize');
const { DataTypes } = global.seq;

const WorldItem = global.sequelize.define('WorldItem', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    item_template_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
    },
    amount: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 1
    },
    pos_x: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    pos_y: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    pos_z: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    rot_z: {
        type: DataTypes.FLOAT,
        allowNull: false,
        defaultValue: 0
    },
    dimension: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    meta: {
        type: DataTypes.JSON,
        allowNull: true
    }
}, {
    tableName: 'rp_world_items',
    timestamps: false
});

module.exports = WorldItem;
