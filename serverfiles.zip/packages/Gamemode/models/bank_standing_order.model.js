const logger = require('../Logger/discord');

const BankStandingOrder = sequelize.define('bank_standing_orders', {
  so_id: { type: seq.BIGINT, autoIncrement: true, primaryKey: true },
  from_iban: { type: seq.STRING, allowNull: false },
  to_iban: { type: seq.STRING, allowNull: false },
  amount: { type: seq.BIGINT, allowNull: false },
  interval_hours: { type: seq.INTEGER, allowNull: false, defaultValue: 24 },
  reason: { type: seq.STRING, allowNull: false, defaultValue: 'Standing order' },
  enabled: { type: seq.BOOLEAN, allowNull: false, defaultValue: true },
  next_run_at: { type: seq.BIGINT, allowNull: false, defaultValue: 0 }, // ms timestamp
}, {
  timestamps: true,
  underscored: true,
});

(async () => {
  try {
    await BankStandingOrder.sync();
    console.log('[Bank] bank_standing_orders synced');
  } catch (err) {
    try { logger.sendlog('server_logs', `[Bank] bank_standing_orders sync failed: ${err}`); } catch(e) {}
    console.log('[Bank] bank_standing_orders sync failed', err);
  }
})();

module.exports = BankStandingOrder;
