const logger = require('../Logger/discord');

const BankLedger = sequelize.define('bank_ledger', {
  ledger_id: { type: seq.BIGINT, autoIncrement: true, primaryKey: true },
  iban: { type: seq.STRING, allowNull: false },
  type: { type: seq.STRING, allowNull: false }, // DEPOSIT | WITHDRAW | TRANSFER_IN | TRANSFER_OUT | INVOICE_PAY | SO_RUN | FEE
  amount: { type: seq.BIGINT, allowNull: false },
  balance_before: { type: seq.BIGINT, allowNull: false },
  balance_after: { type: seq.BIGINT, allowNull: false },
  info: { type: seq.STRING, allowNull: false, defaultValue: '' },
  meta: {
    type: seq.TEXT,
    get: function () {
      try { return JSON.parse(this.getDataValue('meta') || '{}'); } catch(e) { return {}; }
    },
    set: function (value) { this.setDataValue('meta', JSON.stringify(value || {})); }
  },
}, {
  timestamps: true,
  underscored: true,
});

(async () => {
  try {
    await BankLedger.sync();
    console.log('[Bank] bank_ledger synced');
  } catch (err) {
    try { logger.sendlog('server_logs', `[Bank] bank_ledger sync failed: ${err}`); } catch(e) {}
    console.log('[Bank] bank_ledger sync failed', err);
  }
})();

module.exports = BankLedger;
