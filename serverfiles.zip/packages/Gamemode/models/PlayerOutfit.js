'use strict';

require('../sequelize');
const { DataTypes } = global.seq;

const PlayerOutfit = global.sequelize.define('PlayerOutfit', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  owner_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  components: { type: DataTypes.JSON, allowNull: true },
  props: { type: DataTypes.JSON, allowNull: true },
  model: { type: DataTypes.BIGINT, allowNull: true }
}, {
  tableName: 'rp_player_outfits',
  timestamps: false
});

module.exports = PlayerOutfit;
