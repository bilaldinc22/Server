
const whitelist = sequelize.define('whitelist', {
    socialclub: { type: seq.STRING }
} , {
        timestamps: true,
        underscrored: true,
        createdAt: "regester_date",
        updatedAt: "updated_date"
 });

 whitelist.prototype.login = function () { 
    // compare passwods return ? true false;
};

 // Sync
(async () => {
   await whitelist.sync();
   console.log(`Whitelist Synced!`);
 })();
 

module.exports = whitelist;