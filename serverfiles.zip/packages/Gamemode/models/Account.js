'use strict';

require('../sequelize');
const { DataTypes } = global.seq;

// eigenes Account-Model für Persistenz, getrennt vom Admin-accounts-Model
const Account = global.sequelize.define('Account', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    socialclub: {
        type: DataTypes.STRING(64),
        allowNull: false,
        unique: true
    },
    name: {
        type: DataTypes.STRING(64),
        allowNull: false
    },
    cash: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    bank: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    last_position_x: {
        type: DataTypes.FLOAT,
        allowNull: false,
        defaultValue: 0
    },
    last_position_y: {
        type: DataTypes.FLOAT,
        allowNull: false,
        defaultValue: 0
    },
    last_position_z: {
        type: DataTypes.FLOAT,
        allowNull: false,
        defaultValue: 72
    },
    last_dimension: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    }
}, {
    tableName: 'rp_accounts',
    timestamps: false
});

module.exports = Account;
