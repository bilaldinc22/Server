const { DataTypes } = require("sequelize");
const characters = sequelize.define('characters', {
    // Character Basics
    username: { type: seq.STRING },

    character_id: { type: seq.INTEGER, autoIncrement: true, primaryKey: true },  
    character_name: { type: seq.STRING }, 
    character_gender: { type: seq.BOOLEAN },

    character_position: { 
        type: seq.TEXT, 
        get: function () { return JSON.parse(this.getDataValue('character_position')); },
        set: function (value) { this.setDataValue('character_position', JSON.stringify(value)); }
    },

    character_heading: { type: seq.INTEGER, defaultValue: 180 },
    character_dimension: { type: seq.INTEGER, defaultValue: 0 },


    character_appearance: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('character_appearance')); },
        set: function (value) { this.setDataValue('character_appearance', JSON.stringify(value)); }
     },

     character_features: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('character_features')); },
        set: function (value) { this.setDataValue('character_features', JSON.stringify(value)); }
     },

     character_clothes: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('character_clothes')); },
        set: function (value) { this.setDataValue('character_clothes', JSON.stringify(value)); }
     },

     character_inventory: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('character_inventory')); },
        set: function (value) { this.setDataValue('character_inventory', JSON.stringify(value)); }
     },

     faction_data: { 
        type: seq.TEXT, defaultValue: '[]',
        get: function () { return JSON.parse(this.getDataValue('faction_data')); },
        set: function (value) { this.setDataValue('faction_data', JSON.stringify(value)); }
     },

    mood: { type: seq.STRING, defaultValue: 'normal' },
    walking_style: { type: seq.STRING, defaultValue: 0 },

    house_slots: { type: seq.INTEGER, defaultValue: 2 },
    business_slots: { type: seq.INTEGER, defaultValue: 2 },
    vehicle_slots: { type: seq.INTEGER, defaultValue: 2 },

    // JOB
    job: { type: seq.INTEGER },
    working_hours: { type: seq.INTEGER },
    licenses: { type: seq.STRING },

    // Money
    pocket_money: { type: seq.BIGINT, defaultValue: 0 },
    bank_money: { type: seq.BIGINT, defaultValue: 15000 },
    bank_iban: { type: seq.STRING },
    bank_account_number: { type: seq.STRING },
    bank_pin_salt: { type: seq.STRING },
    bank_pin_hash: { type: seq.STRING },
    bank_locked_until: { type: seq.BIGINT, defaultValue: 0 },
    salary: { type: seq.INTEGER, defaultValue: 4500 },

    // Health 
    health: { type: seq.INTEGER, defaultValue: 100 },
    vest: { type: seq.INTEGER, defaultValue: 0 },
    hunger: { type: seq.FLOAT, defaultValue: 100 },
    thirst: { type: seq.FLOAT, defaultValue: 100 },
    wounded: { type: seq.BOOLEAN, defaultValue: false },
    cuffed: { type: seq.BOOLEAN, defaultValue: false },

    muted: { type: seq.INTEGER, defaultValue: 0 },
    muted_hours: { type: seq.INTEGER, defaultValue: 0 },
    muted_minutes: { type: seq.INTEGER, defaultValue: 0 },


} , {
        timestamps: true,
        underscrored: true,
        createdAt: "regester_date",
        updatedAt: "updated_date"
 ,

    outfit: {
        type: DataTypes.JSON,
        allowNull: false,
        defaultValue: {}
    }
});

//characters.removeAttribute('id'); // remove default sequelize id 
// password compare 
characters.prototype.login = function () { 
    // later nigga
};


 // Sync
(async () => {
    await characters.sync();
    console.log(`Characters Synced!`);
 })();
 

 module.exports = characters;