
const logger = require('../Logger/discord');
const itemjs = require('../Inventory/item');

const items = sequelize.define('items', {

    id: { type: seq.INTEGER, autoIncrement: true, primaryKey: true },
    name: { type: seq.STRING },
    type: { type: seq.STRING },
    description: { type: seq.STRING },
    model: { type: seq.STRING },
    spawned: { type: seq.BOOLEAN },

    owner: { type: seq.STRING },
    slot: { type: seq.INTEGER },
    equiped: { type: seq.BOOLEAN },
    
    /*
    height: { type: seq.INTEGER },
    width: { type: seq.INTEGER },
    weight: { type: seq.INTEGER },
    quantity: { type: seq.INTEGER },
    owner: { type: seq.STRING },
    last_owner: { type: seq.STRING },
    dimension: { type: seq.INTEGER },
*/

    position: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('position')); },
        set: function (value) { this.setDataValue('position', JSON.stringify(value)); }
    },

    rotation: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('rotation')); },
        set: function (value) { this.setDataValue('rotation', JSON.stringify(value)); }
    },

    last_owners: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('last_owners')); },
        set: function (value) { this.setDataValue('last_owners', JSON.stringify(value)); }
    },

    data: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('data')); },
        set: function (value) { this.setDataValue('data', JSON.stringify(value)); }
    },

} , {
        timestamps: true,
        underscrored: true,
        createdAt: "regester_date",
        updatedAt: "updated_date"
 });

 items.prototype.login = function () { 
    // compare passwods return ? true false;
};

 // Sync
(async () => {
    try 
    {
        await items.sync();
        console.log(`Items Synced!`);
        const all = await items.findAll();
        if(!all.length) return;
        all.forEach((item) => {
            itemjs.loadItem(JSON.stringify(item));
        });
    }
    catch(err) {
        logger.serverlog(`Sync Items Failed ${err}`);
    }
 })();
 

module.exports = items;