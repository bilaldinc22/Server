const logger = require('../Logger/discord');

const BankTransaction = sequelize.define('bank_transactions', {
    tx_id: { type: seq.BIGINT, autoIncrement: true, primaryKey: true },
    character_name: { type: seq.STRING, allowNull: false },
    type: { type: seq.STRING, allowNull: false }, // DEPOSIT | WITHDRAW | TRANSFER_IN | TRANSFER_OUT | FEE
    amount: { type: seq.BIGINT, allowNull: false, defaultValue: 0 },
    pocket_before: { type: seq.BIGINT, allowNull: false, defaultValue: 0 },
    pocket_after: { type: seq.BIGINT, allowNull: false, defaultValue: 0 },
    bank_before: { type: seq.BIGINT, allowNull: false, defaultValue: 0 },
    bank_after: { type: seq.BIGINT, allowNull: false, defaultValue: 0 },
    meta: { 
        type: seq.TEXT,
        get: function () { 
            try { return JSON.parse(this.getDataValue('meta') || '{}'); } catch (e) { return {}; }
        },
        set: function (value) { this.setDataValue('meta', JSON.stringify(value || {})); }
    },
}, {
    timestamps: true,
    underscored: true,
});

(async () => {
    try {
        await BankTransaction.sync();
        console.log('[Bank] bank_transactions synced');
    } catch (err) {
        try { logger.sendlog('server_logs', `[Bank] bank_transactions sync failed: ${err}`); } catch(e) {}
        console.log('[Bank] bank_transactions sync failed', err);
    }
})();

module.exports = BankTransaction;
