'use strict';

require('../sequelize');
const { DataTypes } = global.seq;

/**
 * Persisted weapon components per player/weapon.
 * Table will be auto-created by Sequelize sync.
 */
const PlayerWeaponComponent = global.sequelize.define('PlayerWeaponComponent', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    owner_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
    },
    weapon_hash: {
        // store as string to avoid uint32 overflow issues in some DBs
        type: DataTypes.STRING(64),
        allowNull: false
    },
    component_hash: {
        type: DataTypes.STRING(64),
        allowNull: false
    }
}, {
    tableName: 'rp_player_weapon_components',
    timestamps: false,
    indexes: [
        { unique: true, fields: ['owner_id', 'weapon_hash', 'component_hash'] }
    ]
});

module.exports = PlayerWeaponComponent;
