'use strict';

require('../sequelize');
const { DataTypes } = global.seq;

const ItemTemplate = require('./ItemTemplate');

const PlayerItem = global.sequelize.define('PlayerItem', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  owner_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  item_template_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  amount: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false, defaultValue: 1 },
  slot: { type: DataTypes.INTEGER, allowNull: false },
  // IMPORTANT: in your DB meta is a string column -> store JSON as STRING/TEXT
  meta: { type: DataTypes.TEXT, allowNull: true }
}, {
  tableName: 'rp_player_items',
  timestamps: false
});

// Associations for include
PlayerItem.belongsTo(ItemTemplate, { foreignKey: 'item_template_id', as: 'template' });
ItemTemplate.hasMany(PlayerItem, { foreignKey: 'item_template_id', as: 'items' });

module.exports = PlayerItem;
