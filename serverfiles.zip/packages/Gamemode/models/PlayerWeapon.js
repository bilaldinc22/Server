'use strict';

require('../sequelize');
const { DataTypes } = global.seq;

const PlayerWeapon = global.sequelize.define('PlayerWeapon', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    owner_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
    },
    weapon_hash: {
        type: DataTypes.STRING(64),
        allowNull: false
    },
    ammo: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    is_equipped: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true
    }
}, {
    tableName: 'rp_player_weapons',
    timestamps: false
});

module.exports = PlayerWeapon;
