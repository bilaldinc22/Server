const logger = require('../Logger/discord');
const atmjs = require('../Bank/atm');


const atms = sequelize.define('atms', {
    atm_id: { type: seq.INTEGER, autoIncrement: true, primaryKey: true },
    atm_pos: { 
        type: seq.TEXT, 
        get: function () { return JSON.parse(this.getDataValue('atm_pos')); },
        set: function (value) { this.setDataValue('atm_pos', JSON.stringify(value)); }
    },
    atm_cash: { type: seq.BIGINT },
    atm_closed: { type: seq.BOOLEAN },
} , {
        timestamps: true,
        underscrored: true,
        createdAt: "regester_date",
        updatedAt: "updated_date"
 });

atms.prototype.login = function () { 
    // compare passwods return ? true false;
};

 // Sync
 (async () => {
    await atms.sync();
try {
    const find = await atms.findAll();
    if(!find) return;
    find.forEach(async (atm) => {
        atmjs.loadAtm(atm.atm_pos, atm.atm_id);
    });
    console.log(`Atms Synced!`)
    } catch (err) {
        logger.serverLog(`Atm Loading Failed ${err}`);
    }
})();
 

module.exports = atms;