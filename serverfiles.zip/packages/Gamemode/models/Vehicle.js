'use strict';

require('../sequelize');
const { DataTypes } = global.seq;

const Vehicle = global.sequelize.define('Vehicle', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    owner_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
    },
    model: {
        type: DataTypes.STRING(64),
        allowNull: false
    },
    pos_x: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    pos_y: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    pos_z: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    rot_z: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    dimension: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    color1: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    color2: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    locked: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
    },
    health: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 1000
    },
    fuel: {
        type: DataTypes.FLOAT,
        allowNull: false,
        defaultValue: 100
    },
    plate: {
        type: DataTypes.STRING(16),
        allowNull: true
    }
}, {
    tableName: 'rp_vehicles',
    timestamps: false
});

module.exports = Vehicle;
