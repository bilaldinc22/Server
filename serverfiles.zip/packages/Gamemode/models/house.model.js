const logger = require('../Logger/discord');
const housejs = require('../PropertySystem/house');
const houses = sequelize.define('houses', {

    house_id: { type: seq.INTEGER, autoIncrement: true, primaryKey: true },
    house_address: { type: seq.STRING },
    house_status: { type: seq.STRING, defaultValue: false },
    house_price: { type: seq.STRING },
    house_owner: { type: seq.STRING, defaultValue: 'Los Santos Govt' },

    // House Interior -------------------------------------------------------------------------
    house_interior: { type: seq.INTEGER },
    
    house_interior_name: { type: seq.STRING },

    house_interior_position: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('house_interior_position')); },
        set: function (value) { this.setDataValue('house_interior_position', JSON.stringify(value)); }
    },

    house_interior_heading: {
        type: seq.TEXT, 
        get: function () { return JSON.parse(this.getDataValue('house_interior_heading')); },
        set: function (value) { this.setDataValue('house_interior_heading', JSON.stringify(value)); }
    },

    house_garage_position: {
        type: seq.TEXT, 
        get: function () { return JSON.parse(this.getDataValue('house_garage_position')); },
        set: function (value) { this.setDataValue('house_garage_position', JSON.stringify(value)); }
    },

    house_garage_slots: { type: seq.INTEGER },

    house_garage_vehicles: {
        type: seq.TEXT, 
        get: function () { return JSON.parse(this.getDataValue('house_garage_vehicles')); },
        set: function (value) { this.setDataValue('house_garage_vehicles', JSON.stringify(value)); }
    },

    //---------------------------------------------------------------------------------------
    house_position: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('house_position')); },
        set: function (value) { this.setDataValue('house_position', JSON.stringify(value)); }
    },

    house_inventory: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('house_inventory')); },
        set: function (value) { this.setDataValue('house_inventory', JSON.stringify(value)); }
    },

    house_inventory_position: {
        type: seq.TEXT, 
        get: function () { return JSON.parse(this.getDataValue('house_inventory_position')); },
        set: function (value) { this.setDataValue('house_inventory_position', JSON.stringify(value)); }
    },

    house_furniture: { 
        type: seq.TEXT,
        get: function () { return JSON.parse(this.getDataValue('house_furniture')); },
        set: function (value) { this.setDataValue('house_furniture', JSON.stringify(value)); }
    },

    house_vehicles: {
        type: seq.TEXT, 
        get: function () { return JSON.parse(this.getDataValue('house_vehicles')); },
        set: function (value) { this.setDataValue('house_vehicles', JSON.stringify(value)); }
    },

    house_tenants: {
        type: seq.TEXT, 
        get: function () { return JSON.parse(this.getDataValue('house_tenants')); },
        set: function (value) { this.setDataValue('house_tenants', JSON.stringify(value)); }
    },

    

    house_lock: { type: seq.BOOLEAN, defaultValue: false },

} , {
        timestamps: true,
        underscrored: true,
        createdAt: "regester_date",
        updatedAt: "updated_date"
 });

 houses.prototype.login = function () { 
    // compare passwods return ? true false;
};

 // Sync
(async () => {
    try 
    {
        await houses.sync();
        console.log(`Houses Synced!`);
        const all = await houses.findAll();
    
        all.forEach((house) => {
            housejs.loadHouse(house)
        });
    }
    catch(err) {
        logger.serverLog(`Sync Houses Failed ${err}`);
    }
 })();
 

module.exports = houses;