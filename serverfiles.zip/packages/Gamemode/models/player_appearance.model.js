const { DataTypes } = global.seq || require('sequelize');

// Table: rp_player_appearance
// owner_id: character.id (unique)
// tattoos: JSON string (array)
// barber: JSON string (object)
const PlayerAppearance = global.sequelize.define('rp_player_appearance', {
  owner_id: { type: DataTypes.INTEGER, allowNull: false, unique: true },
  tattoos: { type: DataTypes.TEXT('long'), allowNull: false, defaultValue: '[]' },
  barber: { type: DataTypes.TEXT('long'), allowNull: false, defaultValue: '{}' }
}, {
  timestamps: true,
  underscored: true
});

module.exports = PlayerAppearance;
