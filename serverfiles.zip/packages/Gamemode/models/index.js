'use strict';

require('../sequelize');

const Account = require('./Account');
const Vehicle = require('./Vehicle');
const ItemTemplate = require('./ItemTemplate');
const PlayerItem = require('./PlayerItem');
const PlayerWeapon = require('./PlayerWeapon');
const PlayerWeaponComponent = require('./PlayerWeaponComponent');
const WorldItem = require('./WorldItem');
const PlayerOutfit = require('./PlayerOutfit');

// Account <-> Vehicle
Account.hasMany(Vehicle, { foreignKey: 'owner_id', as: 'vehicles', constraints: false });
Vehicle.belongsTo(Account, { foreignKey: 'owner_id', as: 'owner', constraints: false });

// Account <-> PlayerItem
Account.hasMany(PlayerItem, { foreignKey: 'owner_id', as: 'items', constraints: false });
PlayerItem.belongsTo(Account, { foreignKey: 'owner_id', as: 'owner', constraints: false });

// ItemTemplate <-> PlayerItem  (WICHTIG für Inventory)
ItemTemplate.hasMany(PlayerItem, { foreignKey: 'item_template_id', as: 'playerItems', constraints: false });
PlayerItem.belongsTo(ItemTemplate, { foreignKey: 'item_template_id', as: 'template', constraints: false });

// Account <-> PlayerWeapon
Account.hasMany(PlayerWeapon, { foreignKey: 'owner_id', as: 'weapons', constraints: false });
PlayerWeapon.belongsTo(Account, { foreignKey: 'owner_id', as: 'owner', constraints: false });

// Account <-> PlayerWeaponComponent
Account.hasMany(PlayerWeaponComponent, { foreignKey: 'owner_id', as: 'weaponComponents', constraints: false });
PlayerWeaponComponent.belongsTo(Account, { foreignKey: 'owner_id', as: 'owner', constraints: false });


// ItemTemplate <-> WorldItem
ItemTemplate.hasMany(WorldItem, { foreignKey: 'item_template_id', as: 'worldItems', constraints: false });
WorldItem.belongsTo(ItemTemplate, { foreignKey: 'item_template_id', as: 'template', constraints: false });

// (optional) Account <-> Outfit
Account.hasMany(PlayerOutfit, { foreignKey: 'owner_id', as: 'outfits', constraints: false });
PlayerOutfit.belongsTo(Account, { foreignKey: 'owner_id', as: 'owner', constraints: false });

global.sequelize.sync()
  .then(() => console.log('Sequelize models synced'))
  .catch(err => console.log('Sequelize sync error:', err));

module.exports = {
  Account, Vehicle, ItemTemplate, PlayerItem, PlayerWeapon, PlayerWeaponComponent, WorldItem, PlayerOutfit
};
