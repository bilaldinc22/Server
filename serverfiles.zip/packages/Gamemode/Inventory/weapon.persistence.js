const PlayerWeapon = require('../models/PlayerWeapon');

async function saveWeaponsSafe(player) {
    if (!player?.character?.id) return;

    await PlayerWeapon.destroy({
        where: { owner_id: player.character.id }
    });

    const allWeapons = Object.values(mp.weapons.all);

    for (const hash of allWeapons) {
        const ammo = player.getAmmo(hash);
        if (ammo > 0) {
            await PlayerWeapon.create({
                owner_id: player.character.id,
                weapon_hash: String(hash),
                ammo,
                is_equipped: true
            });
        }
    }
}

async function loadWeapons(player) {
    if (!player?.character?.id) return;

    const weapons = await PlayerWeapon.findAll({
        where: { owner_id: player.character.id }
    });

    for (const w of weapons) {
        const hash = Number(w.weapon_hash);
        if (!hash) continue;
        player.giveWeapon(hash, w.ammo ?? 0);
    }
}

module.exports = { saveWeaponsSafe, loadWeapons };