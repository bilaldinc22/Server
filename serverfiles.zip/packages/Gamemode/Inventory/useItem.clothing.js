'use strict';
const service = require('./inventory.service');
mp.events.add('inventory:useItem', (player, itemId) => { service.useItem(player, itemId); });
