'use strict';

const money = require('../moneyscripts/money.adapter');


// === CASH SAVE FIX (PASSEND ZU character.js) ===
const Character = require('../Character/character');

async function saveCash(player) {
    if (!player || !player.valid) return;
    await Character.save(player);
}


// --- Inventory wearable helpers (auto-added) ---
// Used by older equip flow; keeps server from crashing if referenced.
function captureCurrentAppearance(player) {
    const data = { components: {}, props: {}, armour: 0 };
    try { data.armour = typeof player.armour === 'number' ? player.armour : (player.getArmour ? player.getArmour() : 0); } catch (_) {}
    // Components 0..11
    for (let i = 0; i <= 11; i++) {
        try {
            const c = player.getClothes ? player.getClothes(i) : null;
            data.components[i] = c ? { drawable: c.drawable, texture: c.texture, palette: c.palette } : { drawable: 0, texture: 0, palette: 0 };
        } catch (_) {
            data.components[i] = { drawable: 0, texture: 0, palette: 0 };
        }
    }
    // Props 0..7
    for (let i = 0; i <= 7; i++) {
        let drawable = -1, texture = 0;
        try { drawable = player.getProp ? player.getProp(i) : -1; } catch (_) {}
        try { texture = player.getPropTexture ? player.getPropTexture(i) : 0; } catch (_) {}
        data.props[i] = { drawable, texture };
    }
    return data;
}

function restoreAppearance(player, data) {
    if (!data) return;
    try {
        if (player.setArmour && typeof data.armour === 'number') player.setArmour(data.armour);
    } catch (_) {}
    if (data.components && player.setClothes) {
        for (const k of Object.keys(data.components)) {
            const v = data.components[k];
            try { player.setClothes(Number(k), v.drawable, v.texture, v.palette ?? 0); } catch (_) {}
        }
    }
    if (data.props) {
        for (const k of Object.keys(data.props)) {
            const v = data.props[k];
            try {
                const idx = Number(k);
                if (v.drawable === -1) {
                    if (player.clearProp) player.clearProp(idx);
                } else {
                    if (player.setProp) player.setProp(idx, v.drawable, v.texture ?? 0);
                }
            } catch (_) {}
        }
    }
}
// --- end helpers ---

/**
 * inventory.service.js (sync-safe)
 * - Clothing is applied SERVER-SIDE via player.setClothes / player.setProp -> syncs to all players automatically in RAGE MP.
 * - Adds restoreEquippedClothes() called on playerReady (like weapons), so relog/spawn restores outfit for everyone.
 * - No chat debug spam.
 */

const PlayerItem = require('../models/PlayerItem');
const ItemTemplate = require('../models/ItemTemplate');

const MAX_SLOTS = 40;

function getOwnerId(player) {
  return player.characterId || (player.character && player.character.id) || null;
}

function parseMeta(meta) {
  if (!meta) return {};
  if (typeof meta === 'object') return meta;
  try { return JSON.parse(meta); } catch (_) { return {}; }
}

function stringifyMeta(obj) {
  try { return JSON.stringify(obj || {}); } catch (_) { return "{}"; }
}

function isWeaponTemplate(tpl) {
  if (!tpl) return false;
  const name = String(tpl.name || '').toLowerCase();
  return name.startsWith('weapon_');
}

function isAmmoTemplate(tpl) {
  if (!tpl) return false;
  const name = String(tpl.name || '').toLowerCase();
  return name.endsWith('_ammo') || name.includes('ammo');
}

function isClothesTemplateName(name) {
  name = String(name || '').toLowerCase();
  return name.startsWith('clothes_') || name.startsWith('prop_') || name.startsWith('outfit_');
}

function componentFromClothesName(name) {
  name = String(name || '').toLowerCase();
  if (name === 'clothes_mask' || name.startsWith('clothes_mask_') || name.includes('mask')) return 1;
  if (name === 'clothes_accessory' || name.startsWith('clothes_accessory_') || name.includes('accessory') || name.includes('schmuck')) return 7;
  if (name.includes('pants') || name.includes('hose') || name.includes('legs')) return 4;
  if (name.includes('shoes') || name.includes('schuhe')) return 6;
  if (name.includes('torso')) return 3;
  if (name.includes('top') || name.includes('oberteil')) return 11;
  if (name.includes('undershirt') || name.includes('unterhemd')) return 8;
  return null;
}

function weaponHashFromTemplate(tpl) {
  return mp.joaat(String(tpl.name).toLowerCase());
}

function shouldHideFromInventoryRow(row) {
  if (!row || !row.template) return false;
  if (!isWeaponTemplate(row.template)) return false;
  const m = parseMeta(row.meta);
  return !!m.equipped;
}

async function findFreeSlot(ownerId) {
  const used = await PlayerItem.findAll({ where: { owner_id: ownerId } });
  const usedSlots = new Set(used.map(r => r.slot));
  let slot = 1;
  while (usedSlots.has(slot) && slot <= MAX_SLOTS) slot++;
  if (slot > MAX_SLOTS) return 0;
  return slot;
}

async function findItemByIdOrSlot(ownerId, idOrSlot) {
  const n = parseInt(idOrSlot, 10);
  if (!n) return null;
  let item = await PlayerItem.findOne({ where: { owner_id: ownerId, id: n } });
  if (item) return item;
  item = await PlayerItem.findOne({ where: { owner_id: ownerId, slot: n } });
  return item;
}

async function getInventoryByOwner(ownerId) {
  const rows = await PlayerItem.findAll({
    where: { owner_id: ownerId },
    include: [{ model: ItemTemplate, as: 'template' }],
    order: [['slot', 'ASC']]
  });
  return rows.filter(r => !shouldHideFromInventoryRow(r));
}

async function getInventoryWeight(ownerId) {
  const items = await PlayerItem.findAll({ where: { owner_id: ownerId } });
  return items.reduce((s, i) => s + (Number(i.amount) || 0), 0);
}

function getMaxWeight() { return 100; }

async function findEquippedWeaponItem(ownerId) {
  const rows = await PlayerItem.findAll({
    where: { owner_id: ownerId },
    include: [{ model: ItemTemplate, as: 'template' }]
  });
  for (const r of rows) {
    if (!r.template || !isWeaponTemplate(r.template)) continue;
    const m = parseMeta(r.meta);
    if (m.equipped) return r;
  }
  return null;
}

async function restoreEquippedWeapon(player) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return false;

  const weaponItem = await findEquippedWeaponItem(ownerId);
  if (!weaponItem) return false;

  const hash = weaponHashFromTemplate(weaponItem.template);
  const meta = parseMeta(weaponItem.meta);
  const ammo = (meta.ammo !== undefined) ? (parseInt(meta.ammo, 10) || 0) : 0;

  try { player.giveWeapon(hash, ammo); } catch (_) {}
  return true;
}

function applyComponent(player, c, d, t) {
  try { player.setClothes(Number(c), Number(d), Number(t) || 0, 0); } catch (_) {}
}
function applyProp(player, p, d, t) {
  try {
    const dd = Number(d);
    if (dd < 0) player.clearProp(Number(p));
    else player.setProp(Number(p), dd, Number(t) || 0);
  } catch (_) {}
}


// ---- Base appearance (used when unequipping clothing) ----
// We capture current clothes/props once (after spawn/ready) and treat it as the "underwear/base" outfit.
// For Tops (component 11) we enforce a shirtless preset so unequipping doesn't revert to a T-shirt.
function getShirtlessPreset() {
  // Works for freemode peds (mp_m_freemode_01 / mp_f_freemode_01). If you use custom peds, adjust as needed.
  return {
    11: { d: 15, t: 0 }, // top
    8:  { d: 15, t: 0 }, // undershirt
    3:  { d: 15, t: 0 }  // torso/arms
  };
}


function getUnderwearPreset(player) {
  // GTA V freemode underwear default. Adjust if needed for custom peds.
  // component 4 = legs
  return { 4: { d: 21, t: 0 } };
}
function getDefaultShoesPreset(player) {
  return { 6: { d: 34, t: 0 } };
}
function getDefaultTorsoPreset(player) {
  return { 3: { d: 15, t: 0 } };
}

function ensureBaseAppearance(player) {
  if (player._invBaseAppearance) return;

  player._invBaseAppearance = { components: {}, props: {} };

  const compsToCapture = [3,4,5,6,7,8,9,10,11];
  const propsToCapture = [0,1,2,6,7];

  for (const c of compsToCapture) {
    const cur = readCurrentComponent(player, c);
    if (cur) player._invBaseAppearance.components[c] = { d: cur.d, t: cur.t };
  }
  for (const p of propsToCapture) {
    const cur = readCurrentProp(player, p);
    if (cur) player._invBaseAppearance.props[p] = { d: cur.d, t: cur.t };
  }

  // Force shirtless base for tops
  const shirtless = getShirtlessPreset();
  for (const k of Object.keys(shirtless)) player._invBaseAppearance.components[Number(k)] = shirtless[k];
}

function getBaseComponent(player, c) {
  ensureBaseAppearance(player);
  const base = player._invBaseAppearance && player._invBaseAppearance.components ? player._invBaseAppearance.components : {};
  return base && base[c] ? base[c] : { d: 0, t: 0 };
}
function getBaseProp(player, p) {
  ensureBaseAppearance(player);
  const base = player._invBaseAppearance && player._invBaseAppearance.props ? player._invBaseAppearance.props : {};
  return base && base[p] ? base[p] : { d: -1, t: 0 };
}

// Read current appearance so we can restore on unequip.
function readCurrentComponent(player, c) {
  try {
    const res = player.getClothes(Number(c));
    if (res && typeof res === 'object') {
      const drawable = res.drawable !== undefined ? res.drawable : res[0];
      const texture = res.texture !== undefined ? res.texture : res[1];
      if (drawable !== undefined && texture !== undefined) return { d: Number(drawable) || 0, t: Number(texture) || 0 };
    }
  } catch (_) {}
  return null;
}

function readCurrentProp(player, p) {
  try {
    const res = player.getProp(Number(p));
    if (typeof res === 'number') {
      let texture = 0;
      try { texture = player.getPropTexture ? player.getPropTexture(Number(p)) : 0; } catch (_) {}
      return { d: Number(res), t: Number(texture) || 0 };
    }
    if (res && typeof res === 'object') {
      const drawable = res.drawable !== undefined ? res.drawable : res[0];
      const texture = res.texture !== undefined ? res.texture : res[1];
      if (drawable !== undefined && texture !== undefined) return { d: Number(drawable), t: Number(texture) || 0 };
    }
  } catch (_) {}
  return null;
}

/**
 * Restores all equipped clothes/props/outfits SERVER-SIDE -> syncs to all players.
 * Works for:
 * - single pieces: template clothes_* / prop_* with meta {kind:'component'|'prop', c/p, d, t, equipped:true}
 * - outfits: template outfit_* with meta {outfit:{clothes:[{c,d,t}], props:[{p,d,t}]}, equipped:true}
 */
async function restoreEquippedClothes(player) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return false;

  const rows = await PlayerItem.findAll({
    where: { owner_id: ownerId },
    include: [{ model: ItemTemplate, as: 'template' }]
  });

  const equipped = [];
  for (const r of rows) {
    if (!r.template) continue;
    const name = String(r.template.name || '').toLowerCase();
    if (!isClothesTemplateName(name)) continue;
    const m = parseMeta(r.meta);
    if (m && m.equipped) equipped.push({ name, meta: m });
  }

  if (equipped.length === 0) return false;

  // Apply components first, then props (prevents props being cleared by later outfit applications)
  // 1) outfits clothes
  for (const e of equipped) {
    if (!e.name.startsWith('outfit_')) continue;
    const outfit = e.meta.outfit || {};
    const clothes = Array.isArray(outfit.clothes) ? outfit.clothes : [];
    for (const cc of clothes) applyComponent(player, cc.c, cc.d, cc.t);
  }
  // 2) single clothes_* components
  for (const e of equipped) {
    if (!e.name.startsWith('clothes_')) continue;
    if (e.meta.kind !== 'component') continue;
    applyComponent(player, e.meta.c, e.meta.d, e.meta.t);
  }
  // 3) outfits props
  for (const e of equipped) {
    if (!e.name.startsWith('outfit_')) continue;
    const outfit = e.meta.outfit || {};
    const props = Array.isArray(outfit.props) ? outfit.props : [];
    for (const pp of props) applyProp(player, pp.p, pp.d, pp.t);
  }
  // 4) single prop_* props
  for (const e of equipped) {
    if (!e.name.startsWith('prop_')) continue;
    if (e.meta.kind !== 'prop') continue;
    applyProp(player, e.meta.p, e.meta.d, e.meta.t);
  }

  return true;
}

// Auto restore on playerReady with retry until characterId exists
const restoring = new Set();
mp.events.add('playerReady', (player) => {
  if (restoring.has(player)) return;
  restoring.add(player);

  let tries = 0;
  const t = setInterval(async () => {
    tries++;
    if (!player || !mp.players.exists(player)) { clearInterval(t); restoring.delete(player); return; }

    const ownerId = getOwnerId(player);
    if (!ownerId) {
      if (tries >= 60) { clearInterval(t); restoring.delete(player); }
      return;
    }

    try {
      await restoreEquippedWeapon(player);
      await restoreEquippedClothes(player);
    } catch (_) {}
    clearInterval(t);
    restoring.delete(player);
  }, 250);
});

async function moveItem(player, fromIdOrSlot, toSlot) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return;

  const targetSlot = parseInt(toSlot, 10) || 0;
  if (targetSlot <= 0 || targetSlot > MAX_SLOTS) return;

  const fromItem = await findItemByIdOrSlot(ownerId, fromIdOrSlot);
  if (!fromItem) return;

  const tpl = await ItemTemplate.findByPk(fromItem.item_template_id);
  const tplName = String((tpl && tpl.name) || '').toLowerCase();
  const isWeapon = (tpl && isWeaponTemplate(tpl)) || tplName.startsWith('weapon_');
  const m = parseMeta(fromItem.meta);
  const isWeaponMeta = m && m.kind === 'weapon';
  if ((isWeapon || isWeaponMeta || tplName.startsWith('weapon_')) && m.equipped && fromItem.slot !== 0) {
    if (tpl && isWeaponTemplate(tpl)) {
      const hash = weaponHashFromTemplate(tpl);
      try { player.removeWeapon(hash); } catch (_) {}
    } else {
      try { player.removeAllWeapons(); } catch (_) {}
    }
    m.equipped = false;
    fromItem.meta = stringifyMeta(m);
    await fromItem.save();
  }

  // Special: moving items out of slot 0 (used for equipped clothing) should never swap into slot 0.
  // If the item is equipped clothing/prop/outfit, dragging it to an inventory slot means: unequip + move into inventory.
  if (fromItem.slot === 0) {
    const meta = parseMeta(fromItem.meta);

    // Unequip if needed
    if (meta && meta.equipped && (tplName.startsWith('clothes_') || tplName.startsWith('prop_') || tplName.startsWith('outfit_'))) {
      ensureBaseAppearance(player);

      if (tplName.startsWith('clothes_') && meta.c === undefined) {
        const mapped = componentFromClothesName(tplName);
        if (mapped !== null) meta.c = mapped;
      }

      if (tplName.startsWith('outfit_')) {
        // Restore base for all outfit parts
        const outfit = meta.outfit || {};
        const clothes = Array.isArray(outfit.clothes) ? outfit.clothes : [];
        const props = Array.isArray(outfit.props) ? outfit.props : [];
        for (const c of clothes) {
          if (!c) continue;
          const base = getBaseComponent(player, Number(c.c));
          applyComponent(player, Number(c.c), base.d, base.t);
        }
        for (const p of props) {
          if (!p) continue;
          const base = getBaseProp(player, Number(p.p));
          applyProp(player, Number(p.p), base.d, base.t);
        }
      } else if ((meta.kind === 'component' || meta.kind === 'accessory' || (!meta.kind && meta.c !== undefined)) && meta.c !== undefined) {
        const c = Number(meta.c);
        if (c === 11) {
          const shirtless = getShirtlessPreset();
          applyComponent(player, 11, shirtless[11].d, shirtless[11].t);
          applyComponent(player, 8,  shirtless[8].d,  shirtless[8].t);
          applyComponent(player, 3,  shirtless[3].d,  shirtless[3].t);
        } else if (c === 4) {
          const underwear = getUnderwearPreset(player);
          applyComponent(player, 4, underwear[4].d, underwear[4].t);
        } else if (meta.prev && meta.prev.d !== undefined) {
          applyComponent(player, c, meta.prev.d, meta.prev.t || 0);
        } else {
          const base = getBaseComponent(player, c);
          applyComponent(player, c, base.d, base.t);
        }
      } else if ((meta.kind === 'prop' || (!meta.kind && meta.p !== undefined)) && meta.p !== undefined) {
        const p = Number(meta.p);
        if (meta.prev && meta.prev.d !== undefined) {
          applyProp(player, p, meta.prev.d, meta.prev.t || 0);
        } else {
          const base = getBaseProp(player, p);
          applyProp(player, p, base.d, base.t);
        }
      }

      meta.equipped = false;
      fromItem.meta = stringifyMeta(meta);
    } else if (meta && meta.equipped && (isWeapon || isWeaponMeta || !tplName.startsWith('clothes_') && !tplName.startsWith('prop_') && !tplName.startsWith('outfit_'))) {
      if (tpl && isWeaponTemplate(tpl)) {
        const hash = weaponHashFromTemplate(tpl);
        try { player.removeWeapon(hash); } catch (_) {}
      } else {
        try { player.removeAllWeapons(); } catch (_) {}
      }
      meta.equipped = false;
      fromItem.meta = stringifyMeta(meta);
    }

    // Place into target slot if free, otherwise move the occupied item to a free slot.
    const occupied = await PlayerItem.findOne({ where: { owner_id: ownerId, slot: targetSlot } });
    if (occupied) {
      const freeSlot = await findFreeSlot(ownerId);
      if (!freeSlot) return;
      occupied.slot = freeSlot;
      await occupied.save();
    }
    fromItem.slot = targetSlot;
    await fromItem.save();
    return;
  }


  if (fromItem.slot === targetSlot) return;

  const toItem = await PlayerItem.findOne({ where: { owner_id: ownerId, slot: targetSlot } });

  if (!toItem) {
    fromItem.slot = targetSlot;
    await fromItem.save();
    return;
  }

  const tmp = fromItem.slot;
  fromItem.slot = toItem.slot;
  toItem.slot = tmp;
  await fromItem.save();
  await toItem.save();
}

async function unequipForMove(player, itemIdOrSlot) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return;

  const item = await findItemByIdOrSlot(ownerId, itemIdOrSlot);
  if (!item) return;

  const meta = parseMeta(item.meta);
  if (!meta || !meta.equipped) return;

  await useItem(player, item.id);
}

async function dropItemToWorld(player, idOrSlot) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return;

  const item = await findItemByIdOrSlot(ownerId, idOrSlot);
  if (!item) return;

  const tpl = await ItemTemplate.findByPk(item.item_template_id);
  if (tpl && isWeaponTemplate(tpl)) {
    const m = parseMeta(item.meta);
    if (m.equipped) {
      const hash = weaponHashFromTemplate(tpl);
      try { player.removeWeapon(hash); } catch (_) {}
      m.equipped = false;
      item.meta = stringifyMeta(m);
      await item.save();
    }
  }

  await item.destroy();
}

function getWorldItemStore() {
  const store = global.inventoryWorldItems || global.worldItems;
  if (!store || typeof store.get !== 'function' || typeof store.values !== 'function') return null;
  return store;
}

function getWorldItemPosition(worldItem) {
  if (!worldItem) return null;
  if (worldItem.position) return worldItem.position;
  if (worldItem.pos) return worldItem.pos;
  if (worldItem.coords) return worldItem.coords;
  return null;
}

async function listNearbyDrops(player, maxDistance = 4.0) {
  if (!player || !player.position) return [];
  const store = getWorldItemStore();
  if (!store) return [];

  const drops = [];
  for (const worldItem of store.values()) {
    if (!worldItem) continue;
    const pos = getWorldItemPosition(worldItem);
    if (!pos) continue;

    const dx = player.position.x - pos.x;
    const dy = player.position.y - pos.y;
    const dz = player.position.z - pos.z;
    const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (distance > maxDistance) continue;

    drops.push({
      id: worldItem.id,
      name: worldItem.templateName || worldItem.name || null,
      label: worldItem.label || null,
      amount: worldItem.amount || 1,
      distance,
      meta: worldItem.meta || null
    });
  }

  drops.sort((a, b) => a.distance - b.distance);
  return drops;
}

async function pickupWorldItem(player, worldId) {
  const ownerId = getOwnerId(player);
  if (!ownerId) throw new Error('ownerId missing');

  const id = parseInt(worldId, 10);
  if (!id) return false;

  const store = getWorldItemStore();
  if (!store) {
    throw new Error('World item store not configured');
  }

  const worldItem = store.get(id);
  if (!worldItem) return false;

  const tpl = await ItemTemplate.findOne({ where: { name: String(worldItem.templateName).toLowerCase() } });
  if (!tpl) throw new Error(`ItemTemplate not found: ${worldItem.templateName}`);

  const slot = await findFreeSlot(ownerId);
  if (!slot) throw new Error('Inventory full');

  await PlayerItem.create({
    owner_id: ownerId,
    item_template_id: tpl.id,
    amount: Math.max(1, parseInt(worldItem.amount, 10) || 1),
    slot,
    meta: worldItem.meta ? stringifyMeta(worldItem.meta) : null
  });

  store.delete(id);
  if (typeof worldItem.onPickup === 'function') {
    try { worldItem.onPickup(); } catch (_) {}
  }

  return true;
}

async function storeWeaponToInventory(player) {
  const ownerId = getOwnerId(player);
  if (!ownerId) throw new Error('ownerId missing');

  const weaponHash = Number(player.weapon) >>> 0;
  if (!weaponHash) return false;

  const templates = await ItemTemplate.findAll();
  let tpl = null;
  for (const t of templates) {
    if (!isWeaponTemplate(t)) continue;
    if ((mp.joaat(String(t.name).toLowerCase()) >>> 0) === weaponHash) { tpl = t; break; }
  }
  if (!tpl) throw new Error('No weapon template for current weapon');

  let item = await PlayerItem.findOne({ where: { owner_id: ownerId, item_template_id: tpl.id } });

  if (!item) {
    const slot = await findFreeSlot(ownerId);
    if (!slot) throw new Error('Inventory full');

    item = await PlayerItem.create({
      owner_id: ownerId,
      item_template_id: tpl.id,
      amount: 1,
      slot,
      meta: stringifyMeta({ equipped: false, ammo: 0 })
    });
  } else {
    const m = parseMeta(item.meta);
    m.equipped = false;
    if (m.ammo === undefined) m.ammo = 0;
    item.meta = stringifyMeta(m);
    await item.save();
  }

  try { player.removeWeapon(weaponHash); } catch (_) {}
  return true;
}

async function restoreWeaponsForPlayer(player) {
  await restoreEquippedWeapon(player);
  await restoreEquippedClothes(player);
}

async function useItem(player, itemIdOrSlot) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return;

  const n = parseInt(itemIdOrSlot, 10) || -1;

  const item = await PlayerItem.findOne({
    where: { owner_id: ownerId, id: n },
    include: [{ model: ItemTemplate, as: 'template' }]
  }) || await PlayerItem.findOne({
    where: { owner_id: ownerId, slot: n },
    include: [{ model: ItemTemplate, as: 'template' }]
  });

  if (!item || !item.template) return;

  // ---- Weapon equip/unequip (weapon slot) ----
  try {
    const techName = String(item.template.name || '').toLowerCase();
    if (techName.startsWith('weapon_')) {
      const meta = parseMeta(item.meta) || {};
      meta.kind = 'weapon';
      const hash = weaponHashFromTemplate(item.template);

      if (meta.equipped) {
        // Unequip: remove weapon and put item back into inventory
        try { player.removeWeapon(hash); } catch (_) {}
        meta.equipped = false;
        item.meta = stringifyMeta(meta);
        try { item.slot = await findFreeSlot(ownerId); } catch (_) { item.slot = item.slot || 1; }
        await item.save();
        return;
      } else {
        // Equip: keep only one equipped weapon
        const eq = await findEquippedWeaponItem(ownerId);
        if (eq && eq.id !== item.id) {
          const em = parseMeta(eq.meta) || {};
          em.kind = 'weapon';
          em.equipped = false;
          eq.meta = stringifyMeta(em);
          try { eq.slot = await findFreeSlot(ownerId); } catch (_) { eq.slot = eq.slot || 1; }
          await eq.save();
        }
        try { player.removeAllWeapons(); } catch (_) {}
        const ammo = (meta.ammo !== undefined) ? (parseInt(meta.ammo, 10) || 0) : 0;
        try { player.giveWeapon(hash, ammo); } catch (_) {}
        meta.equipped = true;
        item.meta = stringifyMeta(meta);
        item.slot = 0; // hide from inventory grid
        await item.save();
        return;
      }
    }
  } catch (_) {}

  const tplName = String(item.template.name || '').toLowerCase();

  // Medikit / Armor (100%)
  if (tplName === 'medikit') {
    player.health = 100;
    item.amount -= 1;
    if (item.amount <= 0) await item.destroy();
    else await item.save();
    return;
  }
  if (tplName === 'bodyarmor') {
    // Bodyarmor is treated as wearable (component 9) so it can be equipped/unequipped and be visible.
    // If it has no wearable meta yet, convert it to a default wearable vest.
    const meta = parseMeta(item.meta) || {};
    if (!(meta.kind === 'component' && meta.c !== undefined && Number(meta.c) === 9 && meta.d !== undefined)) {
      meta.kind = 'component';
      meta.c = 9;
      if (meta.d === undefined || meta.d === null) meta.d = 1; // default vest drawable
      if (meta.t === undefined || meta.t === null) meta.t = 0; // default texture
    }

    const equipped = !!meta.equipped;

    if (equipped) {
      // Unequip -> remove vest component and reset armor value
      // For component 9, restoring 'base' is unreliable if base was captured after equipping.
      // Desired behavior: vest disappears.
      applyComponent(player, 9, 0, 0);
      try { player.armour = 0; } catch (_) {}

meta.equipped = false;
      item.meta = stringifyMeta(meta);

      // Move back into a free inventory slot
      try { item.slot = await findFreeSlot(ownerId); } catch (_) { item.slot = item.slot || 1; }
      await item.save();
      return;
    }

    // Equip -> unequip any other component-9 item, then apply this one
    const equippedItems = await PlayerItem.findAll({
      where: { owner_id: ownerId },
      include: [{ model: ItemTemplate, as: 'template' }]
    });

    for (const it of equippedItems) {
      if (!it || !it.template || it.id === item.id) continue;
      const tn = String(it.template.name || it.name || '').toLowerCase();
      if (tn.startsWith('clothes_') || tn.startsWith('prop_') || tn === 'bodyarmor') {
        const m = parseMeta(it.meta);
        if (m && m.kind === 'component' && m.c !== undefined && Number(m.c) === 9 && !!m.equipped) {
          m.equipped = false;
          it.meta = stringifyMeta(m);
          // Put other equipped items back into inventory
          try { it.slot = await findFreeSlot(ownerId); } catch (_) {}
          await it.save();
        }
      }
    }

    // Store base appearance so we can restore on unequip
    if (!meta.base) {
      meta.base = captureCurrentAppearance(player);
    }

    // Apply vest + armor value
    applyComponent(player, 9, Number(meta.d) || 1, Number(meta.t) || 0);
    try { player.armour = 100; } catch (_) {}

    meta.equipped = true;
    item.meta = stringifyMeta(meta);

    // Hide from normal inventory (equipped slot)
    item.slot = 0;
    await item.save();
    return;
  }


  // Outfit item
  if (tplName.startsWith('outfit_')) {
    const meta = parseMeta(item.meta);
    const equipped = !!meta.equipped;
    const outfit = meta.outfit || {};
    const clothes = Array.isArray(outfit.clothes) ? outfit.clothes : [];
    const props = Array.isArray(outfit.props) ? outfit.props : [];

    if (equipped) {
      meta.equipped = false;
      item.meta = stringifyMeta(meta);

      // Put back into a free inventory slot (equipped items live in slot 0)
      try { item.slot = await findFreeSlot(ownerId); } catch (_) { item.slot = item.slot || 1; }

      await item.save();
      return;
    }

    // Unequip other outfits
    const all = await PlayerItem.findAll({
      where: { owner_id: ownerId },
      include: [{ model: ItemTemplate, as: 'template' }]
    });
    for (const it of all) {
      if (!it.template) continue;
      const name = String(it.template.name || '').toLowerCase();
      if (!name.startsWith('outfit_')) continue;
      const m = parseMeta(it.meta);
      if (m.equipped) {
        m.equipped = false;
        it.meta = stringifyMeta(m);
        await it.save();
      }
    }

    for (const cc of clothes) applyComponent(player, cc.c, cc.d, cc.t);
    for (const pp of props) applyProp(player, pp.p, pp.d, pp.t);

    meta.equipped = true;
    item.meta = stringifyMeta(meta);
    await item.save();
    return;
  }

  // Single clothing piece (components/props)
  if (tplName.startsWith('clothes_') || tplName.startsWith('prop_')) {
    const meta = parseMeta(item.meta);
    const equipped = !!meta.equipped;
    const mappedComponent = componentFromClothesName(tplName);
    if (tplName.startsWith('clothes_') && meta.c === undefined && mappedComponent !== null) {
      meta.c = mappedComponent;
    }

    if (equipped) {
      // Unequip -> apply BASE outfit (prevents default T-shirt etc.)
      ensureBaseAppearance(player);

      if ((meta.kind === 'component' || meta.kind === 'accessory' || (!meta.kind && meta.c !== undefined)) && meta.c !== undefined) {
        const c = Number(meta.c);

        // Special: Tops -> fully shirtless (also clears undershirt/torso)
        if (c === 11) {
          const shirtless = getShirtlessPreset();
          applyComponent(player, 11, shirtless[11].d, shirtless[11].t);
          applyComponent(player, 8,  shirtless[8].d,  shirtless[8].t);
          applyComponent(player, 3,  shirtless[3].d,  shirtless[3].t);
        } else if (c === 4) {
          const underwear = getUnderwearPreset(player);
          applyComponent(player, 4, underwear[4].d, underwear[4].t);
        } else if (meta.prev && meta.prev.d !== undefined) {
          applyComponent(player, c, meta.prev.d, meta.prev.t || 0);
        } else {
          const base = getBaseComponent(player, c);
          applyComponent(player, c, base.d, base.t);
        }
      } else if ((meta.kind === 'prop' || (!meta.kind && meta.p !== undefined)) && meta.p !== undefined) {
        const p = Number(meta.p);
        if (meta.prev && meta.prev.d !== undefined) {
          applyProp(player, p, meta.prev.d, meta.prev.t || 0);
        } else {
          const base = getBaseProp(player, p);
          applyProp(player, p, base.d, base.t);
        }
      }

      meta.equipped = false;
      item.meta = stringifyMeta(meta);
      // Put back into a free inventory slot (equipped items live in slot 0)
      try { item.slot = await findFreeSlot(ownerId); } catch (_) { item.slot = item.slot || 1; }

      await item.save();
      return;
    }

    // Unequip other items of same slot
    const all = await PlayerItem.findAll({
      where: { owner_id: ownerId },
      include: [{ model: ItemTemplate, as: 'template' }]
    });

    for (const it of all) {
      if (!it.template) continue;
      const name = String(it.template.name || '').toLowerCase();
      if (!(name.startsWith('clothes_') || name.startsWith('prop_'))) continue;

      const m = parseMeta(it.meta);
      if (!m.equipped) continue;

      if (meta.kind === 'component' && m.kind === 'component' && Number(m.c) === Number(meta.c)) {
        m.equipped = false;
        it.meta = stringifyMeta(m);
        await it.save();
      }
      if (meta.kind === 'prop' && m.kind === 'prop' && Number(m.p) === Number(meta.p)) {
        m.equipped = false;
        it.meta = stringifyMeta(m);
        await it.save();
      }
    }

    // Store current appearance so we can restore on unequip
    if (!meta.kind && tplName.startsWith('clothes_') && meta.c !== undefined) meta.kind = 'component';
    if (!meta.kind && tplName.startsWith('prop_') && meta.p !== undefined) meta.kind = 'prop';
    if (meta.kind === 'accessory') meta.kind = 'component';
    if (tplName.startsWith('clothes_') && meta.c === undefined) {
      if (meta.component !== undefined) meta.c = meta.component;
      if (meta.slot !== undefined) meta.c = meta.slot;
    }

    if (meta.kind === 'component' && meta.c !== undefined) {
      const cur = readCurrentComponent(player, meta.c);
      if (cur) meta.prev = cur;
      applyComponent(player, meta.c, meta.d, meta.t);
    } else if (meta.kind === 'prop' && meta.p !== undefined) {
      const cur = readCurrentProp(player, meta.p);
      if (cur) meta.prev = cur;
      applyProp(player, meta.p, meta.d, meta.t);
    }

    meta.equipped = true;
    item.meta = stringifyMeta(meta);

    // Equipped clothing lives in slot 0 so it doesn't appear in the normal inventory grid
    item.slot = 0;

    await item.save();
    return;
  }

  // Weapon equip
  if (isWeaponTemplate(item.template)) {
    const hash = weaponHashFromTemplate(item.template);
    const meta = parseMeta(item.meta);

    if (meta.equipped) {
      try { player.removeWeapon(hash); } catch (_) {}
      meta.equipped = false;
      item.meta = stringifyMeta(meta);
      await item.save();
      return;
    }

    const currentEquipped = await findEquippedWeaponItem(ownerId);
    if (currentEquipped && currentEquipped.id !== item.id) {
      const h = weaponHashFromTemplate(currentEquipped.template);
      try { player.removeWeapon(h); } catch (_) {}
      const m2 = parseMeta(currentEquipped.meta);
      m2.equipped = false;
      currentEquipped.meta = stringifyMeta(m2);
      await currentEquipped.save();
    }

    const ammo = (meta.ammo !== undefined) ? (parseInt(meta.ammo, 10) || 0) : 100;
    player.giveWeapon(hash, ammo);

    meta.equipped = true;
    meta.ammo = ammo;
    item.meta = stringifyMeta(meta);
    await item.save();
    return;
  }

  // Ammo item
  if (isAmmoTemplate(item.template)) {
    const weaponItem = await findEquippedWeaponItem(ownerId);
    if (!weaponItem) return;

    const wHash = weaponHashFromTemplate(weaponItem.template);
    const wMeta = parseMeta(weaponItem.meta);

    const take = Math.min(50, item.amount);
    if (take <= 0) return;

    const curAmmo = (wMeta.ammo !== undefined) ? (parseInt(wMeta.ammo, 10) || 0) : 0;
    const nextAmmo = curAmmo + take;

    item.amount -= take;
    if (item.amount <= 0) await item.destroy();
    else await item.save();

    try { player.removeWeapon(wHash); } catch (_) {}
    player.giveWeapon(wHash, nextAmmo);

    wMeta.ammo = nextAmmo;
    weaponItem.meta = stringifyMeta(wMeta);
    await weaponItem.save();
    return;
  }
}

async function splitItem(player, slot, amount) {
  const ownerId = getOwnerId(player);
  if (!ownerId) return;

  const s = parseInt(slot, 10) || -1;
  const item = await PlayerItem.findOne({ where: { owner_id: ownerId, slot: s } });
  const a = parseInt(amount, 10) || 0;
  if (!item || a <= 0 || item.amount <= a) return;

  const freeSlot = await findFreeSlot(ownerId);
  if (!freeSlot) return;

  item.amount -= a;
  await item.save();

  await PlayerItem.create({
    owner_id: ownerId,
    item_template_id: item.item_template_id,
    amount: a,
    slot: freeSlot,
    meta: item.meta
  });
}


async function giveCashToNearest(player, amount) {
  amount = Math.floor(Number(amount) || 0);
  if (amount <= 0) return false;

  const target = findNearestPlayer(player, 3.0);
  if (!target) {
    try { player.notify('Kein Spieler in der Nähe.'); } catch (_) {}
    return false;
  }

  const ok = money.takeCash(player, amount);
  if (!ok) {
    try { player.notify('Nicht genug Bargeld.'); } catch (_) {}
    return false;
  }

  // add cash to target
  const ch = target.character;
  if (ch) {
    if (ch.pocket_money !== undefined) ch.pocket_money = (Number(ch.pocket_money) || 0) + amount;
    else if (ch.cash !== undefined) ch.cash = (Number(ch.cash) || 0) + amount;
  }

  try { if (global.hudMoney?.syncCash) global.hudMoney.syncCash(player, player.character); } catch (_) {}
  try { if (global.hudMoney?.syncCash) global.hudMoney.syncCash(target, target.character); } catch (_) {}

  try { player.notify(`Du hast $${amount} gegeben.`); } catch (_) {}
  try { target.notify(`Du hast $${amount} erhalten.`); } catch (_) {}
  return true;
}

function findNearestPlayer(player, maxDist = 3.0) {
  let nearest = null;
  let best = maxDist;

  mp.players.forEach(p => {
    if (p === player) return;
    const dx = player.position.x - p.position.x;
    const dy = player.position.y - p.position.y;
    const dz = player.position.z - p.position.z;
    const d = Math.sqrt(dx*dx + dy*dy + dz*dz);
    if (d < best) { best = d; nearest = p; }
  });

  return nearest;
}

async function giveItemToPlayer(player, target, slot) {
  const ownerId = getOwnerId(player);
  const targetOwner = getOwnerId(target);
  if (!ownerId || !targetOwner) return;

  const s = parseInt(slot, 10) || -1;
  const item = await PlayerItem.findOne({ where: { owner_id: ownerId, slot: s } });
  if (!item) return;

  item.owner_id = targetOwner;
  item.slot = 1;
  await item.save();
}

async function addItemByTemplateName(player, templateName, amount = 1, metaObj = null) {
  const ownerId = getOwnerId(player);
  if (!ownerId) throw new Error('ownerId missing');

  const tpl = await ItemTemplate.findOne({ where: { name: String(templateName).toLowerCase() } });
  if (!tpl) throw new Error(`ItemTemplate not found: ${templateName}`);

  const slot = await findFreeSlot(ownerId);
  if (!slot) throw new Error('Inventory full');

  return PlayerItem.create({
    owner_id: ownerId,
    item_template_id: tpl.id,
    amount: Math.max(1, parseInt(amount, 10) || 1),
    slot,
    meta: metaObj ? stringifyMeta(metaObj) : null
  });
}

// Unequip an equipped item and move it into a specific inventory slot (if free).
// Used when dragging from equipment/clothing slot into a normal inventory slot.
async function unequipToSlot(player, itemId, targetSlot) {
  const ownerId = getOwnerId(player);
  if (!ownerId) throw new Error('ownerId missing');

  const item = await PlayerItem.findOne({ where: { owner_id: ownerId, id: itemId } });
  if (!item) return;

  const meta = parseMeta(item.meta) || {};

  // If equipped, toggle off via useItem (applies defaults and moves item back into inventory)
  if (meta.equipped) {
    await useItem(player, item.id);
  }

  const slot = parseInt(targetSlot, 10) || 1;

  // If requested slot is occupied, keep whatever slot useItem (or current) already set.
  const occupied = await PlayerItem.findOne({ where: { owner_id: ownerId, slot } });
  if (occupied) return;

  const fresh = await PlayerItem.findOne({ where: { owner_id: ownerId, id: item.id } });
  if (!fresh) return;

  fresh.slot = slot;
  await fresh.save();
}

module.exports = {
  MAX_SLOTS,
  getOwnerId,
  getInventoryByOwner,
  getInventoryWeight,
  getMaxWeight,
  moveItem,
  dropItemToWorld,
  listNearbyDrops,
  pickupWorldItem,
  storeWeaponToInventory,
  restoreEquippedWeapon,
  restoreEquippedClothes,
  restoreWeaponsForPlayer,
  useItem,
  unequipForMove,
  splitItem,
  findNearestPlayer,
  giveItemToPlayer,
  addItemByTemplateName,
  giveCashToNearest,
  unequipToSlot
};