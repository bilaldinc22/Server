'use strict';

const { DataTypes } = require('sequelize');
const sequelize = global.sequelize; // set in packages/Gamemode/sequelize.js

const ItemTemplate = require('../models/ItemTemplate');

const PlayerItem = sequelize.define('rp_player_items', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        primaryKey: true,
        autoIncrement: true
    },
    owner_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
    },
    item_template_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
    },
    amount: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 1
    },
    slot: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    meta: {
        type: DataTypes.TEXT('long'),
        allowNull: true
    }
}, {
    tableName: 'rp_player_items',
    timestamps: false
});

// 🔴 EXTREM WICHTIG: Relation korrekt
PlayerItem.belongsTo(ItemTemplate, {
    as: 'template',
    foreignKey: 'item_template_id'
});

module.exports = PlayerItem;
