'use strict';

const service = require('./inventory.service');
const logger = require('../Logger/discord');

function isInventoryBlocked(player) {
    // Serverseitige Gaben (Shop, Admin, Scripts) dürfen immer durch
    if (player._serverGiveItem) return false;

    // Normale Schutzlogik bleibt erhalten
    if (player.isInMenu) return true;
    if (player.inventoryBlocked) return true;

    return false;
}

async function buildPayload(player) {
    const ownerId = service.getOwnerId(player);
    if (!ownerId) {
        return {
            items: [],
            maxSlots: service.MAX_SLOTS,
            weight: 0,
            maxWeight: service.getMaxWeight(player),
            drops: []
        };
    }

    const rows = await service.getInventoryByOwner(ownerId);
    const items = rows.map(r => ({
        id: r.id,
        slot: r.slot,
        amount: r.amount,
        meta:(()=>{if(!r.meta)return {};if(typeof r.meta==='object')return r.meta;try{return JSON.parse(String(r.meta));}catch{return {};}})(),
        template: {
            id: r.template.id,
            name: String(r.template.name || '').toLowerCase(),
            label: r.template.label || null,
            type: r.template.type || 'item',
            icon: r.template.icon || null,
            max_stack: r.template.max_stack || 1,
            weight: r.template.weight || 1
        }
    }));

    let weight = 0;
    try { weight = await service.getInventoryWeight(ownerId); } catch (e) {}

    let drops = [];
    try { drops = await service.listNearbyDrops(player); } catch (e) {}

    return {
        items,
        maxSlots: service.MAX_SLOTS,
        weight,
        maxWeight: service.getMaxWeight(player),
        drops
    };
}

async function sendInventory(player) {
    if (isInventoryBlocked(player)) return;
    const payload = await buildPayload(player);
    player.call('CLIENT::INVENTORY:SET_DATA', [JSON.stringify(payload), payload.maxSlots]);
}

mp.events.add('SERVER::INVENTORY:REQUEST', async (player) => {
    try { await sendInventory(player); }
    catch (e) { console.log('[INV] REQUEST ERROR', e); logger.serverlog('INVENTORY REQUEST ERROR: ' + e); }
});

mp.events.add('SERVER::INVENTORY:USE', async (player, itemId) => {
    if (isInventoryBlocked(player)) return;
    if (player._invIgnoreUseFor && Number(player._invIgnoreUseFor) === Number(itemId)) return;
    try { await service.useItem(player, itemId); await sendInventory(player); }
    catch (e) { console.log('[INV] USE ERROR', e); logger.serverlog('INVENTORY USE ERROR: ' + e); }
});

mp.events.add('SERVER::INVENTORY:MOVE', async (player, itemId, newSlot) => {
    if (isInventoryBlocked(player)) return;
    try {
        player._invIgnoreUseFor = Number(itemId);
        setTimeout(() => { if (player) player._invIgnoreUseFor = null; }, 500);
        await service.unequipForMove(player, itemId);
        await service.moveItem(player, itemId, newSlot);
        await sendInventory(player);
    }
    catch (e) { console.log('[INV] MOVE ERROR', e); logger.serverlog('INVENTORY MOVE ERROR: ' + e); }
});

mp.events.add('SERVER::INVENTORY:UNEQUIP_TO_SLOT', async (player, itemId, targetSlot) => {
    if (isInventoryBlocked(player)) return;
    try { await service.unequipToSlot(player, itemId, targetSlot); await sendInventory(player); }
    catch (e) { console.log('[INV] UNEQUIP_TO_SLOT ERROR', e); logger.serverlog('INVENTORY UNEQUIP_TO_SLOT ERROR: ' + e); }
});

mp.events.add('SERVER::INVENTORY:SPLIT', async (player, itemId, amount) => {
    if (isInventoryBlocked(player)) return;
    try { await service.splitItem(player, itemId, amount); await sendInventory(player); }
    catch (e) { console.log('[INV] SPLIT ERROR', e); logger.serverlog('INVENTORY SPLIT ERROR: ' + e); }
});

mp.events.add('SERVER::INVENTORY:DROP', async (player, itemId, amount) => {
    if (isInventoryBlocked(player)) return;
    try { await service.dropItemToWorld(player, itemId, amount); await sendInventory(player); }
    catch (e) { console.log('[INV] DROP ERROR', e); logger.serverlog('INVENTORY DROP ERROR: ' + e); }
});

mp.events.add('SERVER::INVENTORY:NEAR_DROPS', async (player) => {
    try { await sendInventory(player); } catch (e) {}
});

mp.events.add('SERVER::INVENTORY:PICKUP', async (player, worldItemId) => {
    if (isInventoryBlocked(player)) return;
    try { await service.pickupWorldItem(player, worldItemId); await sendInventory(player); }
    catch (e) { console.log('[INV] PICKUP ERROR', e); logger.serverlog('INVENTORY PICKUP ERROR: ' + e); }
});

mp.events.add('SERVER::INVENTORY:GIVE', async (player, targetStr, itemId, amount) => {
    if (isInventoryBlocked(player)) return;
    try {
        let target = service.findNearestPlayer(player, 3.0);
        if (!target) { player.outputChatBox('Kein Zielspieler in der Nähe gefunden.'); return; }
        const ok = await service.giveItemToPlayer(player, target, itemId, amount);
        if (!ok) { player.outputChatBox('Konnte Item nicht geben.'); return; }
        await sendInventory(player);
        await sendInventory(target);
    } catch (e) { console.log('[INV] GIVE ERROR', e); }
});


mp.events.add('SERVER::INVENTORY:GIVE_CASH', async (player, amount) => {
  try {
    await service.giveCashToNearest(player, amount);
  } catch (e) {
    try { console.log('[INV] GIVE_CASH ERROR', e); } catch (_) {}
  }
});

mp.events.add('SERVER::INVENTORY:STORE_WEAPON', async (player, templateName, weaponHash, ammo) => {
    if (isInventoryBlocked(player)) return;
    try {
        const ok = await service.storeWeaponToInventory(
            player,
            String(templateName || ''),
            parseInt(weaponHash),
            parseInt(ammo)
        );
        if (!ok) return;
        await sendInventory(player);
    } catch (e) {
        console.log('[INV] STORE_WEAPON ERROR', e);
        logger.serverlog('INVENTORY STORE_WEAPON ERROR: ' + e);
    }
});

async function restoreWithRetry(player, tries = 10) {
    for (let i = 0; i < tries; i++) {
        try {
            if (service.getOwnerId(player)) {
                await service.restoreWeaponsForPlayer(player);
                return;
            }
        } catch (e) {}
        await new Promise(r => setTimeout(r, 500));
    }
}

mp.events.add('playerSpawn', (player) => { restoreWithRetry(player, 10); });
mp.events.add('playerReady', (player) => { restoreWithRetry(player, 10); });

module.exports = { sendInventory };