module.exports = {
    weapon_pistol: mp.joaat('weapon_pistol'),
    weapon_combatpistol: mp.joaat('weapon_combatpistol'),
    weapon_smg: mp.joaat('weapon_smg'),
    weapon_microsmg: mp.joaat('weapon_microsmg'),
    weapon_assaultrifle: mp.joaat('weapon_assaultrifle'),
    weapon_carbinerifle: mp.joaat('weapon_carbinerifle'),
    weapon_pumpshotgun: mp.joaat('weapon_pumpshotgun'),
    weapon_sniperrifle: mp.joaat('weapon_sniperrifle'),
    weapon_knife: mp.joaat('weapon_knife'),
    weapon_bat: mp.joaat('weapon_bat')
};