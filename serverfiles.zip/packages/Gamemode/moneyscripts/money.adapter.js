function getCash(player) {
  const ch = player.character;
  return Number(ch?.pocket_money ?? ch?.cash ?? 0) || 0;
}

async function takeCash(player, amount) {
  amount = Number(amount) || 0;
  if (amount <= 0) return true;

  const ch = player.character;
  if (!ch) return false;

  const cur = getCash(player);
  if (cur < amount) return false;

  if (ch.pocket_money !== undefined) ch.pocket_money = cur - amount;
  else if (ch.cash !== undefined) ch.cash = cur - amount;
  else return false;

  await ch.save();

  // optional: falls du moneyhud sync hast
  try { if (global.hudMoney?.syncCash) global.hudMoney.syncCash(player, ch); } catch {}
  return true;
}

module.exports = { getCash, takeCash };