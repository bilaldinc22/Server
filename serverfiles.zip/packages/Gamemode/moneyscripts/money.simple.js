async function takeCash(player, amount) {
  amount = Number(amount) || 0;
  if (amount <= 0) return true;

  const ch = player.character;
  if (!ch) return false;

  // unterstütze beide Varianten
  const hasPocket = ch.pocket_money !== undefined;
  const hasCash = ch.cash !== undefined;

  const cur = Number(hasPocket ? ch.pocket_money : (hasCash ? ch.cash : 0)) || 0;
  if (cur < amount) return false;

  if (hasPocket) ch.pocket_money = cur - amount;
  else if (hasCash) ch.cash = cur - amount;

  await ch.save();

  // optional: wenn du moneyhud sync hast, kannst du hier deinen existing sync callen
  // z.B. player.call("moneyhud:update", [ch.pocket_money]) etc.

  return true;
}

module.exports = { takeCash };