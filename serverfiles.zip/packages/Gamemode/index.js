require('./sequelize');


//A
require("./Authorization/authorization");
require("./admin/AdminActions");
require("./admin/AdminLogger");
require("./admin/AdminPermissions");
require("./admin/AdminUtil");
require("./admin/index");
require("./admin/permissions");
require("./admin/db/BanRepository");
require("./admin/db/AdminSpawnedVehicle.model");
require("./admin/db/AdminSpawnedVehicleRepository");
require("./admin/db/Ban.model");
require("./dbid_autofix.js");
require('./admin/giveveh');
require('./admin/admin.commands');
require("./appearance_persistence");
require("./AirportRental/rental");
//B
require("./Bank/bank");
require("./Bank/atm");

//C
require("./Character/character");
require("./colors");
require("./clothesshop/index");


//F
require("./Factions/factions");
require("./Factions/pd");

//H
require("./hairshop/index");
require("./Hud/moneyhud");

//I;
require("./Inventory/item");
require('./Inventory/inventory.controller');
require('./Inventory/inventory.service');
require('./Inventory/inventory.use');
require('./Inventory/useItem.clothing');
require('./Inventory/weapon.map');
require('./Inventory/weapon.persistence');
require('./Inventory/weapon.tracker');

//M
require("./moneyscripts/money.simple");

// P
require("./Player/chat");
require("./Player/commands");
require("./Player/death");
require("./PropertySystem/house")
require('./persistence');


//U
require("./updatePlayer");

//V
require("./VOIP/voiceChat");

//W
require("./weaponshop/index");
require('./weapon/weapon_persistence_fix');
require("./weapon/1weaponcomponents/index");





