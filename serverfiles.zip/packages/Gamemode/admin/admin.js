const whitelist = require('../models/whitelist.model');
const accounts = require('../models/account.model');
const banned = require('../models/ban.model');
const character = require('../models/character.model');
const characterjs = require('../Character/character');
const logger = require('../Logger/discord');

// const admins



// Set admin 

mp.events.addCommand('admins', (player) => {
    mp.players.forEachFast((target) => {
        if(target.getVariable('admin') > 0) {
            player.outputChatBox(`${lightred} [ADMIN] ${target.getVariable('username')} ${green} ON DUTY`);
        } 
    });
});

mp.events.addCommand('a', (player, _, ...text) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error: You are not an admin`);
    if(admin > 0) {
        if(!text) return player.outputChatBox(`syntax : /a text`);
        text = text.join(' ');
        mp.players.forEachFast((getplayer) => {
            if(getplayer.getVariable('admin') > 0) {
                getplayer.outputChatBox(`${lightred} ${player.getVariable('username')} ${white} [${player.id}] Rank [${player.getVariable('adminRank')}]: ${text}`);
            }
        });
    }
});

mp.events.addCommand('askin', async (player, _, skinName) => {
    try
    {
        const admin = player.getVariable('admin');
        if(!admin) return player.outputChatBox(`Error this command is for admins only!`);
        player.model = mp.joaat(`${skinName}`);
        const change = await accounts.findOne({ where: { username: player.getVariable("username")}});
        if(change)
        {
            change.update({ admin_skin: skinName });
            player.outputChatBox(`Successfully Updated Your Admin Skin`);
        }
    }
    catch(err)
    {
        logger.serverLog(`${err}`)
    }
});

mp.events.addCommand('mod', (player, _, modType , modIndex) => {
	if(!player.vehicle) return player.outputChatBox("You need to be in a vehicle to use this command.");
    if(isNaN(modType) || isNaN(modIndex)) return player.outputChatBox(`Please define mod type and index , /mod type index`);
	player.vehicle.setMod(parseInt(modType), parseInt(modIndex));
	player.outputChatBox(`Mod Type ${modType} with Mod Index ${modIndex} applied.`);
});

mp.events.addCommand('aduty', async (player) => {
    try
    {
        const adminPerms = player.getVariable('adminPerms');
        if(!adminPerms) return player.outputChatBox(`Error : You are not an admin`);
        const adminRank = player.getVariable('adminRank');
        const playingCharacter = player.getVariable("playingCharacter");
        const adminDuty = player.getVariable('adminDuty');
    
        if(adminDuty == false) {
    
    
            
            player.setVariable('admin', adminRank);
            player.setVariable('adminDuty', true);
            player.outputChatBox(`${green} You are on duty now! Admin Level : ${player.getVariable('admin')}`);
      
            const heading = player.heading;
            player.model = mp.joaat(`${player.getVariable('admin_skin')}`);
            player.heading = heading;
            logger.sendLog('admin_logs', `${player.getVariable("username")} is on duty now!`);
    
        } else {
    
            if(!adminRank) return player.outputChatBox(`Error : You have not been assigned with an admin rank yet`);
            player.setVariable('admin', null);
            player.setVariable('adminDuty', false);
    
            player.outputChatBox(`${darkred} You are off duty now!`);
    
            characterjs.setApearance(player, playingCharacter);
            logger.sendLog('admin_logs', `${player.getVariable("username")} is off duty now!`);
        }

    }
    catch(err)
    {
        logger.serverLog(`${err}`)
    }
});


mp.events.addCommand('setadmin', async (player, _, id, rank) => {
    try {

    const admin = player.getVariable('admin');
    const adminName = player.getVariable('username');

    if(!admin) return player.outputChatBox(`Error: You are not an admin`);
    if(admin < 3) return player.outputChatBox(`Error: This command is only for admin lvl 3`);
    if(isNaN(id) || isNaN(rank)) return player.outputChatBox(`Syntax : /setadmin playerid ranknumber[1-3]`);
    
    const findplayer = mp.players.at(parseInt(id));
    if(!findplayer) return player.outputChatBox(`Player not found`);

    

        const targerusername = findplayer.getVariable('username');

        const checkaccount = await accounts.findOne({ where: { username: targerusername }});
        if(!checkaccount) return player.outputChatBox(`None of the accounts found for player id : ${id}`);
        if(checkaccount.admin == rank) return player.outputChatBox(`Error: This player is already an admin with the rank ${rank}`);

        const setadmin = await checkaccount.update({ admin: rank });
        if(!setadmin) return player.outputChatBox(`Error While setting player admin, retry!`);


        findplayer.setVariable('admin', rank);
        findplayer.setVariable('adminPerms', true);

        player.outputChatBox(`Successfully set player ${id} as an admin`);
        logger.sendLog(`admin_logs`, `${player.getVariable("username")} has set player ${targerusername} as an admin! with rank ${rank}`);


    } catch (err) {
        logger.serverLog(`${err}`);
    }
});


mp.events.addCommand('settime', (player, _, hour) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You are not an admin`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);
    if(isNaN(hour)) return player.outputChatBox(`Syntax : /settime hour`);
    mp.world.time.set(hour, 0, 0);
});

mp.events.addCommand('checkweather', (player) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 3) return player.outputChatBox(`Error : This command is only for Administrator`);

    const weather = mp.world.weather;
    if(weather) {
        player.outputChatBox(`Weather currently is ${weather}`);
        logger.sendLog('admin_logs', `${player.getVariable("username")} Used the command /checkweather`);
    }
});

mp.events.addCommand('setweather', (player, _, id) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    if(!id || isNaN(id)) return player.outputChatBox(`Syntax : /setweather ID`);
    
    switch(parseInt(id)) {

        case 0: 
        {
            mp.world.weather = 'EXTRASUNNY';
            player.outputChatBox(`You set the weather as EXTRASUNNY`);
            break;
        }

        case 1: 
        {
            mp.world.weather = 'CLEAR';
            player.outputChatBox(`You set the weather as CLEAR`);
            break;
        }

        case 2: 
        {
            mp.world.weather = 'CLOUDS';
            player.outputChatBox(`You set the weather as CLOUDS`);
            break;
        }

        case 3: 
        {
            mp.world.weather = 'SMOG';
            player.outputChatBox(`You set the weather as SMOG`);
            break;
        }

        case 4: 
        {
            mp.world.weather = 'FOGGY';
            player.outputChatBox(`You set the weather as FOGGY`);
            break;
        }

        case 5: 
        {
            mp.world.weather = 'OVERCAST';
            player.outputChatBox(`You set the weather as OVERCAST`);
            break;
        }

        case 6: 
        {
            mp.world.weather = 'RAIN';
            player.outputChatBox(`You set the weather as RAIN`);
            break;
        }

        case 7: 
        {
            mp.world.weather = 'THUNDER';
            player.outputChatBox(`You set the weather as THUNDER`);
            break;
        }

        case 8: 
        {
            mp.world.weather = 'CLEARING';
            player.outputChatBox(`You set the weather as CLEARING`);
            break;
        }

        case 9: 
        {
            mp.world.weather = 'NEUTRAL';
            player.outputChatBox(`You set the weather as NEUTRAL`);
            break;
        }

        case 10: 
        {
            mp.world.weather = 'SNOW';
            player.outputChatBox(`You set the weather as SNOW`);
            break;
        }

        case 11: 
        {
            mp.world.weather = 'BLIZZARD';
            player.outputChatBox(`You set the weather as BLIZZARD`);
            break;
        }

        case 12: 
        {
            mp.world.weather = 'SNOWLIGHT';
            player.outputChatBox(`You set the weather as SNOWLIGHT`);
            break;
        }

        case 13: 
        {
            mp.world.weather = 'XMAS';
            player.outputChatBox(`You set the weather as XMAS`);
            break;
        }

        case 14: 
        {
            mp.world.weather = 'HALLOWEEN';
            player.outputChatBox(`You set the weather as HALLOWEEN`);
            break;
        }

        default: 
        {
            player.outputChatBox(`Invalid ID Entered type an ID between 0-14`);
            break;
        }

    }
    logger.sendLog('admin_logs', `${player.getVariable("username")} Changed the weather to ID ${id}`);
    return;
});


mp.events.addCommand("awep", (player) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 3) return player.outputChatBox(`Error : This command is only for Administrator`);

        player.giveWeapon([3220176749, 2210333304], 1000); // Assault Rifle, Carbine Rifle
        player.giveWeapon([324215364, -619010992], 1000); // Micro Smg , Machine pistol
        player.giveWeapon([-1660422300, 487013001], 1000); // Machine gun , shotgun
        player.giveWeapon([-1716589765, -771403250], 1000); // pistols

    logger.sendLog('admin_logs', `${player.getVariable("username")} Used the command /awep`);
    return;
  });

  mp.events.addCommand("givewep", (player, _, id) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 3) return player.outputChatBox(`Error : This command is only for Administrator`);
    if(isNaN(id)) return player.outputChatBox(`/givewep id`);
    const target = mp.players.at(id);
    if(!target) return;
    target.giveWeapon([3220176749, 2210333304], 1000); // Assault Rifle, Carbine Rifle
    target.giveWeapon([324215364, -619010992], 1000); // Micro Smg , Machine pistol
    target.giveWeapon([-1660422300, 487013001], 1000); // Machine gun , shotgun
    target.giveWeapon([-1716589765, -771403250], 1000); // pistols

    logger.sendLog('admin_logs', `${player.getVariable("username")} Used the command /givewep to player ${target.getVariable('playingCharacter')}`);
    return;
  });

  mp.events.addCommand('aspawn', (player, _, name, color1, color2, plate) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 3) return player.outputChatBox(`Error : This command is only for Administrator`);

    if (!name || isNaN(color1) || isNaN(color2) || !plate) return player.outputChatBox(`Syntax : /aspawn vehicleName color1 color2 plate`);


    let pos = player.position;
    pos.x += 2;
  
    veh = mp.vehicles.new(mp.joaat(name), pos, {
    numberPlate: plate
    });
    veh.setColor(Number(color1), Number(color2));
    veh.setVariable('veh_fuel', 100);
    player.putIntoVehicle(veh, 0);
    player.outputChatBox(`${green} [Success]${white} Created a temp vehicle ${lightred} ${name}`);
    logger.sendLog('admin_logs', `${player.getVariable("username")} Spawned vehicle ${name} with plate ${plate}`);
    return;
  });
  
  mp.events.addCommand('setfuel', (player, _, fuel) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Administrator`);

    if(!player.vehicle) return player.outputChatBox(`Error : You are not inside a vehicle`);
    const vehicle = player.vehicle;
    if(!fuel || isNaN(fuel)) return player.outputChatBox(`Syntax : /setfuel number`);
    vehicle.setVariable('veh_fuel', fuel);
    player.outputChatBox(`You successfully set fuel for this vehicle, temprorly`);
  });
  

mp.events.addCommand('afix', (player) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    if (player.vehicle) {
        player.vehicle.repair();
        player.outputChatBox(`${green}[Success] ${white} Vehicle Repair 100%`);
    } 
});


mp.events.addCommand('adelete', (player) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

        if (player.vehicle) {
            player.vehicle.destroy();
            player.outputChatBox(`${green} [Success] ${white} Vehicle deleted temprory`);
        } 
});

mp.events.addCommand("tp", (player, _, id) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    if(!id || isNaN(id)) return player.outputChatBox(`Syntax : /tp [id]`);

    const target = mp.players.at(id);
    if(!target) return player.outputChatBox(`Player not found`);

    target.outputChatBox(`${lightred}[ADMIN] ${white} ${player.getVariable('username')} has teleported to you!`);
    player.outputChatBox(`${green}[Success] ${white} You teleported to player ${target.getVariable('playingCharacter')}`);

    player.spawn(new mp.Vector3(target.position.x, target.position.y, target.position.z));
});

mp.events.addCommand("bring", (player, _, id) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    if(!id || isNaN(id)) return player.outputChatBox(`Syntax : /bring [id]`);

    const target = mp.players.at(id);
    if(!target) return player.outputChatBox(`Player not found`);

    target.outputChatBox(`${lightred}[ADMIN] ${white} ${player.getVariable('username')} teleported you to their position`);
    player.outputChatBox(`${green}[Success] ${white} You brought player ${target.getVariable('playingCharacter')}`);

    target.spawn(new mp.Vector3(player.position.x, player.position.y, player.position.z));
});


mp.events.addCommand('adeleteall', (player) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 3) return player.outputChatBox(`Error : This command is only for Administrator`);

    mp.vehicles.forEach((vehicle) => {
        if(!vehicle.getVariable('veh_id')) {
            vehicle.destroy();
        } else {
            return;
        }
    });
    player.outputChatBox(`${green} [Success] ${white} You deleted all the temp vehiles`);
});



mp.events.addCommand("kick", (player, _, id, ...reason) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    if (isNaN(id) || !reason) return player.outputChatBox(`Error use valid syntax : /kick id reason`);
    reason = reason.join(' ');

    let target = mp.players.at(id);
    if (!target) return player.outputChatBox(`Error: Can not find player`);

    mp.players.broadcast(`${lightred}[KICK] ${white} Player : ${pink} ${target.getVariable('playingCharacter')} ${white} was kicked from the server. Reason : ${reason}`);
    target.kick();

});

mp.events.addCommand("ban", async (player, _, id, ...reason) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    if (isNaN(id) || !reason) return player.outputChatBox(`Error use valid syntax : /ban id reason`);
    reason = reason.join(' ');

      let target = mp.players.at(id);
      if (!target) return player.outputChatBox(`Error: Can not find player`);

        const SRPID = target.getVariable('SRPID');
        const username = target.getVariable('username');

        try {
            const ban = await banned.create({ SRPID: SRPID, username: username, ipaddress: player.ip, socialclub: player.socialClub, banreason: reason });
            if(!ban) return player.outputChatBox(`Error : Could not ban the player! Try again`);
            player.outputChatBox(`Player Banned Successfully! Account username ${username}`);
            mp.players.broadcast(`${lightred}[BAN] ${white} Player : ${pink} ${target.getVariable('playingCharacter')} ${white} was banned from the server. Reason : ${reason}`);
            target.kick();
            logger.sendLog('admin_logs', `${player.getVariable("username")} has banned account ${username}`);

            } catch (err) {
                logger.serverLog(`${err}`);
        }
});


mp.events.addCommand("unban", async (player, _, username) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    if (!username) return player.outputChatBox(`Error use valid syntax : /ban accountname`);

        try {
                const findban = await banned.findOne({ where: { username: username }});
                if(!findban) return player.outputChatBox(`Could not find a player with that accountname`);
                findban.destroy();
                player.outputChatBox(`Successfully unbanned account ${username}`);
                logger.sendLog('admin_logs', `${player.getVariable("username")} has unbanned account ${username}`);
            } catch (err) {
                logger.serverLog(`${err}`);
        }
});

// finish

//smoke commands addCommand
mp.events.addCommand("adminhelp", (player) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    player.outputChatBox("Admin Commands List available at : https://bit.ly/3LaqNpc");

});
/*
mp.events.addCommand("invis", (player) => {
    player.call("CLIENT::INVIS", [player]);
    logger.sendLog(player, 'admin_logs', `used command /invis`);
});
*/
mp.events.addCommand('akill', (player, _, id, reason) => {

    const admin = player.getVariable('admin');
    const adminName = player.getVariable('username');

    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 3) return player.outputChatBox(`Error : This command is only for Administrator`);

    if(!id || isNaN(id) || !reason) return player.outputChatBox(`Syntax : /akill id reason`);
    const target = mp.players.at(id);
    if(!target) return player.outputChatBox(`Player not found`);

    target.health = 0;
    target.outputChatBox(`You were killed by Admin ${lightred} ${adminName}`);
    player.outputChatBox(`You killed player ${lightred} ${target.getVariable('playingCharacter')}`);
    logger.sendLog('admin_logs', `${player.getVariable("username")} used command /akill to kill player : ${target.getVariable('playingCharacter')} ID : ${target.id}`);
});  
    
mp.events.addCommand('rev', (player, _, id) => {
    const admin = player.getVariable('admin');
    const adminName = player.getVariable('username');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    if(!id || isNaN(id)) return player.outputChatBox(`Syntax : /rev id`);

    const target = mp.players.at(id);
    if(!target) return player.outputChatBox(`Player not found!`);

    target.health = 100;
    target.call('CLIENT::NOT:INJURED');
    target.spawn(new mp.Vector3(target.position.x, target.position.y, target.position.z));
    target.outputChatBox(`${lightred}[Revive] ${white} you got revived by admin ${adminName}`);
    player.outputChatBox(`${green}[Success] ${white} You revived ${target.getVariable('playingCharacter')} Successfully`);
    logger.sendLog('admin_logs', `${player.getVariable("username")} used command /rev to revive player ${target.getVariable('playingCharacter')} ID : ${target.id}`)

});

mp.events.addCommand('aheal', (player, _, id) => {
    const admin = player.getVariable('admin');
    const adminName = player.getVariable('username');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    if(!id || isNaN(id)) return player.outputChatBox(`Syntax : /heal id`);

    
    const target = mp.players.at(id);
    if(!target) return player.outputChatBox(`Player not found!`);

    target.health = 100;
    target.outputChatBox(`You got healed by admin ${adminName}`);
    player.outputChatBox(`You Successfully healed player ${target.getVariable('playingCharacter')}`);
    logger.sendLog('admin_logs', `${player.getVariable("username")} healed player ${target.getVariable('playingCharacter')}`);

});


mp.events.addCommand("getpos", (player) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    player.outputChatBox(`Your Position is ${player.position} Heading : ${player.heading}`);
    logger.sendLog('admin_logs', `${player.getVariable("username")} used command /getpos and position got is ${player.position} Heading : ${player.heading}`);
});

mp.events.addCommand("gotopos", (player, _, x, y, z) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);
    if(isNaN(x) || isNaN(y) || isNaN(z)) return player.outputChatBox(`Syntax : /gotopos x y z`);
    player.position = new mp.Vector3(x, y, z);
    player.outputChatBox(`You successfully teleported to position x: ${x} y : ${y} z : ${z}`);
    logger.sendLog('admin_logs', `${player.getVariable("username")} used command /gotopos x: ${x} y: ${y} z: ${z}`);
});


mp.events.addCommand("unbug", (player, _, id) => {

    const admin = player.getVariable('admin');
    const adminName = player.getVariable('username');
    if(!admin) return player.outputChatBox(`Error : You can not use admin commands`);
    if(admin < 2) return player.outputChatBox(`Error : This command is only for Mod+`);

    if(!id || isNaN(id)) return player.outputChatBox(`Syntax : /unbug id`);
    const target = mp.players.at(id);
    if(!target) return player.outputChatBox(`Player not found`);

    target.spawn(new mp.Vector3(player.position.x, player.position.y, player.position.z));
    target.health = 100;
    target.dimension = 0;
    target.outputChatBox(`You were unbugged by Admin ${adminName}`);
    player.outputChatBox(`You unbugged player : ${target.getVariable('playingCharacter')}`);
    logger.sendLog('admin_logs', `${player.getVariable("username")} used /unbug ${id} unbugged player : ${target.getVariable('playingCharacter')}`)
        
});

/*
// no clipping // needs fix later 
 mp.events.addCommand('fly', (player) => {
    let admin = player.getVariable('admin');
    if(admin > 0) {
        player.call('client:noClipStart');
    }
 });
 */


 mp.events.addCommand('whitelist', async (player, _, sc) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error: This command is for admins only!`);
    if(admin < 3) return player.outputChatBox(`Error : Only Admin Lvl 3 can use this command!`);

    if(!sc) return player.outputChatBox(`Syntax : /whitelist socialclub`);
    try
    {
        const findold = await whitelist.findOne({ where: { socialclub: sc }});
        if(findold) return player.outputChatBox(`Whitelist Already Exists with Social Club : ${sc}`);

        const create = await whitelist.create({ socialclub: sc });
        if(create) return player.outputChatBox(`Whitelist Added : ${sc}`);

    }
    catch(err)
    {
        logger.serverLog(`Can not whitelist : ${err}`);
    }

 });

 mp.events.addCommand('removewhitelist', async (player, _, sc) => {

    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error: This command is for admins only!`);
    if(admin < 3) return player.outputChatBox(`Error : Only Admin Lvl 3 can use this command!`);

    if(!sc) return player.outputChatBox(`Syntax : /removewhitelist socialclub`);

    try
    {
        const findold = await whitelist.findOne({ where: { socialclub: sc }});
        if(findold) findold.destroy();

        player.outputChatBox(`Successfully Removed Whitelist from Socialclub : ${sc}`);

    }
    catch(err)
    {
        logger.serverLog(`Can not whitelist : ${err}`);
    }

 });

 mp.events.addCommand("coords", (player) => {
    console.log(player.position + ' heading : ' + player.heading);
 });    

 