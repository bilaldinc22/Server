let AdminLog = null;
try {
  AdminLog = require("./db/AdminLog.model");
} catch (e) {
  AdminLog = null;
}

module.exports = {
  log(admin, action, targetPlayer = null, infoObj = null) {
    const adminName = admin?.name || "CONSOLE";
    const adminSc = admin?.socialClub || null;
    const adminId = Number.isInteger(admin?.id) ? admin.id : null;

    let targetName = null;
    let targetSc = null;
    let targetId = null;

    if (targetPlayer) {
      if (typeof targetPlayer === "string") {
        targetName = targetPlayer;
      } else {
        targetName = targetPlayer.name || null;
        targetSc = targetPlayer.socialClub || null;
        targetId = Number.isInteger(targetPlayer.id) ? targetPlayer.id : null;
      }
    }

    console.log(`[ADMIN] ${adminName} -> ${action} -> ${targetName || "-"}`);

    if (!AdminLog) return;

    AdminLog.create({
      admin_name: adminName,
      admin_socialclub: adminSc,
      admin_id_ingame: adminId,
      action: String(action),
      target_name: targetName,
      target_socialclub: targetSc,
      target_id_ingame: targetId,
      info: infoObj ? JSON.stringify(infoObj) : null
    }).catch(e => {
      console.error("[ADMIN][LOG] DB Fehler:", e?.original?.sqlMessage || e?.message || e);
    });
  }
};
