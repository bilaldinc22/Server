require('../sequelize');
const { QueryTypes } = global.seq;
const admins = require("./admins.json");



/**
 * Prüft Admin-Rechte über admins.json
 * admins.json:
 * {
 *   "InfernoWraith": 5
 * }
 */
function isAdmin(player) {
    if (!player || !player.name) return false;
    return admins[player.name] && admins[player.name] >= 1;
}

// /giveveh [playerId] [model] [plate]
mp.events.addCommand('giveveh', async (player, _, targetId, model, plate) => {
    try {
        // ✅ Admin-Check (RICHTIG)
        if (!isAdmin(player)) {
            return player.outputChatBox('~r~Kein Admin.');
        }

        if (targetId === undefined || !model || !plate) {
            return player.outputChatBox('~y~/giveveh [playerId] [model] [plate]');
        }

        const target = mp.players.at(parseInt(targetId));
        if (!target) {
            return player.outputChatBox('~r~Spieler nicht gefunden.');
        }

        const owner = String(target.getVariable('playingCharacter'));
        if (!owner || owner === 'null' || owner === 'undefined') {
            return player.outputChatBox('~r~Spieler hat keinen aktiven Character.');
        }

        model = model.toLowerCase();
        plate = plate.toUpperCase();

        // 🔍 Prüfen ob Kennzeichen schon existiert
        const check = await global.sequelize.query(
            'SELECT veh_id FROM vehicles WHERE veh_plate = ? LIMIT 1',
            { replacements: [plate], type: QueryTypes.SELECT }
        );

        if (check.length > 0) {
            return player.outputChatBox('~r~Kennzeichen existiert bereits.');
        }

        // ✅ 1) Fahrzeug in DB anlegen
        const [result] = await global.sequelize.query(
            `INSERT INTO vehicles
            (
              veh_owner,
              veh_name,
              veh_plate,
              veh_parked,
              veh_dimension,
              veh_lock,
              veh_engine,
              veh_fuel,
              veh_health,
              stored,
              stored_garage,
              regester_date,
              updated_date
            )
            VALUES
            (?, ?, ?, 0, 0, 1, 1, 100, 1000, 0, 0, NOW(), NOW())`,
            { replacements: [owner, model, plate] }
        );

        const vehId = result.insertId;
        if (!vehId) {
            return player.outputChatBox('~r~DB Fehler: keine Fahrzeug-ID.');
        }

        // ✅ 2) Fahrzeug spawnen
        const pos = target.position;
        const veh = mp.vehicles.new(mp.joaat(model), new mp.Vector3(
            pos.x + 2,
            pos.y,
            pos.z
        ), {
            numberPlate: plate,
            heading: target.heading
        });

        // ✅ 3) EXTREM WICHTIG für Garage
        veh.setVariable('dbid', vehId);
        veh.setVariable('owner', owner);

        target.outputChatBox(`~g~Du hast ein Fahrzeug erhalten: ${model.toUpperCase()} (${plate})`);
        player.outputChatBox(`~g~Fahrzeug erstellt für ${owner} | ID ${vehId}`);

        console.log(`[GIVEVEH] ${player.name} gab ${owner} ein ${model} (${plate})`);

    } catch (e) {
        console.log('[GIVEVEH ERROR]', e);
        player.outputChatBox('~r~Fehler beim Erstellen des Fahrzeugs.');
    }
});
