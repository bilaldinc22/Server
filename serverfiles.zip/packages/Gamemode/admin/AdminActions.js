const Bans = require("./db/BanRepository");
const Log = require("./AdminLogger");
const AdminVehRepo = require("./db/AdminSpawnedVehicleRepository");

/**
 * HILFSFUNKTIONEN
 */
function kick(player, msg) {
  if (player && player.kick) player.kick(msg);
}

function nearestVehicle(pos, maxDist = 10.0) {
  const maxSq = maxDist * maxDist;
  let best = null;
  let bestSq = maxSq;

  mp.vehicles.forEach(v => {
    if (!v || !v.position) return;
    const dx = pos.x - v.position.x;
    const dy = pos.y - v.position.y;
    const dz = pos.z - v.position.z;
    const d = dx * dx + dy * dy + dz * dz;
    if (d < bestSq) {
      bestSq = d;
      best = v;
    }
  });

  return best;
}

/**
 * ADMIN ACTIONS
 */
module.exports = {
  /* PLAYER STATES */
  freeze(admin, t) {
    t.frozen = !t.frozen;
    t.call("admin:freeze", [t.frozen]);
    Log.log(admin, "FREEZE", t);
  },

  unfreeze(admin, t) {
    t.frozen = false;
    t.call("admin:freeze", [false]);
    Log.log(admin, "UNFREEZE", t);
  },

  setGod(admin, t) {
  t.isGod = true;
  t.call("admin:god", [true]);
  Log.log(admin, "GOD_ON", t);
},

ungod(admin, t) {
  t.isGod = false;
  t.call("admin:god", [false]);
  Log.log(admin, "GOD_OFF", t);
},

  heal(admin, t) {
    t.health = 100;
    Log.log(admin, "HEAL", t);
  },

  armor(admin, t) {
    t.armour = 100;
    Log.log(admin, "ARMOR", t);
  },

  revive(admin, t) {
    t.spawn(t.position);
    Log.log(admin, "REVIVE", t);
  },

  invis(admin, t) {
    t.call("admin:invis");
    Log.log(admin, "INVIS", t);
  },

  /* TELEPORT */
  tpTo(admin, t) {
    admin.position = t.position;
    Log.log(admin, "TP_TO", t);
  },

  bring(admin, t) {
    t.position = admin.position;
    Log.log(admin, "BRING", t);
  },

  /* SPECTATE */
  spectate(admin, t) {
    admin.call("admin:spectate:start", [t.remoteId]);
    Log.log(admin, "SPECTATE_START", t);
  },

  stopSpectate(admin) {
    admin.call("admin:spectate:stop");
    Log.log(admin, "SPECTATE_STOP");
  },

  /* ADMIN PUNISHMENTS */
  remove(admin, t, reason) {
    kick(t, reason || "Admin Remove");
    Log.log(admin, "REMOVE", t, { reason });
  },

  async permban(admin, t, reason) {
    await Bans.ban({
      player: t.name,
      sc: t.socialClub,
      reason,
      admin: admin.name,
      until: null
    });
    kick(t, "Permaban: " + reason);
    Log.log(admin, "PERMABAN", t, { reason });
  },

  async tempban(admin, t, minutes, reason) {
    const until = new Date(Date.now() + minutes * 60000);
    await Bans.ban({
      player: t.name,
      sc: t.socialClub,
      reason,
      admin: admin.name,
      until
    });
    kick(t, `Tempban (${minutes} Min): ${reason}`);
    Log.log(admin, "TEMPBAN", t, { minutes, reason });
  },

  async unban(admin, socialclub) {
    await Bans.unban(socialclub);
    Log.log(admin, "UNBAN", socialclub);
  },

  /* VEHICLES */
  async vehicleSpawn(admin, model) {
    model = String(model || "adder").trim();
    const hash = mp.joaat(model);

    const pos = admin.position;
    const heading = admin.heading;

    const v = mp.vehicles.new(hash, pos, { heading });

    v.setVariable("adminSpawned", true);
    v.setVariable("adminOwnerSc", admin.socialClub);
    v.setVariable("adminOwnerName", admin.name);

    const plate = `ADM${String(admin.id).padStart(2, "0")}`;
    try { v.numberPlate = plate; } catch {}

    const row = await AdminVehRepo.create(admin, model, pos, heading, plate);
    if (row && row.id) v.setVariable("adminDbId", row.id);

    Log.log(admin, "VEH_SPAWN", model, { dbId: row ? row.id : null, plate });
  },

  vehicleRepair(admin) {
    const v = admin.vehicle || nearestVehicle(admin.position, 10.0);
    if (!v) return;
    v.repair();
    Log.log(admin, "VEH_REPAIR", "near", {});
  },

  async vehicleDelete(admin) {
    const v = admin.vehicle || nearestVehicle(admin.position, 10.0);
    if (!v) return;

    const dbId = v.getVariable("adminDbId");
    if (dbId) await AdminVehRepo.deactivate(dbId);

    v.destroy();
    Log.log(admin, "VEH_DELETE", "near", { dbId: dbId || null });
  }
};