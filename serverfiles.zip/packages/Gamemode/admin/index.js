require("./server");

console.log("[ADMIN] Admin System geladen");
