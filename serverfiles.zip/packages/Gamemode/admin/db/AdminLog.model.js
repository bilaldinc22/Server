const { DataTypes } = require("sequelize");

const sequelize = global.sequelize;
if (!sequelize) throw new Error("global.sequelize nicht gesetzt");

const AdminLog = sequelize.define("admin_logs", {
  id: { type: DataTypes.INTEGER, primaryKey:true, autoIncrement:true },

  admin_name: { type: DataTypes.STRING(255), allowNull:true },
  admin_socialclub: { type: DataTypes.STRING(255), allowNull:true },
  admin_id_ingame: { type: DataTypes.INTEGER, allowNull:true },

  action: { type: DataTypes.STRING(255), allowNull:true },

  target_name: { type: DataTypes.STRING(255), allowNull:true },
  target_socialclub: { type: DataTypes.STRING(255), allowNull:true },
  target_id_ingame: { type: DataTypes.INTEGER, allowNull:true },

  info: { type: DataTypes.TEXT, allowNull:true }
}, {
  tableName: "admin_logs",
  timestamps: true,
  createdAt: "createdAt",
  updatedAt: "updatedAt"
});

module.exports = AdminLog;
