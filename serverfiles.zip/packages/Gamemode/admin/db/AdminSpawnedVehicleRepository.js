const AdminSpawnedVehicle = require("./AdminSpawnedVehicle.model");

function dbErr(e) {
  return e?.original?.sqlMessage || e?.parent?.sqlMessage || e?.message || String(e);
}

module.exports = {
  async create(owner, model, pos, heading, plate) {
    try {
      return await AdminSpawnedVehicle.create({
        ownerSocialClub: owner.socialClub,
        ownerName: owner.name,
        model,
        x: pos.x, y: pos.y, z: pos.z,
        heading,
        plate,
        active: true
      });
    } catch (e) {
      console.error("[ADMIN][VEH][DB] Insert Fehler:", dbErr(e));
      return null;
    }
  },

  async deactivate(id) {
    try {
      await AdminSpawnedVehicle.update({ active:false }, { where:{ id } });
    } catch (e) {
      console.error("[ADMIN][VEH][DB] Update Fehler:", dbErr(e));
    }
  },

  async updateTransform(id, pos, heading) {
    try {
      await AdminSpawnedVehicle.update({
        x: pos.x, y: pos.y, z: pos.z,
        heading
      }, { where:{ id } });
    } catch (e) {
      console.error("[ADMIN][VEH][DB] Transform Update Fehler:", dbErr(e));
    }
  },

  async listActive(limit = 2000) {
    try {
      return await AdminSpawnedVehicle.findAll({ where:{ active:true }, limit });
    } catch (e) {
      console.error("[ADMIN][VEH][DB] List Fehler:", dbErr(e));
      return [];
    }
  }
};
