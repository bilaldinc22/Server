const { DataTypes } = require("sequelize");
const sequelize = global.sequelize;
if (!sequelize) throw new Error("global.sequelize nicht gesetzt");

const AdminSpawnedVehicle = sequelize.define("admin_spawned_vehicles", {
  id: { type: DataTypes.INTEGER, primaryKey:true, autoIncrement:true },

  ownerSocialClub: { type: DataTypes.STRING(255), allowNull:false },
  ownerName: { type: DataTypes.STRING(255), allowNull:true },

  model: { type: DataTypes.STRING(64), allowNull:false },
  x: { type: DataTypes.FLOAT, allowNull:false },
  y: { type: DataTypes.FLOAT, allowNull:false },
  z: { type: DataTypes.FLOAT, allowNull:false },
  heading: { type: DataTypes.FLOAT, allowNull:false },

  plate: { type: DataTypes.STRING(16), allowNull:true },
  active: { type: DataTypes.BOOLEAN, defaultValue:true }
}, {
  tableName: "admin_spawned_vehicles",
  timestamps: true,
  createdAt: "createdAt",
  updatedAt: "updatedAt"
});

module.exports = AdminSpawnedVehicle;
