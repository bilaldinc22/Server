module.exports = { SUPPORT:1, MODERATOR:2, ADMIN:3, LEAD:4, OWNER:5 };
