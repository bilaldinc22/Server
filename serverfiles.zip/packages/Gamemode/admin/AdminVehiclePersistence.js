const Repo = require("./db/AdminSpawnedVehicleRepository");

function spawnFromRow(row) {
  const model = String(row.model || "adder");
  const hash = mp.joaat(model);
  const pos = new mp.Vector3(Number(row.x), Number(row.y), Number(row.z));
  const heading = Number(row.heading) || 0;

  const v = mp.vehicles.new(hash, pos, { heading });

  v.setVariable("adminSpawned", true);
  v.setVariable("adminDbId", row.id);
  v.setVariable("adminOwnerSc", row.ownerSocialClub || null);
  v.setVariable("adminOwnerName", row.ownerName || null);

  if (row.plate) {
    try { v.numberPlate = String(row.plate).slice(0, 16); } catch {}
  }

  // mark for autosave
  v._adminPersist = true;
  return v;
}

async function loadAll() {
  const rows = await Repo.listActive(5000);
  let ok = 0;
  for (const r of rows) {
    try {
      spawnFromRow(r);
      ok++;
    } catch (e) {
      console.error("[ADMIN][VEH] Spawn Fehler DB id:", r?.id, e?.message || e);
    }
  }
  console.log(`[ADMIN][VEH] Persistente Admin-Fahrzeuge geladen: ${ok}/${rows.length}`);
}

// Save all spawned admin vehicles every N seconds
const SAVE_INTERVAL_MS = 30000;

function startAutoSave() {
  setInterval(() => {
    mp.vehicles.forEach(v => {
      try {
        if (!v || !v._adminPersist) return;
        const id = v.getVariable("adminDbId");
        if (!id) return;
        Repo.updateTransform(id, v.position, v.heading);
      } catch (e) {
        // ignore
      }
    });
  }, SAVE_INTERVAL_MS);
}

// When an admin vehicle is destroyed by script or explosion, set inactive
mp.events.add("vehicleDeath", (v) => {
  try {
    const id = v && v.getVariable ? v.getVariable("adminDbId") : null;
    if (id) Repo.deactivate(id);
  } catch {}
});

module.exports = { loadAll, startAutoSave };
