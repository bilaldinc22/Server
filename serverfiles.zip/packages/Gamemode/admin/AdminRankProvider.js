const fs = require("fs");
const path = require("path");
const ADMINS_PATH = path.join(__dirname, "admins.json");
let cache = {};
function load(){ try{ cache = JSON.parse(fs.readFileSync(ADMINS_PATH,"utf8"))||{}; }catch{ cache={}; } }
load();
function getAdminLevelByPlayer(player){
  const sc = player.socialClub || "";
  const lvl = cache[sc];
  return typeof lvl === "number" ? lvl : 0;
}
function setAdminLevelForSocialClub(sc, lvl){
  cache[String(sc)] = Number(lvl)||0;
  fs.writeFileSync(ADMINS_PATH, JSON.stringify(cache,null,2), "utf8");
}
module.exports = { load, getAdminLevelByPlayer, setAdminLevelForSocialClub };
