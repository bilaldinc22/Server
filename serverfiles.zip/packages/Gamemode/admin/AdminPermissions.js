const PERMS = require("./permissions");
const getLevel = (p) => Number(p.adminLevel || 0);
const requireLevel = (p, lvl) => getLevel(p) >= lvl;
module.exports = { PERMS, getLevel, requireLevel };
