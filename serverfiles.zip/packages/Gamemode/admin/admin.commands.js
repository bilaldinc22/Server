console.log(">>> admin.commands.js GELADEN <<<")

const InventoryService = require("../Player/inventory.service")

/**
 * Passe diese Funktion an dein Rechtesystem an.
 * Beispiele (je nach Gamemode):
 *   return player.adminLevel >= 1
 *   return player.isAdmin === true
 *   return player.getVariable("admin") === true
 */
function isAdmin(player) {
    return !!(player && (player.adminLevel >= 1 || player.isAdmin === true))
}

function normalizeWeaponHash(input) {
    if (!input) return null
    const w = String(input).trim().toUpperCase()
    if (!w) return null
    // erlaubt "WEAPON_PISTOL" oder "PISTOL"
    return w.startsWith("WEAPON_") ? w : `WEAPON_${w}`
}

/**
 * /giveweapon [playerId] <weapon> [ammo]
 * Beispiele:
 *   /giveweapon 3 pistol 250
 *   /giveweapon weapon_carbinerifle 200     (an sich selbst)
 */
mp.events.addCommand("giveweapon", (player, _fullText, arg1, arg2, arg3) => {
    if (!player || !player.characterId) return

    if (!isAdmin(player)) {
        player.outputChatBox("Keine Berechtigung.")
        return
    }

    let target = player
    let weaponArg = arg1
    let ammoArg = arg2

    const maybeId = parseInt(arg1, 10)
    if (!Number.isNaN(maybeId) && String(maybeId) === String(arg1)) {
        target = mp.players.at(maybeId)
        weaponArg = arg2
        ammoArg = arg3

        if (!target) {
            player.outputChatBox("Spieler nicht gefunden.")
            return
        }
    }

    const weaponHash = normalizeWeaponHash(weaponArg)
    if (!weaponHash) {
        player.outputChatBox("Usage: /giveweapon [playerId] <weapon> [ammo]")
        player.outputChatBox("Beispiel: /giveweapon 3 pistol 250")
        return
    }

    const ammo = Math.max(0, parseInt(ammoArg, 10) || 0)

    InventoryService.addWeapon(target, weaponHash, ammo)

    player.outputChatBox(`Waffe ${weaponHash} an ${target.name || "Spieler"} gegeben (${ammo} Ammo).`)
    if (target !== player) target.outputChatBox(`Du hast eine Waffe erhalten: ${weaponHash} (${ammo} Ammo).`)
})
