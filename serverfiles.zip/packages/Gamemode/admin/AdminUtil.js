function safeStr(v, fallback="") { return (v===undefined||v===null) ? fallback : String(v); }
function asInt(v, d=0){ const n=parseInt(v,10); return Number.isFinite(n)?n:d; }
function distSq(a,b){ const dx=a.x-b.x, dy=a.y-b.y, dz=a.z-b.z; return dx*dx+dy*dy+dz*dz; }
module.exports = { safeStr, asInt, distSq };
