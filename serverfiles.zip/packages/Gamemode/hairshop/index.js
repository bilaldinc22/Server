'use strict';

/**
 * Hairshop (Friseur) - server
 * - NativeUI client
 * - Saves into appearance_persistence barber field via Sequelize
 * - Supports GTA component hair + custom model hair
 */

const hairCfg = require("./hairstyles");
const appearance = require("../appearance_persistence");

function getGenderKey(player){
  // 0 = male, 1 = female
  const gVar = player.getVariable("gender");
  if (gVar !== undefined && gVar !== null) {
    const n = Number(gVar);
    return (n === 1 || gVar === true) ? "female" : "male";
  }

  const ch = player.character;
  if (ch && ch.character_gender !== undefined && ch.character_gender !== null) {
    return ch.character_gender ? "female" : "male";
  }

  // fallback: model hash
  try {
    const model = player.model;
    // freemode female hash
    if (model === mp.joaat("mp_f_freemode_01")) return "female";
  } catch (e) {}
  return "male";
}

function calcPrice(barber){
  if (!barber || !barber.type) return 0;
  const p = hairCfg.prices || {};
  return barber.type === "custom" ? (p.custom || 0) : (p.gta || 0);
}

// OPEN event (fehlte)
mp.events.add("hairshop:open", (player) => {
  const key = getGenderKey(player);
  const data = {
    gta: (hairCfg[key] && hairCfg[key].gta) ? hairCfg[key].gta : [],
    custom: (hairCfg[key] && hairCfg[key].custom) ? hairCfg[key].custom : [],
    prices: hairCfg.prices || {}
  };
  player.call("hairshop:showUI", [JSON.stringify(data)]);
});

mp.events.add("hairshop:buy", async (player, a, b, c) => {
  try {
    // Client variants:
    // 1) hairshop:buy(hair, color, highlight)
    // 2) hairshop:buy(JSON.stringify(payload))
    let payload = null;

    if (typeof a === "string" && b === undefined) {
      payload = JSON.parse(a);
    } else if (typeof a === "number" || typeof a === "string") {
      payload = { type: "gta", hair: Number(a) || 0, hairColor: Number(b) || 0, hairHighlight: (c === undefined ? Number(b) || 0 : Number(c) || 0) };
    }

    const barber = normalizePayload(payload);
    const price = calcPrice(barber);

    await appearance.saveAppearance(player, { barber });

    try { player.call("hairshop:notify", [`Frisur gespeichert${price ? ` (Preis: $${price})` : ""}.`]); } catch (_) {}
  } catch (e) {
    console.log("[HAIRSHOP] buy error:", e?.message || e);
    try { player.call("hairshop:notify", ["Fehler beim Speichern."]); } catch (_) {}
  }
});

// Fallback event names used by some clients
async function saveFromPayload(player, payloadJson){
  try {
    let payload = payloadJson;
    if (typeof payloadJson === "string") payload = JSON.parse(payloadJson);

    const barber = normalizePayload(payload);
    await appearance.saveAppearance(player, { barber });
  } catch (e) {
    console.log("[HAIRSHOP] save error:", e?.message || e);
  }
}

mp.events.add("hairshop:save", async (player, payloadJson) => {
  await saveFromPayload(player, payloadJson);
});

mp.events.add("barber:save", async (player, payloadJson) => {
  await saveFromPayload(player, payloadJson);
});

mp.events.add("appearance:barberSave", async (player, payloadJson) => {
  await saveFromPayload(player, payloadJson);
});

function normalizePayload(p){
  if (!p || typeof p !== "object") return null;

  if (p.type === "gta") {
    return {
      type: "gta",
      hair: Number(p.hair) || 0,
      hairColor: Number(p.hairColor) || 0,
      hairHighlight: Number(p.hairHighlight) || Number(p.hairColor) || 0
    };
  }

  if (p.type === "custom") {
    const c = p.custom && typeof p.custom === "object" ? p.custom : null;
    return {
      type: "custom",
      hairColor: Number(p.hairColor) || 0,
      hairHighlight: Number(p.hairHighlight) || Number(p.hairColor) || 0,
      custom: c ? { model: String(c.model || ""), collection: String(c.collection || "") } : null
    };
  }

  // backwards compat
  return p;
}
