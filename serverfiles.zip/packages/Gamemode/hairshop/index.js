'use strict';

/**
 * Hairshop (Friseur) - server
 * Fix: accept BOTH buy formats:
 *   1) hairshop:buy(payloadJson|string|object)  [original]
 *   2) hairshop:buy(hair, hairColor, hairHighlight) [some clients]
 *
 * Saves via appearance_persistence barber field.
 */

const hairCfg = require("./hairstyles");
const appearance = require("../appearance_persistence");

function getGenderKey(player){
  const gVar = player.getVariable("gender");
  if (gVar !== undefined && gVar !== null) return Number(gVar) === 1 ? "female" : "male";
  // fallback: if you store gender elsewhere, keep male by default
  return "male";
}

function calcPrice(barber){
  try {
    if (!barber) return 0;
    const genderKey = (barber.genderKey || "male");
    const list = hairCfg && hairCfg[genderKey] ? hairCfg[genderKey] : null;
    if (!list) return 0;
    if (barber.type === "gta") {
      const entry = list.gta && list.gta[barber.hair] ? list.gta[barber.hair] : null;
      return Number(entry?.price || 0) || 0;
    }
    if (barber.type === "custom") {
      return Number(list.customPrice || 0) || 0;
    }
  } catch (_) {}
  return 0;
}

function normalizePayload(p){
  if (!p || typeof p !== "object") return null;

  if (p.type === "gta" || p.hairType === "gta") {
    return {
      type: "gta",
      hair: Number(p.hair) || 0,
      hairColor: Number(p.hairColor) || 0,
      hairHighlight: Number(p.hairHighlight) || Number(p.hairColor) || 0
    };
  }

  if (p.type === "custom") {
    const c = p.custom && typeof p.custom === "object" ? p.custom : null;
    return {
      type: "custom",
      hairColor: Number(p.hairColor) || 0,
      hairHighlight: Number(p.hairHighlight) || Number(p.hairColor) || 0,
      custom: c ? { model: String(c.model || ""), collection: String(c.collection || "") } : null
    };
  }

  return p;
}

// Main buy handler: supports both signatures
mp.events.add("hairshop:buy", async (player, a, b, c) => {
  try {
    let payload = null;

    // Signature 2: (hair, color, highlight)
    if (typeof a === "number" || typeof a === "string" && /^\d+$/.test(a)) {
      payload = { type: "gta", hair: Number(a) || 0, hairColor: Number(b) || 0, hairHighlight: (c === undefined ? Number(b) || 0 : Number(c) || 0) };
    } else {
      // Signature 1: payloadJson|string|object
      payload = a;
      if (typeof a === "string") payload = JSON.parse(a);
    }

    const barber = normalizePayload(payload);
    if (!barber) throw new Error("invalid payload");

    // attach gender for pricing lookup (optional)
    barber.genderKey = getGenderKey(player);

    const price = calcPrice(barber);

    await appearance.saveAppearance(player, { barber });

    player.call("hairshop:notify", [`Frisur gespeichert${price ? ` (Preis: $${price})` : ""}.`]);
  } catch (e) {
    console.log("[HAIRSHOP] buy error:", e?.message || e);
    try { player.call("hairshop:notify", ["Fehler beim Speichern."]); } catch (_) {}
  }
});
