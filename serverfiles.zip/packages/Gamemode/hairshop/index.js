'use strict';

/**
 * Hairshop (Friseur) - server
 * - Charges cash (pocket_money/cash) using moneyscripts/money.adapter.js
 * - Persists barber via appearance_persistence (relog/restart) + syncs to other players via setVariable
 * - Validates incoming values (no trust in client)
 *
 * Client (NativeUI) sends:
 *   hairshop:buy(JSON.stringify({ type:"gta", hair, hairColor, hairHighlight }))
 *
 * This handler also accepts:
 *   hairshop:buy(hair, hairColor, hairHighlight)  (legacy)
 */

const hairCfg = require("./hairstyles");
const appearance = require("../appearance_persistence");
const money = require("../moneyscripts/money.adapter");

function toInt(v, def = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? Math.trunc(n) : def;
}

function clamp(n, min, max) {
  n = toInt(n, min);
  if (n < min) return min;
  if (n > max) return max;
  return n;
}

function isSameBarber(a, b) {
  if (!a || !b) return false;
  if (a.type !== b.type) return false;
  if (a.type === "gta") {
    return toInt(a.hair) === toInt(b.hair)
      && toInt(a.hairColor) === toInt(b.hairColor)
      && toInt(a.hairHighlight ?? a.hairColor) === toInt(b.hairHighlight ?? b.hairColor);
  }
  if (a.type === "custom") {
    const ac = a.custom || {};
    const bc = b.custom || {};
    return String(ac.model || "") === String(bc.model || "")
      && String(ac.collection || "") === String(bc.collection || "")
      && toInt(a.hairColor) === toInt(b.hairColor)
      && toInt(a.hairHighlight ?? a.hairColor) === toInt(b.hairHighlight ?? b.hairColor);
  }
  return false;
}

function getGenderKey(player) {
  // 0 = male, 1 = female
  const gVar = player.getVariable("gender");
  if (gVar !== undefined && gVar !== null) return Number(gVar) === 1 ? "female" : "male";
  return "male";
}

function normalizePayload(p) {
  if (!p || typeof p !== "object") return null;

  const type = String(p.type || p.hairType || "gta");

  if (type === "gta") {
    // Drawable index range is client-dependent; keep it generous but safe.
    // Freemode has ~70+ in vanilla; allow up to 200 to support addon packs.
    const hair = clamp(p.hair, 0, 200);
    const hairColor = clamp(p.hairColor, 0, 63);
    const hairHighlight = clamp((p.hairHighlight ?? p.hairColor), 0, 63);

    return { type: "gta", hair, hairColor, hairHighlight };
  }

  if (type === "custom") {
    const hairColor = clamp(p.hairColor, 0, 63);
    const hairHighlight = clamp((p.hairHighlight ?? p.hairColor), 0, 63);

    const c = (p.custom && typeof p.custom === "object") ? p.custom : {};
    return {
      type: "custom",
      hairColor,
      hairHighlight,
      custom: { model: String(c.model || ""), collection: String(c.collection || "") }
    };
  }

  return null;
}

function parseArgs(a, b, c) {
  // legacy: numbers
  if (typeof a === "number" || (typeof a === "string" && /^\d+$/.test(a))) {
    return normalizePayload({ type: "gta", hair: a, hairColor: b, hairHighlight: (c === undefined ? b : c) });
  }

  // json string or object
  let payload = a;
  if (typeof a === "string") {
    try { payload = JSON.parse(a); } catch (_) { return null; }
  }
  return normalizePayload(payload);
}

function getPrice(type) {
  if (!hairCfg || !hairCfg.prices) return 0;
  if (type === "gta") return Number(hairCfg.prices.gta || 0) || 0;
  if (type === "custom") return Number(hairCfg.prices.custom || 0) || 0;
  return 0;
}

function currentBarber(player) {
  const b = player.getVariable("barber");
  return (b && typeof b === "object") ? b : null;
}

// Optional: expose lists to client (if you still use CEF somewhere)
mp.events.add("hairshop:requestData", (player) => {
  const key = getGenderKey(player);
  const data = {
    gender: key,
    gta: (hairCfg[key] && Array.isArray(hairCfg[key].gta)) ? hairCfg[key].gta : [],
    custom: (hairCfg[key] && Array.isArray(hairCfg[key].custom)) ? hairCfg[key].custom : [],
    prices: hairCfg.prices || {}
  };
  player.call("hairshop:showUI", [JSON.stringify(data)]);
});

mp.events.add("hairshop:buy", async (player, a, b, c) => {
  try {
    const barber = parseArgs(a, b, c);
    if (!barber) {
      player.call("hairshop:notify", ["Ungültige Auswahl."]);
      return;
    }

    // If unchanged, don't charge
    const cur = currentBarber(player);
    if (cur && isSameBarber(cur, barber)) {
      player.call("hairshop:notify", ["Keine Änderung."]);
      return;
    }

    const price = getPrice(barber.type);

    if (price > 0) {
      const ok = await money.takeCash(player, price);
      if (!ok) {
        player.call("hairshop:notify", ["Nicht genug Geld."]);
        return;
      }
    }

    await appearance.saveAppearance(player, { barber });

    player.call("hairshop:notify", [`Frisur gespeichert${price ? ` (-$${price})` : ""}.`]);
  } catch (e) {
    console.log("[HAIRSHOP] buy error:", e?.message || e);
    try { player.call("hairshop:notify", ["Fehler beim Speichern."]); } catch (_) {}
  }
});

// Fallback save events (client might call these)
mp.events.add("hairshop:save", async (player, payloadJson) => {
  return mp.events.call("hairshop:buy", player, payloadJson);
});
mp.events.add("barber:save", async (player, payloadJson) => {
  return mp.events.call("hairshop:buy", player, payloadJson);
});
mp.events.add("appearance:barberSave", async (player, payloadJson) => {
  return mp.events.call("hairshop:buy", player, payloadJson);
});
