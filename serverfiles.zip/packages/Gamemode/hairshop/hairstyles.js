module.exports = {
  // Hinweis:
  // GTA Hair = Component 2 (Hair)
  // Custom = Object/Model aus game_resources, wird am Kopf-Bone attached.
  // Passe die Listen an deine Ressourcen an.
  male: {
    gta: [
      { id: 0, name: "Kurz" },
      { id: 2, name: "Buzzcut" },
      { id: 5, name: "Undercut" }
    ],
    custom: [
      // Beispiel:
      // { name: "Fade Custom", model: "hair_fade_01", collection: "custom_hairs" }
    ]
  },

  female: {
    gta: [
      { id: 1, name: "Bob" },
      { id: 4, name: "Pferdeschwanz" }
    ],
    custom: [
      // Beispiel:
      // { name: "Long Waves", model: "hair_long_01", collection: "custom_hairs" }
    ]
  },

  // Preise (Server entscheidet final)
  prices: {
    gta: 250,
    custom: 500
  }
};
