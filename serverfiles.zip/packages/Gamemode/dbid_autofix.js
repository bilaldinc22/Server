// Setzt automatisch dbid & owner für ALLE Fahrzeuge,
// sobald sie erstellt werden (egal von welchem Script)

require("./sequelize");
const { QueryTypes } = global.seq;

mp.events.add('vehicleCreated', async (veh) => {
  try {
    if (!veh || !veh.handle) return;

    // Schon gesetzt? → nichts tun
    if (veh.getVariable('dbid')) return;

    const plate = veh.numberPlate;
    if (!plate) return;

    // Fahrzeug über Kennzeichen in DB finden
    const rows = await global.sequelize.query(
      'SELECT veh_id, veh_owner FROM vehicles WHERE veh_plate = ? LIMIT 1',
      { replacements: [plate], type: QueryTypes.SELECT }
    );

    if (!rows.length) return;

    veh.setVariable('dbid', rows[0].veh_id);
    veh.setVariable('owner', rows[0].veh_owner);

    console.log(`[GARAGE AUTO] dbid gesetzt: ${rows[0].veh_id} (${rows[0].veh_owner})`);
  } catch (e) {
    console.log('[GARAGE AUTO ERROR]', e);
  }
});
