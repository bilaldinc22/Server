// Native RAGE:MP VOIP (proximity + push-to-talk on client)
//
// This server file validates voice listener requests from the client and
// performs periodic cleanup to prevent "ghost" listeners.
//
// NOTE: Range must match the client (client_packages/voiceChat.js)
const MAX_RANGE = 6.0;
const CLEANUP_INTERVAL_MS = 1000;

const listenersByPlayer = new Map(); // player.id -> Set(target.id)

function getSet(player) {
	const key = player && player.id;
	if (key === undefined || key === null) return null;

	let set = listenersByPlayer.get(key);
	if (!set) {
		set = new Set();
		listenersByPlayer.set(key, set);
	}
	return set;
}

function dist3(a, b) {
	const dx = a.x - b.x;
	const dy = a.y - b.y;
	const dz = a.z - b.z;
	return Math.sqrt((dx * dx) + (dy * dy) + (dz * dz));
}

function canHear(player, target) {
	if (!player || !target) return false;
	if (player === target) return false;
	if (player.dimension !== target.dimension) return false;

	const d = dist3(player.position, target.position);
	return d <= MAX_RANGE;
}

mp.events.add("add_voice_listener", (player, target) => {
	try {
		if (!target) return;
		if (!canHear(player, target)) return;

		player.enableVoiceTo(target);

		const set = getSet(player);
		if (set) set.add(target.id);
	} catch (e) {
		// silently ignore
	}
});

mp.events.add("remove_voice_listener", (player, target) => {
	try {
		if (!target) return;

		player.disableVoiceTo(target);

		const set = getSet(player);
		if (set) set.delete(target.id);
	} catch (e) {
		// silently ignore
	}
});

mp.events.add("playerQuit", (player) => {
	// remove bookkeeping for quitting player
	try {
		if (!player) return;
		listenersByPlayer.delete(player.id);

		// also remove this player from other listener sets
		for (const set of listenersByPlayer.values()) {
			set.delete(player.id);
		}
	} catch (e) {}
});

// Periodic cleanup: if players moved away / changed dimension / streamed out, disable voice.
setInterval(() => {
	try {
		mp.players.forEach((player) => {
			const set = listenersByPlayer.get(player.id);
			if (!set || set.size === 0) return;

			for (const targetId of Array.from(set)) {
				const target = mp.players.at(targetId);
				if (!target || !canHear(player, target)) {
					if (target) {
						player.disableVoiceTo(target);
					}
					set.delete(targetId);
				}
			}
		});
	} catch (e) {}
}, CLEANUP_INTERVAL_MS);

mp.events.add('SERVER:SET:VOICE:STATE', (player, state) => {
	switch (state) {
		case 1:
			player.setVariable('istalking', 1);
			break;
		case 2:
			player.setVariable('istalking', 0);
			break;
		default:
			break;
	}
});
