
const logger = require('../Logger/discord');
const atms = require('../models/atm.model');


mp.events.addCommand('createatm', async (player) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error: This command is for admins only!`);
    if(admin < 3) return player.outputChatBox(`Command is only for Admin Lvl 3`);
    
    try 
    {

        const create = await atms.create({ atm_pos: player.position });
        if(!create) return player.outputChatBox(`Error : Can not create atm Please Try again`);

        const colshape = mp.colshapes.newSphere(player.position.x, player.position.y, player.position.z, 1);
        colshape.setVariable('atm', colshape);
        colshape.setVariable('atm_id', parseInt(create.atm_id));

        const marker = mp.markers.new(27, new mp.Vector3(player.position.x, player.position.y, player.position.z - 1), 1, { visible: true, color: [175, 112, 255, 100] });
        marker.setVariable('atm_id', parseInt(create.atm_id));

        const blip = mp.blips.new(277, new mp.Vector3(player.position.x, player.position.y, player.position.z),
        {
            name: `Atm`,
            scale: 0.7,
            color: 69,
            alpha: 255,
            drawDistance: 1.0,
            shortRange: true,
            rotation: 0,
            dimension: 0,
        });
        blip.setVariable('atm_id', parseInt(create.atm_id));

        player.outputChatBox(`Successfully Created Atm with ID : ${create.atm_id}`);
    } catch(err)
    {
        logger.sendlog(`server_logs`, `Atm create err ${err}`);
    }
    
});



function loadAtm(position, id) {
    id = parseInt(id);
    const colshape = mp.colshapes.newSphere(position.x, position.y, position.z, 1);
    colshape.setVariable('atm', colshape);
    colshape.setVariable('atm_id', id);

    const marker = mp.markers.new(27, new mp.Vector3(position.x, position.y, position.z - 1), 1, { visible: true, color: [175, 112, 255, 100] });
    marker.setVariable('atm_id', id);

    const blip = mp.blips.new(277, new mp.Vector3(position.x, position.y, position.z),
    {
        name: `Atm`,
        scale: 0.7,
        color: 69,
        alpha: 255,
        drawDistance: 1.0,
        shortRange: true,
        rotation: 0,
        dimension: 0,
    });
    blip.setVariable('atm_id', id);
}

module.exports.loadAtm = loadAtm;


mp.events.addCommand('delatm', async (player, _, id) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error: This command is for admins only!`);
    if(admin < 3) return player.outputChatBox(`Command is in development!`);
    if(isNaN(id)) return player.outputChatBox(`Syntax : /delatm id`);

    try
    {
        if(mp.colshapes) {
            mp.colshapes.forEach((shape) => {
                if(shape.getVariable('atm_id') == id) {
                    shape.destroy();
                }
            }); 
        }

        if(mp.blips) {
            mp.blips.forEach((myblip) => {
                if(myblip.getVariable('atm_id') == id) {
                    myblip.destroy();
                }
            });
        }

        if(mp.markers) {
            mp.markers.forEach((mymarker) => {
                if(mymarker.getVariable('atm_id') == id) {
                    mymarker.destroy();
                }
            });
        }

        const del = await atms.findOne({ where: { atm_id: id }});
        if(del) {
            
            await del.destroy();

        } else return player.outputChatBox(`Can not find ATM`);
        
        player.outputChatBox(`Successfully Deleted Atm ID : ${id}`);


    } catch(err)
    {
        logger.sendlog(`server_logs`, `Deleting Atm Failed ${err}`);
    }

});




mp.events.add("playerEnterColshape", (player, shape) => {
    if(shape == shape.getVariable('atm')) {
        player.setVariable('bank_context','ATM');
        player.call('CLIENT::OPEN:BANK', ['ATM']);
    }
});


mp.events.add("playerExitColshape", (player, shape) => {
    if(shape == shape.getVariable('atm')) {
        player.call('CLIENT::CLOSE:BANK');
    }
});