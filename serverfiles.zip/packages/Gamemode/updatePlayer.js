
const accounts = require('./models/account.model');
const characters = require('./models/character.model');
const vehicles = require('./models/vehicle.model');
const logger = require('./Logger/discord');


setInterval(async () => {
try {
    mp.players.forEach(async (player) => { 

        const character = player.getVariable('playingCharacter');
        if(!character) return;

            const findcharacter = await characters.findOne({ where: { character_name: character } });
            if(!findcharacter) return;
            findcharacter.update({ 
                character_position: player.position, 
                character_heading: player.heading, 
                character_dimension: player.dimension 
            });
    });

    } catch (err) {
        logger.sendlog(`server_logs`, `Set Interval ${err}`);
    }
    
}, /*300000*/50000);



mp.events.add('playerQuit', async (player) => {
    try {

        const pos = player.position;
        const heading = player.heading;
        const dimension = player.dimension;
        
        const character = player.getVariable('playingCharacter');
        if(!character) return;

        const findcharacter = await characters.findOne({ where: { character_name: character }});
        if(!findcharacter) return;

        findcharacter.update({ 
            character_position: pos, 
            character_heading: heading, 
            character_dimension: dimension 
        });
        

    } catch (err) {
        logger.sendlog(`server_logs`, `Update Player ${err}`);
    }
});