

const airport_rental = mp.colshapes.newSphere(-1035.088623046875, -2657.67236328125, 13.830760955810547, 1);

mp.labels.new("Airport Rental", new mp.Vector3(-1035.088623046875, -2657.67236328125, 13.830760955810547 + 1.0), {
    los: true,
    font: 0,
    drawDistance: 2.5 * 4.0
});


mp.markers.new(36, new mp.Vector3(-1035.088623046875, -2657.67236328125, 13.830760955810547), 1.5, { visible: true, color: [11, 156, 241, 100] });

mp.blips.new(225, new mp.Vector3(-1035.088623046875, -2657.67236328125, 13.830760955810547),
    {
        name: 'Airport Rental',
        scale: 0.7,
        color: 68,
        alpha: 255,
        drawDistance: 1.0,
        shortRange: false,
        rotation: 0,
        dimension: 0,
});


mp.events.add("playerEnterColshape", (player, shape) => {
    if(shape == airport_rental) {
        player.call('CLIENT::OPEN:AIRPORT:RENTAL');
    }
});

mp.events.add("playerExitColshape", (player, shape) => {
    if(shape == airport_rental) {
        player.call('CLIENT::CLOSE:AIRPORT:RENTAL');
    }
});

mp.events.add('SERVER::SPAWN:AIRPORT:RENTAL', (player, vehicleName) => {
    const vehicle = mp.vehicles.new(mp.joaat(vehicleName), new mp.Vector3(player.position.x, player.position.y, player.position.z), {
        heading: parseInt(player.heading),
        numberPlate: `RENTAL`,
        locked: false,
        engine: true,
        dimension: 0
    });
    player.putIntoVehicle(vehicle, 0);
    vehicle.setVariable('rentalvehicle', vehicle); // later
});