
const factions = require("../models/factions.model");
const logger = require("../Logger/discord");



mp.events.addCommand("createfaction", async (player, _, name, code, catagory, leader, blip, blipcolor, uicolor) => {
   try
   {

    if(!player.getVariable("admin")) return player.outputChatBox(`Admin Command Only`);

    if(!name || isNaN(code) || !catagory || !leader || isNaN(blip) || isNaN(blipcolor) || !uicolor) return player.outputChatBox(`Syntax : /createfaction name code catagory leader blip blipcolor uicolor`);

    
    const create = await factions.create({ 
        name: name,
        code: code,
        catagory: catagory,
        leader: leader,
        blip: blip,
        blipcolor: blipcolor,
        uicolor: uicolor,
    });

    player.outputChatBox(`Faction Created Successfully , Faction ID is ${create.id}`);


   }
   catch(err) {
    logger.serverLog(`Create Faction Error ${err}`);
   }
});


mp.events.addCommand("deletefaction", async (player, _, id) => {
    try
    {
        if(!player.getVariable("admin")) return player.outputChatBox(`Admin Command Only`);
        if(isNaN(id)) return player.outputChatBox(`Syntax : /deletefaction id`);

        const del = await factions.destroy({ where: { id: id }});
        console.log(del);
        if(del) {
            player.outputChatBox(`Deleted Faction Successfully`);
        } else return player.outputChatBox(`Cant find a faction with ID ${id}`);
    }
    catch(err) {
        logger.serverLog(`deletefaction ${err}`);
    }

});


mp.events.addCommand("setleader", async (player, _, id, leadername) => {
    try
    {
        if(!player.getVariable("admin")) return player.outputChatBox(`Admin Command Only Bitch`);
        if(isNaN(id) || !leadername) return player.outputChatBox(`syntax : /setleader id leadername`);

        let findFaction = await factions.findOne({ where: { id: id }});
        if(!findFaction) return player.outputChatBox(`Cant find faction with id ${id}`);

        mp.players.forEachFast((person) => {
            if(person.getVariable("playingCharacter") == `${leadername}`) {
                player.outputChatBox(`You were set as leader of the faction ${findFaction.name}`);
            }            
        });

        findFaction.leader = leadername;
        findFaction.save();
        player.outputChatBox(`Faction with id ${findFaction.id} leader updated to ${leadername}`);

    }
    catch(err) {
        logger.serverLog(`editleader ${err}`);
    }

});


mp.events.addCommand("aeditfaction", async (player, _, id) => {
    try
    {
        if(!player.getVariable("admin")) return;
        if(isNaN(id)) return player.outputChatBox(`Syntax : /aeditfaction id`);

        let findfaction = await factions.findOne({ where: { id: id }});
        if(!findfaction) return player.outputChatBox(`Cant find faction with this id ${id}`);

        player.call("CLIENT::EDIT:FACTION", [findfaction]);
        
    }
    catch(err) 
    {
        logger.serverLog(`edit faction err ${err}`);
    }
});

mp.events.add("SERVER::SAVE:FACTION:DATA", async (player, data, id) => {
    try
    {
        data = JSON.parse(data);
        const save = await factions.findOne({ where: { id: id }});
        if(!save) return player.outputChatBox(`Editing Faction Failed, Please Try again`);
        save.name = data.name;
        save.origin = data.origin;
        save.description = data.description;
        save.blip = data.blip;
        save.blipcolor = data.blipcolor;
        save.save();
        player.outputChatBox(`Faction Edit Saved Successfully!`);
    }
    catch(err)
    {
        logger.serverLog(`Save Faction Data ${err}`);
    }
});




mp.events.addProc("SERVER::FETCH:FACTION:DATA", async (player) => {
    try
    {
        let fetch = await factions.findAll();
        return fetch;  
    }
    catch(err) 
    {
        logger.serverLog(`Fetch Faction data ${err}`);
    }
});