

// For DUTY PD 

const position = new mp.Vector3(444.2192687988281, -975.8308715820312, 30.68960189819336);
const helpdeskpos = new mp.Vector3(440.09539794921875, -981.2971801757812, 30.68960189819336);



const pd = mp.colshapes.newSphere(position.x, position.y, position.z, 1);
pd.setVariable('PD', true);

const pdMarker = mp.markers.new(30, new mp.Vector3(position.x, position.y, position.z - 0.3), 1, { visible: true, color: [149, 53, 83, 100] });

const pdBlip = mp.blips.new(60, new mp.Vector3(position.x, position.y, position.z),
{
    name: `LSPD`,
    scale: 0.7,
    color: 63,
    alpha: 255,
    drawDistance: 1.0,
    shortRange: true,
    rotation: 0,
    dimension: 0,
});

mp.labels.new("LSPD", new mp.Vector3(position.x, position.y, position.z), {
    los: true,
    font: 0,
    drawDistance: 2.5 * 4.0
});




// HELP DESK PD 
const helpdesk = mp.colshapes.newSphere(helpdeskpos.x, helpdeskpos.y, helpdeskpos.z, 1);
helpdesk.setVariable('PDHELPDESK', true);

const helpdeskMarker = mp.markers.new(1, new mp.Vector3(helpdeskpos.x, helpdeskpos.y, helpdeskpos.z - 1), 1, { visible: true, color: [149, 53, 83, 100] });

mp.labels.new("Help Desk", new mp.Vector3(helpdeskpos.x, helpdeskpos.y, helpdeskpos.z), {
    los: true,
    font: 0,
    drawDistance: 2.5 * 4.0
});





mp.events.add("playerEnterColshape", (player, shape) => {
    if(shape.getVariable("PD") && player.getVariable("faction").code === 999) {
        player.outputChatBox(`Welcome to LSPD Shift`);
    }

    if(shape.getVariable("PDHELPDESK")) {
        player.outputChatBox(`Welcome to LSPD Help Desk`);
    }

});