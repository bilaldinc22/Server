
const logger = require('../Logger/discord');
const { Op } = require("sequelize"); 
const accounts = require('../models/account.model'); 
const bans = require('../models/ban.model');
const characters = require('../models/character.model');
const whitelist = require('../models/whitelist.model');

mp.events.add('playerReady', (player) => {
    const { ip, socialClub, serial } = player;
    processPlayer(player, ip, serial, socialClub);
});

async function processPlayer (player, ip, hardware, socialclub) {
    try
    {
        //const findwhitelist = await whitelist.findOne({ where: { socialclub: socialclub }});
        //if(!findwhitelist) return player.kick();
        const findban = await bans.findOne({ where: {[Op.or]: [{ ip_address: ip }, { hardware_id: hardware }, { social_club: socialclub }], } });
        if(findban) return player.call("CLIENT::SHOW:BAN:PAGE", [findban.ban_issued_by, findban.ban_reason, findban.ban_type]);
        player.call('CLIENT::SHOW:LOGIN:PAGE');
    }
    catch(err) 
    {
        logger.sendlog('server_logs', `process Player ${err}`);
    }
}

mp.events.add('SERVER::ATTEMPT:REGISTER', async (player, username, email, password) => {
    try { //, { socialclub: player.socialClub } 
        const findaccount = await accounts.findOne({ where: { [Op.or]: [ { username: username }, { email: email }, { socialclub: player.socialClub } ] } });

        if(findaccount) return player.call('Createinfo', [`You already have an account! If you forgot your details contact support staff.`, 255, 0, 0, 'top']);

        const created = await accounts.create({ ipaddress: player.ip, hardwareid: player.serial, username: username, password: password, email: email, socialclub: player.socialClub, online: true });

        if(created) {
            player.call('CLIENT::OPEN:CHARACTER:CREATOR'); 
            player.setVariable('SRPID', created.SRPID);
            player.setVariable('online', true);
            player.setVariable('username', created.username);
            
// Ensure minimum character slots (set to 5)
try {
    if (created.character_slots === null || created.character_slots === undefined || created.character_slots < 5) {
        await created.update({ character_slots: 5 });
        created.character_slots = 5;
    }
} catch (e) {}

            player.setVariable('character_slots', created.character_slots);
            player.call('Createinfo', [`Account Created Successfully`, 0,128,0, 'top']);
            logger.sendlog('server_logs', `${username} Successfully Created an account`);
        } 

    } catch(err) { 
        
        logger.sendlog('server_logs', `ATTEMPT::REGISTER ${err}`);
    }
});

mp.events.add('SERVER::ATTEMPT:LOGIN', async (player, username, password) => {
    try {

        const findaccount = await accounts.findOne({ where: { username: username } });
        if(!findaccount) return player.call('Createinfo', [`Can not find an account with this username`, 170, 0, 0, 'top']);

        if(findaccount.login(password)) {
           
            player.setVariable('SRPID', findaccount.SRPID);
          
            if(findaccount.admin > 0) {
    
                player.setVariable('adminRank', findaccount.admin);
                player.setVariable('adminPerms', true);
                player.setVariable('adminDuty', false);
                player.setVariable('admin_skin', findaccount.admin_skin);
            }
         
            if(findaccount.vip > 0) {
                player.setVariable('vip', findaccount.vip);
            }
           
                player.setVariable('username', findaccount.username);
                player.setVariable('online', true);
                
// Ensure minimum character slots (set to 5)
try {
    if (findaccount.character_slots === null || findaccount.character_slots === undefined || findaccount.character_slots < 5) {
        await findaccount.update({ character_slots: 5 });
        findaccount.character_slots = 5;
    }
} catch (e) {}

            player.setVariable('character_slots', findaccount.character_slots);

           
            const find = await characters.findAll({ where: { username: findaccount.username }});
            if(find.length > 0) {
                player.call("CLIENT::OPEN:CHARACTER:CREATOR:WITH:CHARACTERS", [find]);
                player.dimension = parseInt(findaccount.SRPID);
            } else {
                player.call("CLIENT::OPEN:CHARACTER:CREATOR");
                player.dimension = parseInt(findaccount.SRPID);
            }


        } else {
            player.call('Createinfo', [`Incorrect password`, 170, 0, 0, 'top']);
        }

    } catch(err) { 
        logger.sendlog('server_logs', `ATTEMPT::LOGIN ${err}`);
    }
});
