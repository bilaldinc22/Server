// === WEAPON PERSISTENCE – RAGEMP 1.1 FINAL ===

const PlayerWeapon = require("./models/PlayerWeapon");

// ---------------- OWNER ID ----------------
function getOwnerId(player) {
    if (player.character && player.character.id) return player.character.id;
    if (player.characterId) return player.characterId;
    if (player.accountId) return player.accountId;
    return 0;
}

// ---------------- LOAD ----------------
async function loadWeapons(player) {
    const ownerId = getOwnerId(player);
    if (!ownerId) return;

    const weapons = await PlayerWeapon.findAll({
        where: { owner_id: ownerId }
    });

    for (const w of weapons) {
        player.giveWeapon(
            Number(w.weapon_hash),
            Number(w.ammo) || 0
        );
    }
}

// ---------------- SAVE ----------------
async function saveWeapons(player) {
    const ownerId = getOwnerId(player);
    if (!ownerId) return;
    if (!player._rpState || !Array.isArray(player._rpState.weapons)) return;

    for (const w of player._rpState.weapons) {
        await PlayerWeapon.upsert({
            owner_id: ownerId,
            weapon_hash: Number(w.weapon_hash),
            ammo: Number(w.ammo) || 0,
            is_equipped: 1
        });
    }
}

// ---------------- GIVE WEAPON ----------------
async function givePlayerWeapon(player, weaponHash, ammo) {
    const ownerId = getOwnerId(player);
    if (!ownerId) return;

    await PlayerWeapon.upsert({
        owner_id: ownerId,
        weapon_hash: Number(weaponHash),
        ammo: Number(ammo) || 0,
        is_equipped: 1
    });

    player.giveWeapon(Number(weaponHash), Number(ammo) || 0);
}

// ---------------- ADD AMMO ----------------
async function addAmmoToWeapon(player, weaponHash, addAmmo) {
    const ownerId = getOwnerId(player);
    if (!ownerId) return;

    const row = await PlayerWeapon.findOne({
        where: { owner_id: ownerId, weapon_hash: weaponHash }
    });

    const newAmmo = (row ? Number(row.ammo) : 0) + Number(addAmmo);

    await PlayerWeapon.upsert({
        owner_id: ownerId,
        weapon_hash: weaponHash,
        ammo: newAmmo,
        is_equipped: 1
    });

    player.removeWeapon(weaponHash);
    player.giveWeapon(weaponHash, newAmmo);
}

// ---------------- EXPORT ----------------
module.exports = {
    loadWeapons,
    saveWeapons,
    givePlayerWeapon,
    addAmmoToWeapon
};
