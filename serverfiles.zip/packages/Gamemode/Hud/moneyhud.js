function toInt(n) {
  n = Number(n);
  if (!Number.isFinite(n)) return 0;
  n = Math.floor(n);
  return n < 0 ? 0 : n;
}

function syncCash(player, character) {
  const cash = toInt(character?.pocket_money);
  player.setVariable('pocket_money', cash);
  player.call('CLIENT::HUD:CASH', [cash]);
}

global.hudMoney = {
  syncCash
};
