const logger = require("../Logger/discord");
const characters = require("../models/character.model");
const houses = require('../models/house.model');

//house scripts 

//@ House Interior Data
    const InteriorData = {
        0: {name: "Red Test", position: new mp.Vector3(-1457.483, -520.1168, 69.556), heading: 115.7302},
        1: {name: "Fancy Two Story Appartment", position: new mp.Vector3(0, 0, 0), heading: 115.7302},
        2: {name: "Fancy Apartment", position: new mp.Vector3(-777.6339, 323.6999, 211.9974), heading: 244.0892},
        3: {name: "White Three story house", position: new mp.Vector3(-174.3869, 497.6554, 137.6603), heading: 194.0253},
        4: {name: "Purple and White Fancy Apartment", position: new mp.Vector3(-859.7969, 691.4763, 152.8606), heading: 188.4016},
        5: {name: "Micheals House", position: new mp.Vector3(-816.0034, 178.2824, 72.1531), heading: 293.9880},
        6: {name: "Basic Blue Apartment", position: new mp.Vector3(-1150.950439453125, -1520.503662109375, 10.632719039916992), heading: 31.959997177124023},
        7: {name: "Stairs Apartment", position: new mp.Vector3(266.0919, -1007.609, -101.0085), heading: 353.6273},
        8: {name: "Trevor's Methlab", position: new mp.Vector3(0, 0, 0), heading: 293.9880},
        9: {name: "Comedy Club", position: new mp.Vector3(383.2109, -1001.301, -99), heading: 92.1451},
        10: {name: "Bahamas Mamas", position: new mp.Vector3(-1394.593, -595.8915, 30.3196), heading: 212.7930},
        11: {name: "Green Apartment", position: new mp.Vector3(383.2109, -1001.301, -99), heading: 92.1451},
        12: {name: "Franklin's Aunt's House", position: new mp.Vector3(-14.282843589782715, -1440.491943359375, 31.10154914855957), heading: -14.988152503967285},
        13: {name: "Lesters House", position: new mp.Vector3(1274.3578, -1720.061, 54.7714), heading: 24.3086},

        26: {name: "2 Car Garage", position: new mp.Vector3(172.7737, -1007.054, -98.9999), heading: 353.9140},

        27: {name: "6 Car Garage", position: new mp.Vector3(201.4520, -1003.730, -99), heading: 2.1672},

        37: {name: "Ammunation Shooting Range", position: new mp.Vector3(7.4992, -1098.143, 29.7970), heading: 340.4722},
   
        38: {name: "Ammunation Office", position: new mp.Vector3(13.682, -1107.219, 29.79), heading: 143.7026},

        39: {name: "10 Car Garage", position: new mp.Vector3(238.5505, -1004.741, -98.9999), heading: 93.1390},
 
        64: {name: "Madrazo's Ranch", position: new mp.Vector3(1396.4417, 1141.9154, 114.3336), heading: 267.0472},

        244: {name: "Lester's Sweatshop", position: new mp.Vector3(717.9413, -974.9927, 24.9141), heading: 16.9051},


        249: {name: "GTA 4 HOSPITAL INT", position: new mp.Vector3(1669.060, 3200.043, -89.000), heading: 16.9051},

        250: {name: "GTA 4 STRIP CLUB", position: new mp.Vector3(1672.278, 3187.500, -67.361), heading: 16.9051},
        251: {name: "GTA 4 MUSUEM", position: new mp.Vector3(1613.090, 3226.827, -132.363), heading: 16.9051},
        252: {name: "BIZ INT1", position: new mp.Vector3(1616.317, 3280.410, -136.438), heading: 16.9051},
        253: {name: "BIZ INT2", position: new mp.Vector3(1635.701, 3294.448, -139.664), heading: 16.9051},
        254: {name: "MOTEL ROOM INT", position: new mp.Vector3(1583.149, 3292.616, -124.137), heading: 16.9051},
        255: {name: "BIZ INT3", position: new mp.Vector3(1588.385, 3291.772, -108.408), heading: 16.9051},
        256: {name: "BIZ INT4", position: new mp.Vector3(1582.526, 3241.317, -105.721), heading: 16.9051},
        257: {name: "OFFICES INT", position: new mp.Vector3(1620.529, 3287.400, -111.554), heading: 16.9051},
        258: {name: "BIZ INT5", position: new mp.Vector3(1656.603, 3256.480, -149.218), heading: 16.9051},
        259: {name: "BIKER INT", position: new mp.Vector3(1611.263, 3224.962, -147.347), heading: 16.9051},

        260: {name: "THEATER INT", position: new mp.Vector3(1550.068, 3188.444, -133.162), heading: 16.9051},
        261: {name: "GTA O OFFICES INT", position: new mp.Vector3(1534.019, 3150.822, -138.478), heading: 16.9051},
        262: {name: "GARAGE INT1", position: new mp.Vector3(1512.512, 3179.113, -141.461), heading: 16.9051},
        263: {name: "PS INT", position: new mp.Vector3(1436.491, 3227.093, -150.384), heading: 16.9051},
        264: {name: "WAREHOUSE INT", position: new mp.Vector3(1720.543, 3254.667, -149.020), heading: 16.9051},
        265: {name: "BIG EMPTY BOX INT", position: new mp.Vector3(1771.943, 3260.618, -149.004), heading: 16.9051},
        266: {name: "SMALL EMPTY BOX INT", position: new mp.Vector3(1775.569, 3270.124, -132.494), heading: 16.9051},
        267: {name: "MEDIUM EMPTY BOX INT", position: new mp.Vector3(1774.389, 3261.500, -114.452), heading: 16.9051},
        268: {name: "CHURCH INT", position: new mp.Vector3(1712.589, 3224.054, -86.368), heading: 16.9051},
        269: {name: "GTA 4 BAR INT", position: new mp.Vector3(1674.276, 3233.121, -75.732), heading: 16.9051},
        270: {name: "APTMENT COMPLEX INT", position: new mp.Vector3(1642.351, 3231.098, -82.950), heading: 16.9051},
      
     
    };

//@@


mp.events.addCommand('createhouse', async (player, _, interior, address, price) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error: This command is for admins only!`);
    //if(admin < 3) return player.outputChatBox(`Command is only for Admin Lvl 3`);
  
    if(isNaN(interior) || !address || isNaN(price)) return player.outputChatBox(`Syntax : /createhouse interior address price`);

    try 
      {
        const findInterior = InteriorData[interior];
        if(findInterior.length == 0) return player.outputChatBox(`Error: Invalid Interior`);


        const house = await houses.create({
            house_interior: interior,
            house_interior_name: findInterior.name,
            house_interior_position: findInterior.position,
            house_interior_heading: findInterior.heading,

            house_address: address, 
            house_price: price, 
            house_position: player.position
        });

        if(!house) return player.outputChatBox(`Error : Can not create house Please Try again`);

        // id = parseInt(house.house_id);
        id = house.house_id;

        // Entrance
        const colshape = mp.colshapes.newSphere(house.house_position.x, house.house_position.y, house.house_position.z, 1);
        colshape.setVariable('house', colshape);
        colshape.setVariable('house_id', id);
        colshape.setVariable('house_address', house.house_address);
        colshape.setVariable('house_owner', house.house_owner ? house.house_owner : `SA Housing & Urban Development`);
        colshape.setVariable('house_door_type', true);
        // Exit 
            const exitcolshape = mp.colshapes.newSphere(parseFloat(house.house_interior_position.x), parseFloat(house.house_interior_position.y), parseFloat(house.house_interior_position.z), 1);
            exitcolshape.setVariable('house', exitcolshape);
            exitcolshape.setVariable('house_id', id);
            exitcolshape.setVariable('house_door_type', false);
            
            const exitmarker = mp.markers.new(0, new mp.Vector3(parseFloat(house.house_interior_position.x), parseFloat(house.house_interior_position.y), parseFloat(house.house_interior_position.z) -0.1), 1, { visible: true, color: [198, 77, 156, 100] });
            exitmarker.setVariable('house_id', id);
        
        // Dimension Set
            exitcolshape.dimension = id;
            exitmarker.dimension = id;

        const label = mp.labels.new(`${house.house_address}`, new mp.Vector3(house.house_position.x, house.house_position.y, house.house_position.z + 0.3), {
            los: true,
            font: 0,
            drawDistance: 2.5 * 4.0
        });
        label.setVariable('house_id', id);

        const marker = mp.markers.new(0, new mp.Vector3(house.house_position.x, house.house_position.y, house.house_position.z - 0.1), 1, { visible: true, color: [198, 77, 156, 100] });
        marker.setVariable('house_id', id);

        const blip = mp.blips.new(40, new mp.Vector3(house.house_position.x, house.house_position.y, house.house_position.z),
        {
            name: `House`,
            scale: 0.7,
            color: 69,
            alpha: 255,
            drawDistance: 1.0,
            shortRange: true,
            rotation: 0,
            dimension: 0,
        });
        blip.setVariable('house_id', id);

        player.outputChatBox(`Successfully Created House with ID : ${house.house_id}`);
    } catch(err)
    {
        logger.serverLog(`House create err ${err}`);
    }
    
});



function loadHouse(house) {
  
  // id = parseInt(house.house_id);
    id = house.house_id;

   // Entrance
   const colshape = mp.colshapes.newSphere(house.house_position.x, house.house_position.y, house.house_position.z, 1);
   colshape.setVariable('house', colshape);
   colshape.setVariable('house_id', id);
   colshape.setVariable('house_address', house.house_address);
   colshape.setVariable('house_owner', house.house_owner ? house.house_owner : `Los Santos Govt`);
   colshape.setVariable('house_door_type', true);
   // Exit 
        const exitcolshape = mp.colshapes.newSphere(parseFloat(house.house_interior_position.x), parseFloat(house.house_interior_position.y), parseFloat(house.house_interior_position.z), 1);
        exitcolshape.setVariable('house', exitcolshape);
        exitcolshape.setVariable('house_id', id);
        exitcolshape.setVariable('house_door_type', false);
      
        const exitmarker = mp.markers.new(0, new mp.Vector3(parseFloat(house.house_interior_position.x), parseFloat(house.house_interior_position.y), parseFloat(house.house_interior_position.z) -0.1), 1, { visible: true, color: [198, 77, 156, 100] });
        exitmarker.setVariable('house_id', id);
   
    // Dimension Set
        exitcolshape.dimension = id;
        exitmarker.dimension = id;

   
   const label = mp.labels.new(`${house.house_address}`, new mp.Vector3(house.house_position.x, house.house_position.y, house.house_position.z + 0.3), {
        los: true,
        font: 0,
        drawDistance: 2.5 * 4.0
    });
    label.setVariable('house_id', id);

    const marker = mp.markers.new(0, new mp.Vector3(house.house_position.x, house.house_position.y, house.house_position.z - 0.1), 1, { visible: true, color: [198, 77, 156, 100] });
    marker.setVariable('house_id', id);

    const blip = mp.blips.new(40, new mp.Vector3(house.house_position.x, house.house_position.y, house.house_position.z),
    {
        name: `House`,
        scale: 0.7,
        color: 69,
        alpha: 255,
        drawDistance: 1.0,
        shortRange: true,
        rotation: 0,
        dimension: 0,
    });
    blip.setVariable('house_id', id);
}

module.exports.loadHouse = loadHouse;


mp.events.addCommand('delhouse', async (player, _, id) => {
    const admin = player.getVariable('admin');
    if(!admin) return player.outputChatBox(`Error: This command is for admins only!`);
    if(admin < 3) return player.outputChatBox(`Command is in development!`);
    if(isNaN(id)) return player.outputChatBox(`Syntax : /delhouse id`);

    try 
    {
        const findhouse = await houses.findOne({ where: { house_id: id }});
        if(!findhouse) return player.outputChatBox(`House Not Found`);

        mp.colshapes.forEach((shape) => {
            if(shape.getVariable('house_id') == id) {
                shape.destroy();
            }
        });

        mp.markers.forEach((marker) => {
            if(marker.getVariable('house_id') == id) {
                marker.destroy();
            }
        });

        mp.blips.forEach((blip) => {
            if(blip.getVariable('house_id') == id) {
                blip.destroy();
            }
        });

        mp.labels.forEach((label) => {
            if(label.getVariable('house_id') == id) {
                label.destroy();
            }
        });

        await findhouse.destroy();
        player.outputChatBox(`Successfully Deleted House With ID ${id}`);
    }
    catch(err)
    {
        logger.serverLog(`Deleting House Failed ${err}`);
    }
});

mp.events.addCommand(`testinterior`, (player, _, id) => {
    const data = InteriorData[id];
    if(!data) return player.outputChatBox(`Interior Not found!`);
    player.outputChatBox(`Interior Name : ${data.name} Position:  ${data.position}`);
    player.position = data.position;
});


mp.events.add("playerEnterColshape", async (player, shape) => {
  
        if(shape == shape.getVariable('house')) 
        {
            player.outputChatBox(`${pink}Press ${white}Y${pink} to enter the house, and ${white}E${pink} to manage the house`);
            player.setVariable('inHouseColShape', shape);
        }
    
});


mp.events.add("playerExitColshape", (player, shape) => {
    if(shape == shape.getVariable('house')) {
       player.call(`CLIENT::CLOSE:HOUSE:MENU`);
       player.setVariable("inHouseColShape", null);
    }
});


mp.events.add('SERVER::HOUSE:MENU', async (player) => {
    try
    {
            const house = player.getVariable('inHouseColShape');
            if(!house) return;
            const house_id = house.getVariable('house_id');
            //const door_type = house.getVariable('house_door_type');
            
            const findhouse = await houses.findOne({ where: { house_id: parseInt(house_id) }});
            if(findhouse) 
            {
               // console.log(findhouse)
              player.call('CLIENT::OPEN:HOUSE:MENU', [findhouse.house_id, findhouse.house_owner, findhouse.house_address]);

            }
        
    }
    catch(err)
    {
        logger.serverLog(`Player Enter house colshape ${err}`);
    }
});


mp.events.add("SERVER::HOUSE:ENTER", async (player) => {
    const characterName = player.getVariable("playingCharacter");
    const house = player.getVariable('inHouseColShape');
    if(!house) return;
    const house_id = house.getVariable('house_id');
    const door_type = house.getVariable('house_door_type');

    try 
    {
        const findhouse = await houses.findOne({ where: { house_id: house_id }});
        const findcharacter = await characters.findOne({ where: { character_name: characterName }});
        if(!findhouse || !findcharacter) return;
        if(findhouse.house_lock == true) return player.outputChatBox(`House is locked`);
        if(door_type == true) 
        {
            player.setVariable('inHouse', true);
            player.setVariable('inHouseOwner', findhouse.house_owner);
            player.dimension = findhouse.house_id;
            findcharacter.update({ character_dimension: findhouse.house_id });
            player.position = new mp.Vector3(parseInt(findhouse.house_interior_position.x), parseInt(findhouse.house_interior_position.y), parseInt(findhouse.house_interior_position.z));
        } else {
            player.setVariable('inHouse', false);
            player.setVariable('inHouseOwner', null);
            player.dimension = 0;
            findcharacter.update({ character_dimension: 0 });
            player.position = new mp.Vector3(parseInt(findhouse.house_position.x), parseInt(findhouse.house_position.y), parseInt(findhouse.house_position.z) + 1);
        }
    }
    catch(err)
    {
        logger.serverLog(`House Enter Error ${err}`);
    }
});


mp.events.add('SERVER::HOUSE:LOCK', async (player, house_id) => {
    try
    {
        const findhouse = await houses.findOne({ where: { house_id: house_id }});
        if(findhouse) {
            findhouse.update({ house_lock: true });
            player.outputChatBox(`House Locked Successfully`);
        }
    }
    catch(err)
    {
        logger.serverLog(`Locking House Error ${err}`);
    }
});

mp.events.add('SERVER::HOUSE:UNLOCK', async (player, house_id) => {
    try
    {
        const findhouse = await houses.findOne({ where: { house_id: house_id }});
        if(findhouse) {
            findhouse.update({ house_lock: false });
            player.outputChatBox(`House Unlocked Successfully`);
        }
    }
    catch(err)
    {
        logger.serverLog(`Unlocking House Error ${err}`);
    }
});


mp.events.add(`SERVER::HOUSE:ADD:TENANT`, async (player, house_id, Name) => {
    try 
    {
        const findhouse = await houses.findOne({ where: { house_id: house_id }});
        const findcharacter = await characters.findOne({ where: { character_name: Name }});

        if(findhouse && findcharacter) 
        {
            findhouse.update({ house_tenants: { Name }});
            player.outputChatBox(`Tenant ${Name} Successfully Added to the house!`);
        } else {
            player.outputChatBox(`Try Again with correct Character Name`);
        }
    }
    catch(err)
    {
        logger.serverLog(`Add Tenant Error ${err}`);
    }
});


mp.events.add(`SERVER::HOUSE:KICK:TENANT`, async (player, house_id, Name) => {
    try 
    {
        const findhouse = await houses.findOne({ where: { house_id: house_id }});
        if(findhouse) {
            findhouse.update({ house_tenants: Name });
        }
    }
    catch(err)
    {
        logger.serverLog(`House Kick Tenant Fail ${err}`);
    }
});
//_______________________________________________________________________________________________________________


mp.events.addCommand(`changedim`, (player, _, dim) => {
    player.dimension = parseInt(dim);
});

mp.events.addCommand(`getdim`, (player) => {
    player.outputChatBox(`Your Dimension is ${player.dimension}`);
});

mp.events.addCommand(`buyhouse`, async (player) => {
    try
    {

    }
    catch(err)
    {
        logger.serverLog(`buy house fail ${err}`);
    }
});