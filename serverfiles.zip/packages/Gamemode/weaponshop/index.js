'use strict';

const invService = require("../Inventory/inventory.service");

/**
 * Money integration:
 * Uses loaded character instance on player.character (set in Character/character.js).
 * Cash: character.pocket_money
 * Bank: character.bank_money
 * Spending order: cash first, then bank.
 */
function toInt(n){
  n = Number(n);
  if (!Number.isFinite(n)) return 0;
  n = Math.floor(n);
  return n < 0 ? 0 : n;
}

async function spend(player, amount){
  amount = toInt(amount);
  if (amount <= 0) return true;

  const ch = player.character;
  if (!ch) throw new Error('character not loaded');

  const cash = toInt(ch.pocket_money);
  const bank = toInt(ch.bank_money);

  if ((cash + bank) < amount) return false;

  let left = amount;

  if (cash > 0){
    const take = Math.min(cash, left);
    ch.pocket_money = cash - take;
    left -= take;
  }

  if (left > 0){
    ch.bank_money = bank - left;
    left = 0;
  }

  await ch.save();

  // Update HUD cash if available
  try {
    if (global.hudMoney && typeof global.hudMoney.syncCash === 'function') {
      global.hudMoney.syncCash(player, ch);
    } else {
      player.setVariable('pocket_money', toInt(ch.pocket_money));
    }
  } catch (_) {}

  return true;
}

// Weapons -> inventory item (template weapon_*)
mp.events.add("weaponshop:buyWeapon", async (player, weaponName, price) => {
  try {
    const p = toInt(price);
    if (p <= 0) return;

    const ok = await spend(player, p);
    if (!ok) return;

    await invService.addItemByTemplateName(
      player,
      String(weaponName).toLowerCase(),
      1,
      { ammo: 100, equipped: false }
    );
  } catch (e) {
    console.log("weaponshop:buyWeapon error", e);
  }
});

// Ammo -> inventory ammo item
mp.events.add("weaponshop:buyAmmo", async (player, amount, price) => {
  try {
    const a = toInt(amount);
    const p = toInt(price);
    if (a <= 0 || p <= 0) return;

    const ok = await spend(player, p);
    if (!ok) return;

    // default ammo template (adjust if you support more weapon types)
    await invService.addItemByTemplateName(player, "pistol_ammo", a, null);
  } catch (e) {
    console.log("weaponshop:buyAmmo error", e);
  }
});

// Medikit
mp.events.add("weaponshop:buyMedikit", async (player, amount, price) => {
  try {
    const a = Math.max(1, toInt(amount));
    const p = toInt(price);
    if (p <= 0) return;

    const ok = await spend(player, p);
    if (!ok) return;

    await invService.addItemByTemplateName(player, "medikit", a, null);
  } catch (e) {
    console.log("weaponshop:buyMedikit error", e);
  }
});

// Body armor
mp.events.add("weaponshop:buyArmor", async (player, amount, price) => {
  try {
    const a = Math.max(1, toInt(amount));
    const p = toInt(price);
    if (p <= 0) return;

    const ok = await spend(player, p);
    if (!ok) return;

    await invService.addItemByTemplateName(player, "bodyarmor", a, null);
  } catch (e) {
    console.log("weaponshop:buyArmor error", e);
  }
});
