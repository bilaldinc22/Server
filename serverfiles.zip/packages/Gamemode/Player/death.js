// Knocked/Injured system for player "death"
// - When a player dies, they are respawned in-place as "injured" (frozen + anim) with a bleedout timer.
// - Player can call EMS (optional) and/or respawn to hospital after the timer.
// - Server always validates state/time to prevent abuse.

// Color defines
const darkred = "!{#B30000}";
const lightred = "!{#FF0000}";
const green = "!{#00B30E}";
const blue = "!{#0054B3}";
const orange = "!{#EA7F00}";
const yellow = "!{#FFF009}";
const pink = "!{#FF009B}";
const white = "!{#FFFFFF}";
const purple = "!{#A200FF}";
const skyblue = "!{#00FFFF}";
const gray = "!{#808080}";
const black = "!{#000000}";

// ===== Config =====
const DEATH_CFG = {
  // After playerDeath, we respawn the player in place and mark them as injured
  respawnInPlaceDelayMs: 250,

  // How long until the player can choose to respawn (hospital)
  bleedoutMs: 120_000,

  // Hospital respawn location
  hospitalSpawn: {
    pos: new mp.Vector3(298.73, -584.36, 43.26), // Pillbox Hill Medical Center (outside)
    heading: 70.0,
    dimension: 0,
  },

  // If your server has a medic faction code, set it here (else keep null and broadcast to nobody)
  // Example: PD uses 999 in your scripts; you might set EMS to 998 if you have it.
  emsFactionCode: null,
};

// Per-player state (kept server-side; do not trust client)
const injuredState = new Map(); // player.id -> { injuredUntil:number, deathPos:Vector3, deathDim:number }

function now() {
  return Date.now();
}

function isPlayerValid(player) {
  return player && mp.players.exists(player);
}

function isInjured(player) {
  return isPlayerValid(player) && player.getVariable("injured") === true;
}

function setInjured(player, state) {
  if (!isPlayerValid(player)) return;
  player.setVariable("injured", !!state);
}

function getInjuredEntry(player) {
  if (!isPlayerValid(player)) return null;
  return injuredState.get(player.id) || null;
}

function clearInjured(player) {
  if (!isPlayerValid(player)) return;
  injuredState.delete(player.id);
  setInjured(player, false);
  // Client cleanup
  player.call("CLIENT::NOT:INJURED");
}

function notifyEms(player) {
  if (!isPlayerValid(player)) return;

  const entry = getInjuredEntry(player);
  const pos = entry?.deathPos || player.position;

  if (DEATH_CFG.emsFactionCode === null) return;

  mp.players.forEach((p) => {
    try {
      const f = p.getVariable("faction");
      if (!f || typeof f !== "object") return;
      if (f.code !== DEATH_CFG.emsFactionCode) return;
      p.outputChatBox(`${orange}[EMS] ${white}Injured player: ${player.getVariable("playingCharacter") || player.name} (ID: ${player.id})`);
      p.outputChatBox(`${gray}Location: ${pos.x.toFixed(1)}, ${pos.y.toFixed(1)}, ${pos.z.toFixed(1)}`);
    } catch (e) {}
  });
}

function respawnToHospital(player) {
  if (!isPlayerValid(player)) return;
  const { pos, heading, dimension } = DEATH_CFG.hospitalSpawn;

  clearInjured(player);

  player.dimension = dimension;
  player.spawn(pos);
  player.heading = heading;
  player.health = 100;

  player.outputChatBox(`${green}[Hospital] ${white}You have been treated and released.`);
}

function respawnInPlaceAsInjured(player) {
  if (!isPlayerValid(player)) return;
  if (isInjured(player)) return;

  const deathPos = new mp.Vector3(player.position.x, player.position.y, player.position.z);
  const deathDim = player.dimension;

  const injuredUntil = now() + DEATH_CFG.bleedoutMs;
  injuredState.set(player.id, { injuredUntil, deathPos, deathDim });
  setInjured(player, true);

  // Respawn (revives the ped) then let client handle freeze/anim/controls
  player.spawn(deathPos);
  player.dimension = deathDim;
  player.health = 50;

  player.call("CLIENT::INJURED", [DEATH_CFG.bleedoutMs]);
  player.outputChatBox(`${lightred}[Injured] ${white}Call EMS or wait to be transported to the hospital.`);
}

// ===== Events =====

mp.events.add("playerDeath", (player /*, reason, killer */) => {
  if (!isPlayerValid(player)) return;

  // Avoid double firing / edge cases
  if (isInjured(player)) return;

  setTimeout(() => {
    if (!isPlayerValid(player)) return;
    respawnInPlaceAsInjured(player);
  }, DEATH_CFG.respawnInPlaceDelayMs);
});

mp.events.add("playerQuit", (player) => {
  if (!player) return;
  injuredState.delete(player.id);
});

mp.events.add("playerSpawn", (player) => {
  // If they were injured and got spawned by something else (admin revive, script, etc.), clear state.
  if (!isPlayerValid(player)) return;
  if (isInjured(player)) {
    // keep injured if they were spawned in-place by our system
    // but if another script spawned them away, we still want to remove freeze/anim client-side
    player.call("CLIENT::INJURED_SYNC", []);
  }
});

// Client requests
mp.events.add("SERVER::DEATH:REQUEST_RESPAWN", (player) => {
  if (!isPlayerValid(player)) return;
  if (!isInjured(player)) return;

  const entry = getInjuredEntry(player);
  if (!entry) return;

  if (now() < entry.injuredUntil) {
    const remaining = Math.ceil((entry.injuredUntil - now()) / 1000);
    player.outputChatBox(`${gray}You can respawn in ${remaining}s.`);
    return;
  }

  respawnToHospital(player);
});

mp.events.add("SERVER::DEATH:CALL_EMS", (player) => {
  if (!isPlayerValid(player)) return;
  if (!isInjured(player)) return;
  notifyEms(player);
  player.outputChatBox(`${blue}[Info] ${white}EMS has been notified (if available).`);
});

// Fallback command for players
mp.events.addCommand("respawn", (player) => {
  if (!isPlayerValid(player)) return;
  if (!isInjured(player)) return player.outputChatBox(`${gray}You are not injured.`);
  mp.events.call("SERVER::DEATH:REQUEST_RESPAWN", player);
});
