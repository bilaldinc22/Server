
const logger = require('../Logger/discord');

mp.events.add('playerChat',(player, fullText) => {
    if(!fullText) return;

    const admin = player.getVariable('admin');
    const username = player.getVariable("username");
    const character = player.getVariable('playingCharacter');

    if(admin > 0) 
    {
        mp.players.broadcastInRange(player.position, 15, `${lightred}ADMIN${white} ${username} : ${fullText}`);
        logger.sendlog('chat_logs', `Admin ${username} Says : ${fullText}`);
    } 
    else 
    {
        mp.players.broadcastInRange(player.position, 15, `${character} (${player.id})!{#A9A9A9} says:!{#ffffff} ${fullText}`);
        logger.sendlog('chat_logs', `${character} Says : ${fullText}`);
    }
});

mp.events.addCommand('s', (player, fullText) => {
    if(!fullText) return;

    const admin = player.getVariable('admin');
    const username = player.getVariable("username");
    const character = player.getVariable('playingCharacter');

    if(admin > 0) 
    {
        mp.players.broadcastInRange(player.position, 15, `${lightred}ADMIN${white} ${username} : ${fullText}`);
        logger.sendlog('chat_logs', `Admin ${username} : ${fullText}`);
    } 
    else 
    {
        mp.players.broadcastInRange(player.position, 15, `${character} (${player.id})!{#A9A9A9} says:!{#ffffff} ${fullText}`);
        logger.sendlog('chat_logs', `${character} Says : ${fullText}`);
    }
});

mp.events.addCommand('b', (player, fullText) => {
    if(!fullText) return;

    const admin = player.getVariable('admin');
    const username = player.getVariable("username");
    const character = player.getVariable('playingCharacter');

    if(admin > 0) 
    {
        mp.players.broadcastInRange(player.position, 15, `${lightred}ADMIN${white} ${username} : ${fullText}`);
        logger.sendlog('chat_logs', `Admin ${username} Says : ${fullText}`);
    } 
    else 
    {
        mp.players.broadcastInRange(player.position, 15, `${character} (${player.id})!{#A9A9A9} says:!{#ffffff} ${fullText}`);
        logger.sendlog('chat_logs', `${character} Says : ${fullText}`);
    }
});

mp.events.addCommand('me', (player, fullText) => {
    if(!fullText) return;

    const admin = player.getVariable('admin');
    const username = player.getVariable("username");
    const character = player.getVariable('playingCharacter');

    if(admin > 0) 
    {
        mp.players.broadcastInRange(player.position, 15, `${lightred}ADMIN${white} ${username} : ${fullText}`);
        logger.sendlog('chat_logs', `Admin ${username} Says : ${fullText}`);
    } 
    else 
    {
        mp.players.broadcastInRange(player.position, 15, `${character} (${player.id})!{#A9A9A9} says:!{#ffffff} ${fullText}`);
        logger.sendlog('chat_logs', `${character} Says : ${fullText}`);
    }
});

mp.events.addCommand('do', (player, fullText) => {
    if(!fullText) return;

    const admin = player.getVariable('admin');
    const username = player.getVariable("username");
    const character = player.getVariable('playingCharacter');

    if(admin > 0) 
    {
        mp.players.broadcastInRange(player.position, 15, `${lightred}ADMIN${white} ${username} : ${fullText}`);
        logger.sendlog('chat_logs', `Admin ${username} Says : ${fullText}`);
    } 
    else 
    {
        mp.players.broadcastInRange(player.position, 15, `${character} (${player.id})!{#A9A9A9} says:!{#ffffff} ${fullText}`);
        logger.sendlog('chat_logs', `${character} Says : ${fullText}`);
    }
});