
const db = require("../sequelize")
const weaponMap = require("../shared/weapon.map")



class InventoryService {

  static load(player, char) {
    let inv
    try {
      inv = JSON.parse(char.character_inventory)
    } catch {
      inv = { items: [], weapons: [] }
    }
    player.inventory = inv
    this.sync(player)
  }

  static save(player) {
    db.query(
      "UPDATE characters SET character_inventory = ? WHERE character_id = ?",
      [JSON.stringify(player.inventory), player.characterId]
    )
  }

  static sync(player) {
    const uiWeapons = player.inventory.weapons.map(w => ({
      hash: w.hash,
      ammo: w.ammo,
      label: weaponMap[w.hash]?.label || w.hash,
      icon: weaponMap[w.hash]?.icon || "unknown.png"
    }))

    player.call("inventory:sync", [{
      items: player.inventory.items,
      weapons: uiWeapons
    }])
  }

  static addItem(player, id, amount = 1) {
    const item = player.inventory.items.find(i => i.id === id)
    if (item) item.amount += amount
    else player.inventory.items.push({ id, amount })
    this.save(player)
    this.sync(player)
  }

  static addWeapon(player, hash, ammo = 0) {
    if (player.inventory.weapons.some(w => w.hash === hash)) return
    player.inventory.weapons.push({ hash, ammo, components: [] })
    this.save(player)
    this.sync(player)
  }

  static equipWeapon(player, hash) {
    const weapon = player.inventory.weapons.find(w => w.hash === hash)
    if (!weapon) return
    player.removeAllWeapons()
    player.giveWeapon(mp.joaat(hash), weapon.ammo, true)
  }
}

module.exports = InventoryService
