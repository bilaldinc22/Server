// Clientseite
mp.events.add('weaponStorage:open', (data) => {
    // UI öffnen und Lagerdaten anzeigen
});

mp.keys.bind(0x45, true, function() {
    // Interaktion mit Lager (Taste E)
    // z.B. Trigger zum Öffnen senden
});
