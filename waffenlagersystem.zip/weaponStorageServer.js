// Serverseite
mp.events.addCommand("createweaponstorage", (player) => {
    // Speicherposition in die Datenbank eintragen
});

mp.events.addCommand("deleteweaponstorage", (player, id) => {
    // Lager mit angegebener ID aus der DB entfernen
});

mp.events.add("weaponStorage:open", (player, storageId) => {
    // Inhalte des Lagers aus DB abrufen und an Client senden
});

mp.events.add("weaponStorage:storeItem", (player, item) => {
    // Item im Lager speichern
});

mp.events.add("weaponStorage:takeItem", (player, itemId) => {
    // Item aus dem Lager entnehmen
});
