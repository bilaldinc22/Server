-- MySQL Tabellenstruktur für Waffenlagersystem
CREATE TABLE IF NOT EXISTS weapon_storages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  x FLOAT NOT NULL,
  y FLOAT NOT NULL,
  z FLOAT NOT NULL,
  rotation FLOAT DEFAULT 0,
  type VARCHAR(50) DEFAULT 'default',
  owner VARCHAR(100) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS weapon_storage_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  storage_id INT NOT NULL,
  item_name VARCHAR(100) NOT NULL,
  item_type VARCHAR(50) DEFAULT 'weapon',
  amount INT DEFAULT 1,
  weapon_hash VARCHAR(100),
  ammo INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (storage_id) REFERENCES weapon_storages(id) ON DELETE CASCADE
);
