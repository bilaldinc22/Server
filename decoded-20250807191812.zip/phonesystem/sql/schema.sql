-- SIM cards
drop table if exists sim_cards;
CREATE TABLE sim_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    owner_id INT NOT NULL,
    phone_number VARCHAR(20) UNIQUE NOT NULL,
    active TINYINT DEFAULT 0
);

-- Contacts
drop table if exists contacts;
CREATE TABLE contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    owner_id INT NOT NULL,
    name VARCHAR(50) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    favorite TINYINT DEFAULT 0
);

-- Call logs
drop table if exists call_logs;
CREATE TABLE call_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caller VARCHAR(20) NOT NULL,
    callee VARCHAR(20) NOT NULL,
    status ENUM('dialed','received','missed') NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Messages
drop table if exists messages;
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    conversation_id INT,
    sender VARCHAR(20) NOT NULL,
    receiver VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Blocked numbers
drop table if exists blocked_numbers;
CREATE TABLE blocked_numbers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    owner_id INT NOT NULL,
    blocked_number VARCHAR(20) NOT NULL
);

-- Voicemail
drop table if exists voicemail;
CREATE TABLE voicemail (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caller VARCHAR(20) NOT NULL,
    callee VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);
