const db = require('./db');
const sim = require('./sim');

mp.events.add('phone:getVoicemails', async (player) => {
    const number = await sim.getActiveSim(player.id);
    if (!number) return;
    const [rows] = await db.execute(
        'SELECT id, caller, message, timestamp FROM voicemail WHERE callee=? ORDER BY timestamp DESC',
        [number]
    );
    player.call('phone:voicemailData', [rows]);
});

mp.events.add('phone:deleteVoicemail', async (player, id) => {
    const number = await sim.getActiveSim(player.id);
    if (!number) return;
    await db.execute(
        'DELETE FROM voicemail WHERE id=? AND callee=?',
        [id, number]
    );
    player.call('phone:voicemailUpdated');
});
