const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'mysql-mariadb-1-25.zap-srv.com',
    user: process.env.DB_USER || 'zap851638-1',
    password: process.env.DB_PASSWORD || '3IDvRbF29SqgMwR8',
    database: process.env.DB_NAME || 'zap851638-1',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

module.exports = pool;
