const db = require('./db');
const sim = require('./sim');
const { isBlocked } = require('./blocklist');

mp.events.add('phone:callStart', async (player, targetNumber, anonymous) => {
    const callerNumber = await sim.getActiveSim(player.id);
    if (!callerNumber) return player.call('phone:error', ['Keine aktive SIM.']);

    if (await isBlocked(player.id, targetNumber)) {
        return player.call('phone:error', ['Nummer blockiert.']);
    }

    const target = [...mp.players].find(p => p.data?.phoneNumber === targetNumber);
    if (!target) {
        await db.execute(
            'INSERT INTO call_logs (caller, callee, status) VALUES (?, ?, ?)',
            [callerNumber, targetNumber, 'missed']
        );
        return player.call('phone:callFailed', ['Teilnehmer nicht erreichbar.']);
    }

    if (await isBlocked(target.id, callerNumber)) {
        return player.call('phone:callFailed', ['Teilnehmer blockiert den Anruf.']);
    }

    target.call('phone:incomingCall', [anonymous ? 'Anonym' : callerNumber]);
    player.data.currentCall = target;
    target.data.currentCall = player;

    const onAnswer = (targetPlayer) => {
        if (targetPlayer !== target) return;
        mp.events.remove('phone:callAnswer', onAnswer);
        player.call('phone:callConnected', [targetNumber]);
        target.call('phone:callConnected', [callerNumber]);
    };

    const onEnd = (endPlayer, reason) => {
        if (![player, target].includes(endPlayer)) return;
        mp.events.remove('phone:callEnd', onEnd);
        mp.events.remove('phone:callAnswer', onAnswer);
        player.call('phone:callEnded', [reason]);
        target.call('phone:callEnded', [reason]);
        player.data.currentCall = null;
        target.data.currentCall = null;
    };

    mp.events.add('phone:callAnswer', onAnswer);
    mp.events.add('phone:callEnd', onEnd);
});

mp.events.add('phone:leaveVoicemail', async (player, targetNumber, message) => {
    const callerNumber = await sim.getActiveSim(player.id);
    if (!callerNumber) return;
    await db.execute(
        'INSERT INTO voicemail (caller, callee, message) VALUES (?,?,?)',
        [callerNumber, targetNumber, message]
    );
});
