# RAGE:MP Phone System

Dieses Verzeichnis enthält ein erweitertes Telefonsystem für RAGE:MP.

## Features
- Verwaltung mehrerer SIM-Karten
- Kontakte mit Favoriten und Löschfunktion
- SMS-Versand und Broadcast-Nachrichten
- Anrufe mit Blocklisten und Voicemail
- Datenbankanbindung über `mysql2/promise`

Weitere Events können nach Bedarf ergänzt werden.
