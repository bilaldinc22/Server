require('./calls');
require('./messages');
require('./contacts');
require('./blocklist');
require('./voicemail');
const sim = require('./sim');

mp.events.add('playerJoin', async (player) => {
    const number = await sim.getActiveSim(player.id);
    if (number) player.data.phoneNumber = number;
    player.call('phone:init', [number]);
});
