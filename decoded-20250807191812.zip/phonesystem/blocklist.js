const db = require('./db');

mp.events.add('phone:blockNumber', async (player, number) => {
    await db.execute(
        'INSERT INTO blocked_numbers (owner_id, blocked_number) VALUES (?,?)',
        [player.id, number]
    );
    player.call('phone:blocklistUpdated');
});

mp.events.add('phone:unblockNumber', async (player, number) => {
    await db.execute(
        'DELETE FROM blocked_numbers WHERE owner_id=? AND blocked_number=?',
        [player.id, number]
    );
    player.call('phone:blocklistUpdated');
});

async function isBlocked(ownerId, number) {
    const [rows] = await db.execute(
        'SELECT 1 FROM blocked_numbers WHERE owner_id=? AND blocked_number=? LIMIT 1',
        [ownerId, number]
    );
    return rows.length > 0;
}

module.exports = { isBlocked };
