const db = require('./db');

mp.events.add('phone:contactAdd', async (player, name, number) => {
    await db.execute(
        'INSERT INTO contacts (owner_id, name, phone_number) VALUES (?,?,?)',
        [player.id, name, number]
    );
    player.call('phone:contactsUpdated');
});

mp.events.add('phone:contactRemove', async (player, contactId) => {
    await db.execute(
        'DELETE FROM contacts WHERE owner_id=? AND id=?',
        [player.id, contactId]
    );
    player.call('phone:contactsUpdated');
});

mp.events.add('phone:getContacts', async (player) => {
    const [rows] = await db.execute(
        'SELECT id, name, phone_number, favorite FROM contacts WHERE owner_id=? ORDER BY favorite DESC, name ASC',
        [player.id]
    );
    player.call('phone:contactsData', [rows]);
});

mp.events.add('phone:contactFavorite', async (player, contactId, favorite) => {
    await db.execute(
        'UPDATE contacts SET favorite=? WHERE owner_id=? AND id=?',
        [favorite ? 1 : 0, player.id, contactId]
    );
    player.call('phone:contactsUpdated');
});
