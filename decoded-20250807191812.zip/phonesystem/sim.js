const db = require('./db');

async function getActiveSim(playerId) {
    const [rows] = await db.execute(
        'SELECT phone_number FROM sim_cards WHERE owner_id=? AND active=1 LIMIT 1',
        [playerId]
    );
    return rows.length ? rows[0].phone_number : null;
}

async function setActiveSim(playerId, simId) {
    await db.execute('UPDATE sim_cards SET active=0 WHERE owner_id=?', [playerId]);
    await db.execute('UPDATE sim_cards SET active=1 WHERE owner_id=? AND id=?', [playerId, simId]);
}

module.exports = { getActiveSim, setActiveSim };
