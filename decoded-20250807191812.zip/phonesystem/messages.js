const db = require('./db');
const sim = require('./sim');
const { isBlocked } = require('./blocklist');

mp.events.add('phone:smsSend', async (player, targetNumber, text) => {
    if (text.length > 500) return;
    const sender = await sim.getActiveSim(player.id);
    if (!sender) return player.call('phone:error', ['Keine aktive SIM.']);

    if (await isBlocked(player.id, targetNumber)) {
        return player.call('phone:error', ['Nummer blockiert.']);
    }

    const [conv] = await db.execute(
        'SELECT MIN(id) AS id FROM messages WHERE (sender=? AND receiver=?) OR (sender=? AND receiver=?)',
        [sender, targetNumber, targetNumber, sender]
    );
    const conversationId = conv[0].id || null;

    await db.execute(
        `INSERT INTO messages (conversation_id, sender, receiver, message)
         VALUES (?, ?, ?, ?)`,
        [conversationId, sender, targetNumber, text]
    );

    const target = [...mp.players].find(p => p.data?.phoneNumber === targetNumber);
    if (target) target.call('phone:smsReceived', [sender, text]);

    player.call('phone:smsSent', [targetNumber, text]);
});

mp.events.add('phone:smsBroadcast', async (player, numbers, text) => {
    for (const num of numbers) {
        mp.events.call('phone:smsSend', player, num, text);
    }
});
