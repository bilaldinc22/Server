
// Optional zur Prüfung: mp.gui.chat.push("waffenspeicher client.js geladen!");

const WEAPON_HASHES = [
    // Pistols
    0x1B06D571, 0x5EF9FEC4, 0x22D8FE39, 0x99AEEB3B, 0xC1B3C3D1, 0x2B5EF5EC, 0x917F6C8C, 0x83839C4,
    0x88374054, 0xD205520E, 0x47757124, 0xDC4DB296, 0xCB96392F,
    // SMGs & PDWs
    0x13532244, 0x2BE6766B, 0x324215364, 0xA89CB99E, 0xEFE7E2DF, 0x7FD62962,
    // Assault & Carbine Rifles
    0xBFEFFF6D, 0x394F415C, 0x83BF0278, 0xC0A3098D, 0xAF113F99, 0x84D6FAFD,
    // Shotguns
    0x1D073A89, 0x555AF99A, 0x7846A318, 0xE284C527, 0x9D61E50F, 0x3AABBBAA, 0xDBBD7280, 0xEF951FBB, 0x42BF8A85,
    // Sniper Rifles
    0x05FC3C11, 0xC734385A, 0x0C472FE2, 0xA914799, 0xD1D5F52B,
    // Machine Guns
    0x476BF155, 0xDBBD7280, 0x9D07F764,
    // Heavy Weapons
    0xB1CA77B1, 0xA284510B, 0x42BF8A85, 0x93E220BD, 0x7F7497E5, 0x6D544C99, 0x63AB0442,
    // Nahkampf (entfernbar falls nicht gewünscht)
    0x92A27487, 0x958A4A8F, 0xF9E6AA4B, 0x84BD7BFD, 0xA2719263,
    // Sonstiges
    0xFBAB5776, 0xA0973D5E, 0x24B17070, 0x678B81B1, 0xDC4DB296, 0xCB96392F, 0x8BB05FD7,
];

function sendWeaponDataToServer() {
    let waffen = [];
    const player = mp.players.local;
    for (let i = 0; i < WEAPON_HASHES.length; i++) {
        let hash = WEAPON_HASHES[i];
        if (mp.game.invoke('0x8DECB02F88F428BC', player.handle, hash, false)) { // HAS_PED_GOT_WEAPON
            let ammo = mp.game.invoke('0x015A522136D7F951', player.handle, hash); // GET_AMMO_IN_PED_WEAPON
            waffen.push({ hash, ammo });
        }
    }
    mp.events.callRemote('waffenSpeicher:clientSendWeapons', JSON.stringify(waffen));
}

// Auf Anforderung durch Server (/waffenfetch)
mp.events.add('waffenSpeicher:requestWeapons', () => {
    sendWeaponDataToServer();
});

// Automatisches Speichern beim Disconnect (nur bei "sanftem" Disconnect)
mp.events.add('playerQuit', () => {
    sendWeaponDataToServer();
});

// Alle 10 Sekunden automatische Speicherung (gegen Crash/Alt+F4)
setInterval(() => {
    sendWeaponDataToServer();
}, 10000);
