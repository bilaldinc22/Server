require("./waffenspeicher/client.js");
