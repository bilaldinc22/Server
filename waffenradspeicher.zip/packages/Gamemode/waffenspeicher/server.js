
const mysql = require('mysql2/promise');
const mp = global.mp;

const dbConfig = {
    host: "mysql-mariadb-1-25.zap-srv.com",
    user: "zap851638-1",
    password: "3IDvRbF29SqgMwR8",
    database: "zap851638-1"
};

let db;
(async () => { db = await mysql.createPool(dbConfig); })();

// Waffen aus der DB beim Join laden
mp.events.add('playerReady', async (player) => {
    if (!player || !player.socialClub) return;
    const [rows] = await db.query('SELECT * FROM player_weapons WHERE socialclub = ?', [player.socialClub]);
    rows.forEach(row => {
        player.giveWeapon(Number(row.weapon_hash), Number(row.ammo));
    });
});

// Waffen vom Client speichern (keine Chat-Ausgabe!)
mp.events.add('waffenSpeicher:clientSendWeapons', async (player, waffenJSON) => {
    let waffen = [];
    try { waffen = JSON.parse(waffenJSON); } catch { return; }
    await db.query('DELETE FROM player_weapons WHERE socialclub = ?', [player.socialClub]);
    for (const w of waffen) {
        await db.query('INSERT INTO player_weapons (socialclub, weapon_hash, ammo) VALUES (?, ?, ?)', [
            player.socialClub, Number(w.hash), Number(w.ammo)
        ]);
    }
    // Keine Chat-Ausgabe mehr!
});

// Command, um den Client zum Senden aufzufordern (keine Chat-Ausgabe!)
mp.events.addCommand('waffenfetch', (player) => {
    player.call('waffenSpeicher:requestWeapons');
    // Keine Chat-Ausgabe!
});

// Debug-Befehl für Entwickler (optional)
mp.events.addCommand('waffenprint', (player) => {
    player.outputChatBox("[DEBUG] Waffen werden nur noch clientseitig gespeichert!");
});
