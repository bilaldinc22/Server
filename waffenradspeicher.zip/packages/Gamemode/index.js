require('./waffenspeicher/server.js');
