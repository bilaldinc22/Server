
const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'mysql-mariadb-1-25.zap-srv.com',
    user: 'zap851638-1',
    password: '3IDvRbF29SqgMwR8',
    database: 'zap851638-1'
});

connection.connect(err => {
    if (err) console.error('[MySQL] Verbindung fehlgeschlagen:', err);
    else console.log('[MySQL] Geldsystem verbunden.');
});

function loadMoney(player) {
    connection.query('SELECT cash, bank FROM player_money WHERE socialClub = ?', [player.socialClub], (err, results) => {
        if (err) return console.error(err);
        if (results.length > 0) {
            player.data.cash = results[0].cash;
            player.data.bank = results[0].bank;
        } else {
            connection.query('INSERT INTO player_money (socialClub, cash, bank) VALUES (?, 500, 1000)', [player.socialClub]);
            player.data.cash = 500;
            player.data.bank = 1000;
        }
    });
}

function saveMoney(player) {
    connection.query('UPDATE player_money SET cash = ?, bank = ? WHERE socialClub = ?', [player.data.cash, player.data.bank, player.socialClub]);
}

mp.events.add('playerJoin', (player) => {
    player.data.cash = 0;
    player.data.bank = 0;
});

mp.events.add('playerReady', (player) => {
    loadMoney(player);
});

mp.events.add('playerQuit', (player) => {
    saveMoney(player);
});

mp.events.add('money:deposit', (player, amount) => {
    amount = parseInt(amount);
    if (player.data.cash >= amount && amount > 0) {
        player.data.cash -= amount;
        player.data.bank += amount;
        player.outputChatBox(`~g~${amount}$ eingezahlt.`);
        saveMoney(player);
    }
});

mp.events.add('money:withdraw', (player, amount) => {
    amount = parseInt(amount);
    if (player.data.bank >= amount && amount > 0) {
        player.data.bank -= amount;
        player.data.cash += amount;
        player.outputChatBox(`~g~${amount}$ abgehoben.`);
        saveMoney(player);
    }
});

mp.events.add('money:transferToPlayer', (player, targetId, amount) => {
    const target = mp.players.at(parseInt(targetId));
    amount = parseInt(amount);
    if (!target || isNaN(amount) || amount <= 0 || player.data.bank < amount) return;
    player.data.bank -= amount;
    target.data.bank += amount;
    player.outputChatBox(`~g~${amount}$ an Spieler ${targetId} überwiesen.`);
    target.outputChatBox(`~g~${amount}$ von Spieler ${player.name} erhalten.`);
    saveMoney(player);
    saveMoney(target);
});
