
CREATE TABLE `server_vehicles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `owner` VARCHAR(64),
  `vehiclename` VARCHAR(64),
  `plate` VARCHAR(16),
  `fuel` FLOAT,
  `health` VARCHAR(64),
  `position` VARCHAR(128),
  `engine` TINYINT(1),
  `vlock` TINYINT(1),
  `doors` TEXT,
  `windows` TEXT
);