
📦 Fahrzeug-Kontrollsystem – Installation

1. SQL:
   - Importiere `sql/server_vehicles.sql` in deine MySQL-Datenbank.

2. Server-Scripts:
   - `fahrzeugServer.js` nach `packages/Gamemode/fahrzeug/`
   - `fahrzeugClient.js` nach `packages/Gamemode/fahrzeug/`

3. UI:
   - Ordner `fahrzeugmenue` in `client_packages/ui/` ablegen.

4. Trigger:
   - F5 am Fahrzeug öffnet das Menü
   - Menü: Tank, Zustand, Türen, Motor, Schlüsselübergabe

Fertig! Das System ist sofort einsatzbereit.
